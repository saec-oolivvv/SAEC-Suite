(function(){
  function ready(fn){
    if(document.readyState !== 'loading'){ fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function apiFetch(path, options){
    options = options || {};
    options.headers = options.headers || {};
    if (window.SAEC_CC && SAEC_CC.nonce) {
      options.headers['X-WP-Nonce'] = SAEC_CC.nonce;
    }
    var base = (window.SAEC_CC && SAEC_CC.restBase) ? SAEC_CC.restBase : '';
    return fetch(base + path, options);
  }

  function qs(sel, root){
    return (root || document).querySelector(sel);
  }

  function showModal(){
    var m = qs('#saec-checkout-modal');
    if(m){ m.style.display = 'block'; }
  }

  function hideModal(){
    var m = qs('#saec-checkout-modal');
    if(m){ m.style.display = 'none'; }
  }

  function setCheckoutForm(tier, sale){
    var form = qs('#saec-checkout-form');
    if(!form) return;
    var t = qs('input[name="tier"]', form);
    var s = qs('input[name="sale_type"]', form);
    if(t) t.value = tier || '';
    if(s) s.value = sale || '';
  }

  // Control Center: module toggles + filters
  ready(function(){
    var toggles = document.querySelectorAll('.saec-suite-toggle');
    if(toggles && toggles.length){
      toggles.forEach(function(el){
        el.addEventListener('change', function(){
          var plugin = el.getAttribute('data-plugin');
          var on = el.checked ? true : false;
          el.disabled = true;

          apiFetch('/module/toggle', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({plugin: plugin, on: on})
          })
          .then(function(r){
            if(!r.ok){
              return r.json().catch(function(){ return null; }).then(function(data){
                var msg = (data && data.message) ? data.message : (SAEC_CC && SAEC_CC.i18n ? SAEC_CC.i18n.toggleFailed : 'Action failed');
                throw new Error(msg);
              });
            }
            return r.json();
          })
          .then(function(data){
            if(data && typeof data.active !== 'undefined'){
              el.checked = !!data.active;
            }
          })
          .catch(function(err){
            el.checked = !on;
            alert(err && err.message ? err.message : (SAEC_CC && SAEC_CC.i18n ? SAEC_CC.i18n.toggleFailed : 'Action failed'));
          })
          .finally(function(){
            el.disabled = false;
          });
        });
      });
    }

    var refreshBtn = document.querySelector('[data-saec-refresh-modules]');
    if(refreshBtn){
      refreshBtn.addEventListener('click', function(e){
        e.preventDefault();
        refreshBtn.disabled = true;
        apiFetch('/modules', {method:'GET', credentials:'same-origin'})
          .then(function(r){ return r.json(); })
          .then(function(data){ if(window.console){ console.log('SAEC modules', data); } })
          .catch(function(){})
          .finally(function(){ refreshBtn.disabled = false; });
      });
    }

    var search = document.getElementById('saec-cc-module-search');
    var updatesOnly = document.getElementById('saec-cc-updates-only');
    var table = document.querySelector('.saec-cc-table-modules');
    if(table && (search || updatesOnly)){
      var rows = table.querySelectorAll('tbody tr');
      function applyFilter(){
        var q = (search && search.value ? search.value.toLowerCase().trim() : '');
        var upd = !!(updatesOnly && updatesOnly.checked);
        rows.forEach(function(r){
          var txt = (r.textContent || '').toLowerCase();
          var hasUpd = r.getAttribute('data-has-update') === '1';
          var ok = true;
          if(q && txt.indexOf(q) === -1){ ok = false; }
          if(upd && !hasUpd){ ok = false; }
          r.style.display = ok ? '' : 'none';
        });
      }
      if(search){ search.addEventListener('input', applyFilter); }
      if(updatesOnly){ updatesOnly.addEventListener('change', applyFilter); }
      applyFilter();
    }
  });

  // Licence: open checkout modal on Buy buttons
  ready(function(){
    document.addEventListener('click', function(e){
      var btn = e.target && e.target.closest ? e.target.closest('.saec-buy-btn') : null;
      if(!btn) return;

      // only handle licence buy buttons (avoid colliding with other buttons)
      var card = btn.closest ? btn.closest('.saec-licence-card') : null;
      if(!card) return;

      e.preventDefault();

      var tier = btn.getAttribute('data-tier') || '';
      var sale = btn.getAttribute('data-sale') || '';

      if(!sale){
        var sel = qs('.saec-sale-type', card);
        if(sel && sel.value){ sale = sel.value; }
      }

      setCheckoutForm(tier, sale);
      showModal();
    });

    var closeBtn = qs('#saec-checkout-close');
    var cancelBtn = qs('#saec-checkout-cancel');
    if(closeBtn){ closeBtn.addEventListener('click', function(e){ e.preventDefault(); hideModal(); }); }
    if(cancelBtn){ cancelBtn.addEventListener('click', function(e){ e.preventDefault(); hideModal(); }); }

    var overlay = qs('#saec-checkout-modal');
    if(overlay){
      overlay.addEventListener('click', function(e){
        if(e.target === overlay){ hideModal(); }
      });
    }
  });
})();
