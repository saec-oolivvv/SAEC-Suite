<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SAEC_License_Manager {

    private static $instance = null;
    private $option_key = 'saec_license_data';
    private $data       = array();

    /**
     * Singleton accessor.
     *
     * @return SAEC_License_Manager
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $stored     = get_option( $this->option_key, array() );
        $this->data = is_array( $stored ) ? $stored : array();

        add_action( 'saec_core_cron_license_validate', array( $this, 'cron_validate' ) );
    }

    /**
     * Return the stored (hashed) licence key.
     *
     * This is the SHA-512 hash of the real licence key.
     *
     * @return string
     */
    public function get_license_key() {
        return isset( $this->data['license_key'] ) ? $this->data['license_key'] : '';
    }

    

/**
 * Return a masked representation of the stored licence hash.
 * Only the SHA-512 hash is stored; this masks it for display.
 *
 * @return string
 */
public function get_masked_key() {
    $key = $this->get_license_key();
    if ( empty( $key ) ) {
        return '********';
    }
    $key = (string) $key;
    $len = strlen( $key );
    if ( $len <= 12 ) {
        return str_repeat( '*', $len );
    }
    return substr( $key, 0, 6 ) . '…' . substr( $key, -4 );
}
/**
     * Licence status (active / invalid / expired / none / inactive).
     *
     * @return string
     */
    public function get_status() {
        return isset( $this->data['status'] ) ? $this->data['status'] : 'inactive';
    }

    /**
     * Raw feature flags (backward compatibility).
     *
     * @return array
     */
    public function get_features() {
        return isset( $this->data['features'] ) && is_array( $this->data['features'] )
            ? $this->data['features']
            : array();
    }

    /**
     * Licence tier: basic | pro | agency | none.
     *
     * @return string
     */
    public function get_tier() {
        return isset( $this->data['tier'] ) ? $this->data['tier'] : 'basic';
    }

    /**
     * Global lockdown flag.
     *
     * @return bool
     */
    public function is_lockdown() {
        return ! empty( $this->data['lockdown'] );
    }

    /**
     * Human message from licence server.
     *
     * @return string
     */
    public function get_message() {
        return isset( $this->data['message'] ) ? $this->data['message'] : '';
    }

    /**
     * Purchase / upgrade URL.
     *
     * @return string
     */
    public function get_purchase_url() {
        return isset( $this->data['purchase_url'] ) ? $this->data['purchase_url'] : '';
    }

    /**
     * Expiration date string.
     *
     * @return string
     */
    public function get_expires_at() {
        return isset( $this->data['expires_at'] ) ? $this->data['expires_at'] : '';
    }

    /**
     * Last successful licence check timestamp.
     *
     * @return int
     */
    public function get_last_check() {
        return isset( $this->data['last_check'] ) ? (int) $this->data['last_check'] : 0;
    }

    /**
     * Source of the current licence payload.
     *
     * @return string remote|cache|fallback
     */
    public function get_source() {
        return isset( $this->data['source'] ) ? sanitize_key( $this->data['source'] ) : 'cache';
    }

    /**
     * Persist licence data and propagate global SAEC Suite options.
     *
     * @param string       $license_key  SHA-512 hash of the licence key.
     * @param string       $status       Status string.
     * @param array|string $features     Feature payload from API.
     * @param string       $expires_at   Expiration date string.
     */
    public function set_license( $license_key, $status, $features, $expires_at, $source = 'remote' ) {
        $this->data['license_key'] = sanitize_text_field( $license_key );
        $this->data['status']      = sanitize_text_field( $status );

        // Default values for new suite fields.
        $tier         = 'basic';
        $lockdown     = false;
        $message      = '';
        $purchase_url = '';
        $reason       = '';

        if ( is_array( $features ) ) {
            if ( isset( $features['tier'] ) ) {
                $tier = sanitize_key( $features['tier'] );
            }
            if ( isset( $features['lockdown'] ) ) {
                $lockdown = (bool) $features['lockdown'];
            }
            if ( isset( $features['message'] ) ) {
                $message = wp_kses_post( $features['message'] );
            }
            if ( isset( $features['purchase_url'] ) ) {
                $purchase_url = esc_url_raw( $features['purchase_url'] );
            }
            if ( isset( $features['reason'] ) ) {
                $reason = sanitize_text_field( $features['reason'] );
            }

            // Build simple feature flags array for backward compatibility.
            $flags = array();

            if ( 'basic' === $tier ) {
                $flags[] = 'basic';
            } elseif ( 'pro' === $tier ) {
                $flags = array( 'basic', 'pro' );
            } elseif ( 'agency' === $tier ) {
                $flags = array( 'basic', 'pro', 'agency' );
            }

            $this->data['features'] = $flags;
        } else {
            // Legacy behaviour: assume $features is a flat array of feature keys.
            $this->data['features'] = array_map( 'sanitize_key', (array) $features );
        }

        $this->data['tier']         = $tier;
        $this->data['lockdown']     = $lockdown;
        $this->data['message']      = $message;
        $this->data['purchase_url'] = $purchase_url;
        $this->data['reason']       = $reason;
        $this->data['expires_at']   = $expires_at ? sanitize_text_field( $expires_at ) : '';
        $this->data['last_check']   = time();
        $this->data['source']       = sanitize_key( $source );

        update_option( $this->option_key, $this->data );

        // Propagate global options for all SAEC Suite modules.
        update_option( 'saec_suite_tier', $tier );
        update_option( 'saec_suite_lockdown', (bool) $lockdown );
        update_option( 'saec_suite_message', $message );
        update_option( 'saec_suite_purchase', $purchase_url );
    }

    /**
     * Clear licence data and revert to BASIC unlocked mode.
     */
    public function clear_license() {
        delete_option( $this->option_key );
        $this->data = array();

        update_option( 'saec_suite_tier', 'basic' );
        update_option( 'saec_suite_lockdown', false );
        update_option( 'saec_suite_message', '' );
        update_option( 'saec_suite_purchase', '' );
    }

    /**
     * Cron / background validation.
     */
    public function cron_validate() {
        // Silent validation for cron.
        $this->refresh();
    }

    /**
     * Refresh licence status on demand.
     *
     * @return true|WP_Error
     */
    public function refresh() {
        $license_key = $this->get_license_key();
        if ( empty( $license_key ) ) {
            return new WP_Error( 'no_key', __( 'No licence key stored.', 'saec-core' ) );
        }

        $endpoint = trailingslashit( saec_suite_get_license_api_endpoint() ) . 'validate';

        $body = array(
            'license_key' => $license_key,
            'site_url'    => home_url(),
            'instance_id' => $this->get_instance_id(),
            'machine_id'  => $this->get_machine_id(),
            'machine_md5' => $this->get_instance_id(),
            'email'       => get_bloginfo( 'admin_email' ),
        );

        $response = wp_remote_post(
            $endpoint,
            array(
                'timeout' => 20,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => $body,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( (string) $raw, true );

        if ( 200 !== (int) $code || ! is_array( $data ) || empty( $data['status'] ) ) {
            return new WP_Error( 'invalid_response', __( 'Invalid response from licence server.', 'saec-core' ) );
        }

        $old_status = $this->get_status();
        $status     = (string) $data['status'];
        $features   = isset( $data['features'] ) ? (array) $data['features'] : array();
        $expires    = isset( $data['expires_at'] ) ? (string) $data['expires_at'] : '';

        $this->set_license( $license_key, $status, $features, $expires, 'remote' );

        if ( $old_status !== $status ) {
            do_action( 'saec_license_status_changed', $status, $old_status );
        }

        return true;
    }

    /**
     * Deactivate licence (remote best-effort) and clear locally.
     *
     * @return true|WP_Error
     */
    public function deactivate() {
        $license_key = $this->get_license_key();

        // If no key is stored, just clear local state.
        if ( empty( $license_key ) ) {
            $this->clear_license();
            return true;
        }

        $endpoint = trailingslashit( saec_suite_get_license_api_endpoint() ) . 'deactivate';

        $body = array(
            'license_key' => $license_key,
            'site_url'    => home_url(),
            'instance_id' => $this->get_instance_id(),
            'email'       => get_bloginfo( 'admin_email' ),
        );

        $response = wp_remote_post(
            $endpoint,
            array(
                'timeout' => 20,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => $body,
            )
        );

        if ( is_wp_error( $response ) ) {
            // Still clear local to unlock admin flows.
            $this->clear_license();
            return $response;
        }

        $this->clear_license();
        return true;
    }

    /**
     * Activation of a new licence key.
     *
     * @param string $license_key Plain text licence key entered by user.
     *
     * @return true|WP_Error
     */
    public function activate( $license_key ) {
        $license_key = trim( $license_key );
        if ( empty( $license_key ) ) {
            return new WP_Error( 'empty_key', __( 'Licence key is empty.', 'saec-core' ) );
        }

        $endpoint = trailingslashit( saec_suite_get_license_api_endpoint() ) . 'activate';

        // Hash the licence key before sending it to the server and before storage.
        $license_hash = hash( 'sha512', $license_key );

        $body = array(
            'license_key' => $license_hash,
            'site_url'    => home_url(),
            'instance_id' => $this->get_instance_id(),
            'machine_id'  => $this->get_machine_id(),
            'machine_md5' => $this->get_instance_id(),
            'email'       => get_bloginfo( 'admin_email' ),
            'plugin'      => 'saec-suite',
            'version'     => defined( 'SAEC_CORE_VERSION' ) ? SAEC_CORE_VERSION : '',
            'wp_version'  => get_bloginfo( 'version' ),
            'php_version' => PHP_VERSION,
        );

        $response = wp_remote_post(
            $endpoint,
            array(
                'timeout' => 20,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => $body,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );

        if ( 200 !== $code || ! is_array( $data ) || empty( $data['status'] ) ) {
            return new WP_Error(
                'invalid_response',
                sprintf(
                    __( 'Invalid response from licence server. HTTP code: %d', 'saec-core' ),
                    (int) $code
                )
            );
        }

        $status   = $data['status'];
        $features = isset( $data['features'] ) ? (array) $data['features'] : array();
        $expires  = isset( $data['expires_at'] ) ? $data['expires_at'] : '';

        // Persist hashed key.
        $this->set_license( $license_hash, $status, $features, $expires, 'remote' );

        do_action( 'saec_license_activated', $status, $features );

        return true;
    }

    /**
     * Build a deterministic instance ID for this site.
     *
     * @return string
     */
    public function get_instance_id() {
        $data = home_url() . '|' . wp_salt( 'auth' );
        return md5( $data );
    }

    /**
     * Machine identifier for Agency licences.
     *
     * This identifier is intended to be stable for a given installation.
     *
     * @return string
     */
    public function get_machine_id() {
        $seed = home_url() . '|' . wp_salt( 'auth' );
        if ( function_exists( 'php_uname' ) ) {
            $seed .= '|' . php_uname( 'n' );
        }
        $seed .= '|' . ( defined( 'ABSPATH' ) ? ABSPATH : '' );

        /**
         * Filter the seed used to generate the machine identifier.
         *
         * @param string               $seed
         * @param SAEC_License_Manager  $manager
         */
        $seed = apply_filters( 'saec_suite_machine_id_seed', $seed, $this );

        /**
         * Filter the final machine identifier.
         *
         * @param string               $machine_id
         * @param SAEC_License_Manager  $manager
         */
        $machine_id = hash( 'sha256', (string) $seed );
        return apply_filters( 'saec_suite_machine_id', $machine_id, $this );
    }
    /**
     * Get public licence plans from licence server.
     *
     * @return array{ok:bool,provider?:string,plans?:array,error?:string}
     */
    public function get_public_plans() {
        $endpoint = $this->get_api_endpoint( 'plans' );
        if ( ! $endpoint ) {
            return array( 'ok' => false, 'error' => 'missing_endpoint' );
        }

        $resp = wp_remote_get(
            $endpoint,
            array(
                'timeout' => 10,
                'headers' => array( 'Accept' => 'application/json' ),
            )
        );

        if ( is_wp_error( $resp ) ) {
            return array( 'ok' => false, 'error' => $resp->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = (string) wp_remote_retrieve_body( $resp );
        $json = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            return array( 'ok' => false, 'error' => 'bad_response' );
        }

        return $json;
    }

    /**
     * Create a checkout on the licence server and return checkout URL.
     *
     * @param string $tier basic|pro|agency
     * @return array{ok:bool,checkout_url?:string,checkout_id?:string,error?:string,message?:string}
     */
    public function create_checkout( $tier, $sale_type = '', $billing = array(), $site = array() ) {
        $tier = sanitize_key( (string) $tier );
        $sale_type = sanitize_key( (string) $sale_type );

        $endpoint = $this->get_api_endpoint( 'checkout/create' );
        if ( ! $endpoint ) {
            return array( 'ok' => false, 'error' => 'missing_endpoint' );
        }

        $payload = array(
            'tier'       => $tier,
            'sale_type'  => $sale_type,
            'email'      => (string) get_bloginfo( 'admin_email' ),
            'site_url'   => home_url(),
            'machine_id' => (string) $this->get_machine_id(),
            'instance_id'=> (string) $this->get_instance_id(),
            'billing'    => is_array( $billing ) ? $billing : array(),
            'site'       => is_array( $site ) ? $site : array(),
        );

        $resp = wp_remote_post(
            $endpoint,
            array(
                'timeout' => 15,
                'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
                'body'    => wp_json_encode( $payload ),
            )
        );

        if ( is_wp_error( $resp ) ) {
            return array( 'ok' => false, 'error' => $resp->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = (string) wp_remote_retrieve_body( $resp );
        $json = json_decode( $body, true );

        if ( ! is_array( $json ) ) {
            return array( 'ok' => false, 'error' => 'bad_response' );
        }
        if ( $code < 200 || $code >= 300 || empty( $json['ok'] ) ) {
            return array(
                'ok'      => false,
                'error'   => isset( $json['error'] ) ? (string) $json['error'] : 'request_failed',
                'message' => isset( $json['message'] ) ? (string) $json['message'] : '',
            );
        }
        return $json;
    }

    /**
     * Get checkout status from the licence server.
     *
     * @param string $checkout_id
     * @return array
     */
    public function get_checkout_status( $checkout_id ) {
        $checkout_id = sanitize_text_field( (string) $checkout_id );
        $base        = $this->get_api_endpoint( 'checkout/status' );
        if ( ! $base ) {
            return array( 'ok' => false, 'error' => 'missing_endpoint' );
        }

        $url  = add_query_arg( 'checkout_id', rawurlencode( $checkout_id ), $base );
        $resp = wp_remote_get( $url, array( 'timeout' => 12 ) );

        if ( is_wp_error( $resp ) ) {
            return array( 'ok' => false, 'error' => $resp->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = (string) wp_remote_retrieve_body( $resp );
        $json = json_decode( $body, true );
        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            return array( 'ok' => false, 'error' => 'bad_response' );
        }
        return $json;
    }

    /**
     * Build absolute API endpoint URL.
     *
     * @param string $path
     * @return string
     */
    protected function get_api_endpoint( $path ) {
        if ( ! function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
            return '';
        }
        $base = (string) saec_suite_get_license_api_endpoint();
        $base = trailingslashit( $base );
        $path = ltrim( (string) $path, '/' );
        return $base . $path;
    }

}

/**
 * Expose licence status to SAEC Rules (if present).
 *
 * This allows the SAEC Rules plugin to display a warning banner
 * and send reminder emails when the SAEC licence is about to expire.
 */
if ( ! function_exists( 'saec_core_rules_license_status' ) ) {

    /**
     * @param array|string $status
     * @return array|string
     */
    function saec_core_rules_license_status( $status ) {
        if ( ! class_exists( 'SAEC_License_Manager' ) ) {
            return $status;
        }

        $lm   = SAEC_License_Manager::instance();
        $info = method_exists( $lm, 'get_license_info' ) ? $lm->get_license_info() : array();

        if ( is_array( $info ) && ! empty( $info['status'] ) ) {
            return $info;
        }

        return $status;
    }

    add_filter( 'saec_rules_license_status', 'saec_core_rules_license_status' );
}