<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SAEC_Core {

    public function __construct() {
        // Load translations at init or later (WP 6.7+ warns if loaded too early).
        add_action( 'init', array( $this, 'load_textdomain' ) );
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_init', array( $this, 'maybe_redirect_legacy_pages' ) );
        add_action( 'admin_init', array( $this, 'maybe_handle_purchase_return' ) );
        add_action( 'admin_menu', array( $this, 'enforce_menu_order' ), 999 );
        // Real-time licence validation (throttled) on admin side.
        add_action( 'admin_init', array( $this, 'maybe_realtime_validate' ) );
        // Support bundle export (Health/Diagnostics).
        add_action( 'admin_post_saec_support_bundle', array( $this, 'handle_support_bundle' ) );
        add_action( 'admin_post_saec_clear_logs', array( $this, 'handle_clear_logs' ) );
        add_action( 'admin_post_saec_logs_bundle', array( $this, 'handle_logs_bundle' ) );
        add_action( 'admin_post_saec_clear_audit', array( $this, 'handle_clear_audit' ) );
        add_action( 'admin_post_saec_audit_bundle', array( $this, 'handle_audit_bundle' ) );
        add_action( 'admin_post_saec_retry_license', array( $this, 'handle_retry_license' ) );
        add_action( 'admin_post_saec_create_checkout', array( $this, 'handle_create_checkout' ) );
        add_action( 'admin_post_saec_save_settings', array( $this, 'handle_save_settings' ) );
        // Global lockdown notice if the licence is invalid/mismatched.
        add_action( 'admin_notices', array( $this, 'maybe_show_lockdown_notice' ) );
        // AJAX: toggle SAEC modules on/off from dashboard.
        add_action( 'wp_ajax_saec_toggle_module', array( $this, 'ajax_toggle_module' ) );

        // REST API (preferred for modern admin UIs).
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );


    }

    /**
     * Map tiers to comparable ranks.
     *
     * @param string $tier Tier.
     * @return int
     */
    private function tier_rank( $tier ) {
        $tier = is_string( $tier ) ? strtolower( $tier ) : '';
        switch ( $tier ) {
            case 'agency':
                return 3;
            case 'pro':
                return 2;
            case 'basic':
                return 1;
            default:
                return 0;
		}
	}

    /**
     * Register internal SAEC Suite REST routes.
     */
    public function register_rest_routes() {
        register_rest_route(
            'saec-suite/v1',
            '/status',
            array(
                'methods'             => 'GET',
                'permission_callback' => function () {
                    return current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE );
                },
                'callback'            => function () {
                    return rest_ensure_response(
                        array(
                            'tier'        => saec_suite_get_tier(),
                            'lockdown'    => saec_suite_is_lockdown(),
                            'safe_mode'   => function_exists( 'saec_suite_is_safe_mode' ) ? saec_suite_is_safe_mode() : false,
                            'license'     => saec_suite_get_license_info(),
                            'core'        => array(
                                'version' => defined( 'SAEC_CORE_VERSION' ) ? SAEC_CORE_VERSION : null,
                            ),
                        )
                    );
                },
            )
        );

        register_rest_route(
            'saec-suite/v1',
            '/module/toggle',
            array(
                'methods'             => 'POST',
                'permission_callback' => function () {
                    return current_user_can( 'activate_plugins' );
                },
                'args'                => array(
                    'plugin' => array(
                        'type'              => 'string',
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'on'     => array(
                        'type'     => 'boolean',
                        'required' => true,
                    ),
                ),
                'callback'            => function ( WP_REST_Request $request ) {
                    // Reuse the existing AJAX logic but without admin-ajax.
                    $plugin = (string) $request->get_param( 'plugin' );
                    $on     = (bool) $request->get_param( 'on' );

                    // Never allow disabling SAEC Core itself.
                    if ( defined( 'SAEC_CORE_PLUGIN_FILE' ) ) {
                        $core_plugin_basename = plugin_basename( SAEC_CORE_PLUGIN_FILE );
                        if ( $plugin === $core_plugin_basename ) {
                            return new WP_Error( 'saec_core_protected', __( 'You cannot disable SAEC Core from this endpoint.', 'saec-core' ), array( 'status' => 400 ) );
						}
					}

                    $manager = SAEC_License_Manager::instance();
                    if ( $manager->is_lockdown() && $on ) {
                        $registry = function_exists( 'saec_suite_get_registry' ) ? saec_suite_get_registry() : array();
                        $item     = ( is_array( $registry ) && isset( $registry[ $plugin ] ) && is_array( $registry[ $plugin ] ) ) ? $registry[ $plugin ] : array();
                        $allowed  = ! empty( $item['available_in_lockdown'] );
                        if ( ! $allowed ) {
                            return new WP_Error( 'saec_lockdown', __( 'SAEC Suite is locked by licence. This module cannot be enabled in lockdown.', 'saec-core' ), array( 'status' => 403 ) );
						}
					}

                    if ( ! function_exists( 'activate_plugin' ) ) {
                        require_once ABSPATH . 'wp-admin/includes/plugin.php';
                    }

                    if ( $on ) {
                        $result = activate_plugin( $plugin );
                        if ( is_wp_error( $result ) ) {
                            return $result;
                        }
                    } else {
                        deactivate_plugins( $plugin );
                    }

                    if ( function_exists( 'saec_event' ) ) {
                        saec_event( 'module_toggled', array( 'plugin' => $plugin, 'on' => $on ), 'info' );
                    }

                    $active = function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin );
                    return rest_ensure_response( array( 'active' => $active ) );
                },
            )
        );

        // List installed SAEC modules with status and update information.
        register_rest_route(
            'saec-suite/v1',
            '/modules',
            array(
                'methods'             => 'GET',
                'permission_callback' => function () {
                    return current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE );
                },
                'callback'            => function () {
                    if ( ! function_exists( 'get_plugins' ) ) {
                        require_once ABSPATH . 'wp-admin/includes/plugin.php';
                    }

                    $all_plugins = get_plugins();
                    $updates     = get_site_transient( 'update_plugins' );
                    $update_map  = is_object( $updates ) && ! empty( $updates->response ) && is_array( $updates->response ) ? $updates->response : array();

                    $items = array();

                    $registry = array();
                    if ( function_exists( 'saec_suite_get_registry' ) ) {
                        $registry = (array) saec_suite_get_registry();
                    }

					// Backward compatibility: if Control Center provides a registry, merge it (CC overrides).
					if ( class_exists( 'SAEC_Core_Control_Center' ) ) {
						$cc = new SAEC_Core_Control_Center();
						if ( method_exists( $cc, 'get_registry' ) ) {
							$registry = array_merge( $registry, (array) $cc->get_registry() );
						}
					}

					$current_tier = function_exists( 'saec_suite_get_tier' ) ? (string) saec_suite_get_tier() : '';
					$lockdown     = function_exists( 'saec_suite_is_lockdown' ) ? (bool) saec_suite_is_lockdown() : false;
					$tier_rank    = $this->tier_rank( $current_tier );

					foreach ( $all_plugins as $plugin_file => $data ) {
                        $core_basename = ( defined( 'SAEC_CORE_PLUGIN_FILE' ) ? plugin_basename( SAEC_CORE_PLUGIN_FILE ) : '' );
                        if ( $core_basename && $plugin_file === $core_basename ) {
                            continue;
                        }

                        // Heuristic: consider SAEC modules as plugins with folder starting with "saec-"
                        // or author containing "SAEC".
                        $folder = strtok( $plugin_file, '/' );
                        $author = isset( $data['Author'] ) ? (string) $data['Author'] : '';

                        $is_saec = ( 0 === strpos( $folder, 'saec-' ) ) || ( false !== stripos( $author, 'saec' ) );
                        if ( ! $is_saec ) {
                            continue;
                        }

                        // Do not include the core itself in the modules list (it has its own status).
                        if ( defined( 'SAEC_CORE_PLUGIN_FILE' ) ) {
                            $core_base = plugin_basename( SAEC_CORE_PLUGIN_FILE );
                            if ( $plugin_file === $core_base ) {
                                continue;
                            }
                        }

                        $active = function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin_file );

                        $has_update  = isset( $update_map[ $plugin_file ] );
                        $new_version = $has_update && isset( $update_map[ $plugin_file ]->new_version ) ? (string) $update_map[ $plugin_file ]->new_version : null;

                        $required_tier  = isset( $registry[ $plugin_file ]['required_tier'] ) ? (string) $registry[ $plugin_file ]['required_tier'] : '';
                        $required_rank  = $this->tier_rank( $required_tier );
                        $can_run        = ( ! $lockdown ) && ( $tier_rank >= $required_rank );
                        $blocked_reason = '';
                        if ( $lockdown ) {
                            $blocked_reason = 'lockdown';
                        } elseif ( $required_rank > 0 && $tier_rank < $required_rank ) {
                            $blocked_reason = 'tier';
                        }


                        $items[] = array(
                            'plugin'      => $plugin_file,
                            'name'        => isset( $data['Name'] ) ? (string) $data['Name'] : $plugin_file,
                            'category'    => isset( $registry[ $plugin_file ]['category'] ) ? wp_strip_all_tags( (string) $registry[ $plugin_file ]['category'] ) : '',
                            'required_tier'=> isset( $registry[ $plugin_file ]['required_tier'] ) ? (string) $registry[ $plugin_file ]['required_tier'] : '',
                            'can_run'     => (bool) $can_run,
                            'blocked_reason' => $blocked_reason,
                            'current_tier' => $current_tier,
                            'lockdown'    => (bool) $lockdown,
                            'version'     => isset( $data['Version'] ) ? (string) $data['Version'] : '',
                            'active'      => (bool) $active,
                            'has_update'  => (bool) $has_update,
                            'new_version' => $new_version,
                            'author'      => $author,
                        );
                    }

                    return rest_ensure_response(
                        array(
                            'count' => count( $items ),
                            'items' => $items,
                        )
                    );
                },
            )
        );

        // NOTE: /modules route is registered above (enriched version).
    
        // Logs (recent entries).
        register_rest_route(
            'saec-suite/v1',
            '/logs',
            array(
                'methods'             => 'GET',
                'permission_callback' => function () {
                    return current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE );
                },
                'args'                => array(
                    'limit' => array(
                        'type'     => 'integer',
                        'required' => false,
                        'default'  => 100,
                    ),
                ),
                'callback'            => function ( WP_REST_Request $request ) {
                    $limit = (int) $request->get_param( 'limit' );
                    if ( class_exists( 'SAEC_Logger' ) ) {
                        return rest_ensure_response( array( 'entries' => SAEC_Logger::get( $limit ) ) );
                    }
                    return rest_ensure_response( array( 'entries' => array() ) );
                },
            )
        );

}

    /**
     * Load translations.
     */
    /**
     * Translation loading.
     *
     * WordPress.org will load translations automatically for this plugin slug.
     * This method is intentionally a no-op to satisfy environments where a hook calls it.
     */
    public function load_textdomain() {
        // No-op on purpose (WordPress.org handles translation loading automatically).
    }

    /**
     * Register admin menus: SAEC Suite (dashboard + licence).
     */
    public function register_menu() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) && ! current_user_can( 'manage_options' ) ) {
        return;
    }

        add_menu_page(
            __( 'SAEC Suite', 'saec-core' ),
            __( 'SAEC Suite', 'saec-core' ),
            SAEC_Capabilities::CAP_MANAGE_SUITE,
            'saec-suite',
            array( 'SAEC_Core_Admin', 'render_control_center_page' ),
            'dashicons-admin-generic',
            3
        );

        add_submenu_page(
            'saec-suite',
            __( 'Control Center', 'saec-core' ),
            __( 'Control Center', 'saec-core' ),
            SAEC_Capabilities::CAP_MANAGE_SUITE,
            'saec-suite',
            array( 'SAEC_Core_Admin', 'render_control_center_page' ),
        );

        // Backward compatibility for old bookmarks: admin.php?page=saec-control-center
        // Register the page without displaying it as a submenu entry.
        add_submenu_page(
            null,
            __( 'Control Center', 'saec-core' ),
            __( 'Control Center', 'saec-core' ),
            SAEC_Capabilities::CAP_MANAGE_SUITE,
            'saec-control-center',
            array( 'SAEC_Core_Admin', 'render_control_center_page' )
        );
    }

    
/**
 * Ensure the Core page stays the first submenu item under SAEC Suite.
 * Other SAEC modules may add their own submenu pages; WordPress will redirect
 * the top-level menu click to the first submenu item.
 */
public function enforce_menu_order() {
    if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) && ! current_user_can( 'manage_options' ) ) {
        return;
    }

    global $submenu;

    if ( empty( $submenu['saec-suite'] ) || ! is_array( $submenu['saec-suite'] ) ) {
        return;
    }

    // Find the submenu entry whose slug equals the parent slug (core page).
    $core_index = null;
    foreach ( $submenu['saec-suite'] as $i => $item ) {
        // $item = [0 => title, 1 => capability, 2 => menu_slug, 3 => page_title]
        if ( isset( $item[2] ) && 'saec-suite' === $item[2] ) {
            $core_index = $i;
            break;
        }
    }

    // If not found, add it.
    if ( null === $core_index ) {
        array_unshift(
            $submenu['saec-suite'],
            array(
                __( 'Control Center', 'saec-core' ),
                SAEC_Capabilities::CAP_MANAGE_SUITE,
                'saec-suite',
                __( 'SAEC Suite', 'saec-core' ),
            )
        );
        return;
    }

    // Move it to the top if needed.
    if ( 0 !== $core_index ) {
        $core_item = $submenu['saec-suite'][ $core_index ];
        unset( $submenu['saec-suite'][ $core_index ] );
        array_unshift( $submenu['saec-suite'], $core_item );
        $submenu['saec-suite'] = array_values( $submenu['saec-suite'] );
    }
}

/**
     * Throttled real-time licence validation.
     */
    public function maybe_realtime_validate() {
        $manager = SAEC_License_Manager::instance();

        $last_check = $manager->get_last_check();
        if ( $last_check && ( time() - $last_check ) < 30 * MINUTE_IN_SECONDS ) {
            return;
        }

        // Trigger a background validation.
        $manager->cron_validate();
    }

    /**
     * Show a global admin notice when the suite is locked down.
     */
    public function maybe_show_lockdown_notice() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) && ! current_user_can( 'manage_options' ) ) {
        return;
    }

        $manager = SAEC_License_Manager::instance();

        if ( ! $manager->is_lockdown() ) {
            return;
        }

        $message = $manager->get_message();
        if ( ! $message ) {
            $message = __( 'SAEC Suite is currently locked because the licence is invalid, expired or mismatched. Basic and Pro/Agency features are disabled until this is resolved.', 'saec-core' );
        }

        $purchase_url = $manager->get_purchase_url();
        ?>
        <div class="notice notice-error">
            <p><strong><?php esc_html_e( 'SAEC Suite Licence Lockdown', 'saec-core' ); ?></strong></p>
            <p><?php echo wp_kses_post( $message ); ?></p>
            <?php if ( $purchase_url ) : ?>
                <p>
                    <a href="<?php echo esc_url( $purchase_url ); ?>" target="_blank" class="button button-primary">
                        <?php esc_html_e( 'Fix / renew licence', 'saec-core' ); ?>
                    </a>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * AJAX handler to toggle SAEC modules on/off from the dashboard.
     */
    public function ajax_toggle_module() {
        check_ajax_referer( 'saec_toggle_module', '_ajax_nonce' );

        if ( ! current_user_can( 'activate_plugins' ) ) {
            wp_send_json_error( __( 'You are not allowed to manage plugins.', 'saec-core' ) );
        }

        $plugin = isset( $_POST['plugin'] ) ? sanitize_text_field( wp_unslash( $_POST['plugin'] ) ) : '';
        $on     = isset( $_POST['on'] ) ? (bool) $_POST['on'] : false;

        if ( empty( $plugin ) ) {
            wp_send_json_error( __( 'Missing plugin parameter.', 'saec-core' ) );
        }

        // Never allow disabling SAEC Core itself through the dashboard toggle.
        if ( defined( 'SAEC_CORE_PLUGIN_FILE' ) ) {
            $core_plugin_basename = plugin_basename( SAEC_CORE_PLUGIN_FILE );
            if ( $plugin === $core_plugin_basename ) {
                wp_send_json_error( __( 'You cannot disable SAEC Core from this screen.', 'saec-core' ) );
            }
        }

        // Respect global lockdown: allow disabling any module, but only enable
        // modules explicitly marked as available in lockdown.
        $manager = SAEC_License_Manager::instance();
        if ( $manager->is_lockdown() && $on ) {
            $registry = function_exists( 'saec_suite_get_registry' ) ? saec_suite_get_registry() : array();
            $item     = ( is_array( $registry ) && isset( $registry[ $plugin ] ) && is_array( $registry[ $plugin ] ) ) ? $registry[ $plugin ] : array();
            $allowed  = ! empty( $item['available_in_lockdown'] );
            if ( ! $allowed ) {
                wp_send_json_error( __( 'SAEC Suite is locked by licence. This module cannot be enabled in lockdown.', 'saec-core' ) );
            }
        }

        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if ( $on ) {
            $result = activate_plugin( $plugin );
            if ( is_wp_error( $result ) ) {
                wp_send_json_error( $result->get_error_message() );
            }
        } else {
            deactivate_plugins( $plugin );
        }

        if ( function_exists( 'saec_event' ) ) {
            saec_event( 'module_toggled', array( 'plugin' => $plugin, 'on' => $on ), 'info' );
        }


        $active = function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin );

        wp_send_json_success(
            array(
                'active' => $active,
            )
        );
    }

    /**
     * Render the dashboard page.
     */
    public function render_dashboard_page() {
        SAEC_Core_Admin::render_dashboard_page();
    }

    /**
     * Register internal SAEC Suite REST routes.
     */

    /**
     * Render SAEC Suite main page (unified Control Center).
     */
    public function render_control_center_page() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'saec-core' ) );
        }

        if ( class_exists( 'SAEC_Core_Control_Center' ) ) {
            $cc = new SAEC_Core_Control_Center();
            $cc->render_page();
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__( 'SAEC Suite', 'saec-core' ) . '</h1>';
        echo '<p>' . esc_html__( 'Control Center component is missing.', 'saec-core' ) . '</p></div>';
    }


/**
 * Redirect legacy admin page slugs to the unified Core page.
 */
public function maybe_redirect_legacy_pages() {
    if ( ! is_admin() ) {
        return;
    }
    if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) && ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    if ( 'saec-suite-licence' === $page ) {
        $url = admin_url( 'admin.php?page=saec-suite&tab=licence' );
        wp_safe_redirect( $url );
        exit;
    }
    if ( 'saec-control-center' === $page ) {
        $tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
        $url = admin_url( 'admin.php?page=saec-suite' );
        if ( $tab ) {
            $url = add_query_arg( 'tab', $tab, $url );
        }
        wp_safe_redirect( $url );
        exit;
    }
}

    
/**
 * Hide legacy/duplicate menu entries added by older modules.
 */
public function cleanup_duplicate_menus() {
    // Hide duplicate licence page if another module still registers it.
    if ( function_exists( 'remove_submenu_page' ) ) {
        remove_submenu_page( 'saec-suite', 'saec-suite-licence' );
    }
}

/**
     * Export a support bundle (JSON) for diagnostics.
     * URL: /wp-admin/admin-post.php?action=saec_support_bundle&_wpnonce=...
     */
    public function handle_support_bundle() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'saec-core' ) );
        }

        $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'saec_support_bundle' ) ) {
            wp_die( esc_html__( 'Security check failed.', 'saec-core' ) );
        }

        $bundle = $this->generate_support_bundle();

        $filename = 'saec-support-bundle-' . gmdate( 'Ymd-His' ) . '.json';
        nocache_headers();
        header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
        header( 'Content-Disposition: attachment; filename=' . $filename );
        echo wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        exit;
    }

    /**
     * Build a diagnostics payload.
     *
     * Keep this method defensive (no fatals, no null-to-string deprecations).
     *
     * @return array
     */
    private function generate_support_bundle() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $license = function_exists( 'saec_suite_get_license_info' ) ? (array) saec_suite_get_license_info() : array();
        $tier    = function_exists( 'saec_suite_get_tier' ) ? (string) saec_suite_get_tier() : '';

        // System / environment.
        $env = array(
            'generated_at' => gmdate( 'c' ),
            'site'         => home_url(),
            'wp'           => array(
                'version'   => get_bloginfo( 'version' ),
                'locale'    => function_exists( 'determine_locale' ) ? determine_locale() : get_locale(),
                'multisite' => is_multisite(),
            ),
            'php'          => array(
                'version'           => PHP_VERSION,
                'memory_limit'      => ini_get( 'memory_limit' ),
                'max_execution_time'=> ini_get( 'max_execution_time' ),
            ),
            'server'       => array(
                'software' => isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) $_SERVER['SERVER_SOFTWARE'] : '',
            ),
        );

        // Theme.
        $theme = wp_get_theme();
        $theme_info = array(
            'name'    => $theme ? $theme->get( 'Name' ) : '',
            'version' => $theme ? $theme->get( 'Version' ) : '',
            'template'=> $theme ? $theme->get_template() : '',
        );

        // SAEC plugins.
        $plugins = get_plugins();
        $saec = array();
        foreach ( $plugins as $file => $data ) {
            if ( 0 === strpos( (string) $file, 'saec-' ) && 'saec-core/saec-core.php' !== $file ) {
                $saec[ $file ] = array(
                    'name'    => isset( $data['Name'] ) ? (string) $data['Name'] : '',
                    'version' => isset( $data['Version'] ) ? (string) $data['Version'] : '',
                    'active'  => function_exists( 'is_plugin_active' ) ? (bool) is_plugin_active( $file ) : null,
                );
            }
        }

        // Health checks snapshot.
        $perm = (string) get_option( 'permalink_structure', '' );
        $rest = function_exists( 'rest_url' ) ? (string) rest_url() : '';
        $uploads = wp_upload_dir();
        $uploads_ok = ! empty( $uploads['basedir'] ) && is_dir( $uploads['basedir'] ) && wp_is_writable( $uploads['basedir'] );

        $health = array(
            'rest_url'           => $rest,
            'permalinks'         => array(
                'structure' => $perm,
                'pretty'    => ( '' !== $perm ),
            ),
            'uploads_writable'   => $uploads_ok,
            'wp_cron'            => array(
                'disabled_const' => defined( 'DISABLE_WP_CRON' ) ? (bool) DISABLE_WP_CRON : false,
                'alternate'      => defined( 'ALTERNATE_WP_CRON' ) ? (bool) ALTERNATE_WP_CRON : false,
            ),
        );

        // Logs (last 200) – optional.
        $logs = class_exists( 'SAEC_Logger' ) ? SAEC_Logger::get( 200 ) : array();

        // Registry snapshot.
        $registry = function_exists( 'saec_suite_get_registry' ) ? (array) saec_suite_get_registry() : array();

        return array(
            'env'      => $env,
            'theme'    => $theme_info,
            'license'  => $license,
            'tier'     => $tier,
            'health'   => $health,
            'saec'     => $saec,
            'registry' => $registry,
            'logs'     => $logs,
        );
    }


    
    public function handle_clear_logs() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) ) {
            wp_die( esc_html__( 'Access denied.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_clear_logs' );

        if ( class_exists( 'SAEC_Logger' ) ) {
            SAEC_Logger::clear();
        }

        $redirect = $this->saec_suite_admin_url();
        $redirect = add_query_arg(
            array(
                'tab'     => 'logs',
                'cleared' => 1,
            ),
            $redirect
        );

        wp_safe_redirect( $redirect );
        exit;
    }

    public function handle_logs_bundle() {
        if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) ) {
            wp_die( esc_html__( 'Access denied.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_logs_bundle' );

        $payload = array(
            'generated_at' => gmdate( 'c' ),
            'site'         => home_url(),
            'entries'      => class_exists( 'SAEC_Logger' ) ? SAEC_Logger::get( 500 ) : array(),
        );

        $filename = 'saec-logs-' . gmdate( 'Ymd-His' ) . '.json';

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );

        echo wp_json_encode( $payload );
        exit;
    }

    public function handle_clear_audit() {
        if ( ! current_user_can( 'saec_manage_suite' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to access this page.', 'saec-core' ) );
        }
        check_admin_referer( 'saec_clear_audit' );

        if ( class_exists( 'SAEC_Audit' ) ) {
            SAEC_Audit::clear();
            SAEC_Audit::log( 'audit_cleared', array(), 'warning' );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=audit&cleared=1' ) );
        exit;
    }

    public function handle_audit_bundle() {
        if ( ! current_user_can( 'saec_manage_suite' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to access this page.', 'saec-core' ) );
        }
        check_admin_referer( 'saec_audit_bundle' );

        $bundle = array(
            'generated_at' => gmdate( 'c' ),
            'site'         => home_url(),
            'audit'        => class_exists( 'SAEC_Audit' ) ? SAEC_Audit::bundle( 500 ) : array(),
        );

        $json = wp_json_encode( $bundle, JSON_PRETTY_PRINT );
        nocache_headers();
        header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
        header( 'Content-Disposition: attachment; filename=saec-audit-bundle-' . gmdate( 'Ymd-His' ) . '.json' );
        echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }


    /**
     * Force a licence refresh from the server.
     */
    public function handle_retry_license() {
        if ( ! ( current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) || current_user_can( 'manage_options' ) ) ) {
            wp_die( esc_html__( 'Access denied.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_retry_license' );

        $manager = class_exists( 'SAEC_License_Manager' ) ? SAEC_License_Manager::instance() : null;
        $result  = $manager ? $manager->refresh() : new WP_Error( 'no_manager', __( 'Licence manager not available.', 'saec-core' ) );

        if ( is_wp_error( $result ) ) {
            set_transient( 'saec_cc_market_notice', array(
                'type'    => 'error',
                'message' => sprintf( __( 'Licence refresh failed: %s', 'saec-core' ), $result->get_error_message() ),
            ), 30 );
        } else {
            set_transient( 'saec_cc_market_notice', array(
                'type'    => 'success',
                'message' => __( 'Licence status refreshed.', 'saec-core' ),
            ), 30 );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=licence' ) );
        exit;
    }

/**
 * Build an admin URL for the unified SAEC Suite page.
 * Always returns a non-empty string to avoid PHP 8.1+ null deprecation warnings.
 *
 * @param array $args Query args.
 * @return string
 */
private function saec_suite_admin_url( $args = array() ) {
    $base = admin_url( 'admin.php?page=saec-suite' );
    if ( empty( $args ) || ! is_array( $args ) ) {
        return $base;
    }
    return add_query_arg( $args, $base );
}


    /**
     * Create a checkout on the licence server and redirect to provider checkout URL.
     * Expected params: tier (basic|pro|agency), sale_type (monthly|yearly|lifetime).
     */
    public function handle_create_checkout() {
        if ( ! ( current_user_can( SAEC_Capabilities::CAP_MANAGE_LICENSES ) || current_user_can( 'manage_options' ) || SAEC_Capabilities::user_can_manage_licenses() ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to do this.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_create_checkout', 'saec_checkout_nonce' );

        $tier      = isset( $_REQUEST['tier'] ) ? sanitize_key( wp_unslash( $_REQUEST['tier'] ) ) : '';
        $sale_type = isset( $_REQUEST['sale_type'] ) ? sanitize_key( wp_unslash( $_REQUEST['sale_type'] ) ) : '';


        $billing = array(
            'company'  => isset( $_POST['billing_company'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_company'] ) ) : '',
            'name'     => isset( $_POST['billing_name'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_name'] ) ) : '',
            'vat'      => isset( $_POST['billing_vat'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_vat'] ) ) : '',
            'email'    => isset( $_POST['billing_email'] ) ? sanitize_email( wp_unslash( $_POST['billing_email'] ) ) : '',
            'address1' => isset( $_POST['billing_address1'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_address1'] ) ) : '',
            'address2' => isset( $_POST['billing_address2'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_address2'] ) ) : '',
            'zip'      => isset( $_POST['billing_zip'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_zip'] ) ) : '',
            'city'     => isset( $_POST['billing_city'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_city'] ) ) : '',
            'country'  => isset( $_POST['billing_country'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_country'] ) ) : '',
        );
        $site_meta = array(
            'name'    => isset( $_POST['site_name'] ) ? sanitize_text_field( wp_unslash( $_POST['site_name'] ) ) : '',
            'url'     => isset( $_POST['site_url'] ) ? esc_url_raw( wp_unslash( $_POST['site_url'] ) ) : '',
            'contact' => isset( $_POST['site_contact'] ) ? sanitize_text_field( wp_unslash( $_POST['site_contact'] ) ) : '',
        );

        if ( ! $tier ) {
            wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=licence&saec_err=missing_tier' ) );
            exit;
        }

        $manager = class_exists( 'SAEC_License_Manager' ) ? SAEC_License_Manager::instance() : null;
        if ( ! $manager ) {
            wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=licence&saec_err=missing_manager' ) );
            exit;
        }

        // create_checkout may accept sale_type in newer versions.
        if ( method_exists( $manager, 'create_checkout' ) ) {
            try {
                $result = $manager->create_checkout( $tier, $sale_type, $billing, $site_meta );
            } catch ( Throwable $e ) {
                $result = array( 'ok' => false, 'error' => 'exception', 'message' => $e->getMessage() );
            }
        } else {
            $result = array( 'ok' => false, 'error' => 'missing_method' );
        }

        if ( is_wp_error( $result ) ) {
            $msg = $result->get_error_message();
            wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=licence&saec_err=' . rawurlencode( $msg ) ) );
            exit;
        }

        $ok = is_array( $result ) && ! empty( $result['ok'] );
        if ( $ok && ! empty( $result['checkout_url'] ) ) {
            wp_redirect( esc_url_raw( $result['checkout_url'] ) );
            exit;
        }

        $err = is_array( $result ) && ! empty( $result['message'] ) ? (string) $result['message'] : __( 'Checkout creation failed.', 'saec-core' );
        wp_safe_redirect( admin_url( 'admin.php?page=saec-suite&tab=licence&saec_err=' . rawurlencode( $err ) ) );
        exit;
    }

/**
 * Save SAEC Suite settings (Safe Mode, log verbosity, endpoint overrides).
 */
public function handle_save_settings() {
    if ( ! current_user_can( SAEC_Capabilities::CAP_MANAGE_SUITE ) && ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'saec-core' ) );
    }

    check_admin_referer( 'saec_save_settings' );

    $safe_mode = isset( $_POST['saec_suite_safe_mode'] ) ? (bool) wp_unslash( $_POST['saec_suite_safe_mode'] ) : false;

    $opts = get_option( 'saec_suite_options', array() );
    if ( ! is_array( $opts ) ) {
        $opts = array();
    }
    $opts['safe_mode'] = $safe_mode ? 1 : 0;

    update_option( 'saec_suite_options', $opts, false );

    $redirect = admin_url( 'admin.php?page=saec-suite&tab=settings&saved=1' );
    wp_safe_redirect( $redirect );
    exit;
	}

	/**
	 * Handle return from checkout provider (success/cancel) in WP admin.
	 * This is intentionally conservative to avoid breaking admin_init.
	 */
	public function maybe_handle_purchase_return() : void {
        if ( ! is_admin() ) {
            return;
        }

        // Prevent redirect loops: if we already handled the return once,
        // don't process or redirect again.
        if ( isset( $_GET['saec_checkout_handled'] ) ) {
            return;
        }

        // Only handle on our pages or when explicit params are present.
        $page = isset( $_GET['page'] ) ? sanitize_key( (string) $_GET['page'] ) : '';
        $has_checkout = isset( $_GET['saec_checkout_id'] ) || isset( $_GET['checkout_id'] );

        if ( $page !== 'saec-suite' && $page !== 'saec-control-center' && ! $has_checkout ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) && ! ( class_exists( 'SAEC_Capabilities' ) && SAEC_Capabilities::user_can_manage_licenses() ) ) {
            return;
        }

        $checkout_id = '';
        if ( isset( $_GET['saec_checkout_id'] ) ) {
            $checkout_id = sanitize_text_field( (string) wp_unslash( $_GET['saec_checkout_id'] ) );
        } elseif ( isset( $_GET['checkout_id'] ) ) {
            $checkout_id = sanitize_text_field( (string) wp_unslash( $_GET['checkout_id'] ) );
        }

        if ( $checkout_id === '' ) {
            return;
        }

        // Best-effort: ask license manager to sync checkout status if supported.
        if ( method_exists( $this, 'license_manager' ) ) {
            // no-op
        }

        if ( isset( $this->license_manager ) && is_object( $this->license_manager ) && method_exists( $this->license_manager, 'sync_checkout_status' ) ) {
            $this->license_manager->sync_checkout_status( $checkout_id );
        }

        // Store last checkout id (best-effort) for UI/status messaging.
        $user_id = get_current_user_id();
        if ( $user_id ) {
            update_user_meta( $user_id, 'saec_last_checkout_id', $checkout_id );
        }

        // Redirect to licence tab WITHOUT checkout_id to avoid re-processing on refresh.
        $target = admin_url( 'admin.php?page=saec-suite&tab=licence&saec_checkout_handled=1' );
        wp_safe_redirect( $target );
        exit;
    }

}
