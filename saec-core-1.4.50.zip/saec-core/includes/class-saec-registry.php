<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * SAEC Registry
 * Discovers SAEC module metadata from manifest files and filters.
 */
class SAEC_Registry {

    const MANIFEST_FILENAME = 'saec.json';

    /**
     * Allowed tiers.
     *
     * @var string[]
     */
    private static $allowed_tiers = array( 'basic', 'pro', 'agency', 'none' );

    /**
     * Validate a manifest array.
     *
     * @param array $json Manifest.
     * @return array { valid:bool, errors:string[] }
     */
    private static function validate_manifest( array $json ) : array {
        $errors = array();

        $slug = isset( $json['slug'] ) ? (string) $json['slug'] : '';
        $name = isset( $json['name'] ) ? (string) $json['name'] : '';
        $tier = isset( $json['required_tier'] ) ? (string) $json['required_tier'] : '';

        if ( '' === trim( $slug ) ) {
            $errors[] = 'Missing required field: slug';
        }

        if ( '' === trim( $name ) ) {
            $errors[] = 'Missing required field: name';
        }

        if ( '' !== $tier && ! in_array( strtolower( $tier ), self::$allowed_tiers, true ) ) {
            $errors[] = 'Invalid required_tier (allowed: basic, pro, agency, none)';
        }

        return array(
            'valid'  => empty( $errors ),
            'errors' => $errors,
        );
    }

    /**
     * Return registry indexed by plugin file (e.g., folder/plugin.php).
     *
     * @return array
     */
    public static function get_registry() : array {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        $by_folder = array();
        foreach ( $plugins as $plugin_file => $data ) {
            $folder = strtok( $plugin_file, '/' );
            if ( $folder ) {
                if ( ! isset( $by_folder[ $folder ] ) ) {
                    $by_folder[ $folder ] = $plugin_file;
                }
            }
        }

        $items = array();

        // Scan plugin folders for manifest files.
        foreach ( $by_folder as $folder => $plugin_file ) {
            $manifest_path = WP_PLUGIN_DIR . '/' . $folder . '/' . self::MANIFEST_FILENAME;
            if ( ! file_exists( $manifest_path ) ) {
                continue;
            }

            $raw = file_get_contents( $manifest_path );
            if ( false === $raw || '' === trim( $raw ) ) {
                continue;
            }

            $json = json_decode( $raw, true );
            if ( ! is_array( $json ) ) {
                continue;
            }

            $validation = self::validate_manifest( $json );

            // Normalize
            $items[ $plugin_file ] = array(
                'slug'                 => isset( $json['slug'] ) ? (string) $json['slug'] : $folder,
                'name'                 => isset( $json['name'] ) ? (string) $json['name'] : $folder,
                'category'             => isset( $json['category'] ) ? (string) $json['category'] : '',
                'required_tier'         => isset( $json['required_tier'] ) ? (string) $json['required_tier'] : '',
                'available_in_lockdown' => isset( $json['available_in_lockdown'] ) ? (bool) $json['available_in_lockdown'] : false,
                'features'             => isset( $json['features'] ) && is_array( $json['features'] ) ? array_values( $json['features'] ) : array(),
                'manifest_valid'        => (bool) $validation['valid'],
                'manifest_errors'       => isset( $validation['errors'] ) && is_array( $validation['errors'] ) ? $validation['errors'] : array(),
            );
        }

        /**
         * Filter: allow modules to register metadata without a manifest file.
         * Return the same structure as items above, indexed by plugin file.
         */
        $items = apply_filters( 'saec_suite_registry_items', $items );

        return is_array( $items ) ? $items : array();
    }
}

/**
 * Public helper for other SAEC modules.
 *
 * @return array
 */
function saec_suite_get_registry() : array {
    return SAEC_Registry::get_registry();
}
