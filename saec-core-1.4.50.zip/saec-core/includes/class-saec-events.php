<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class SAEC_Events {

    /**
     * Dispatch an internal SAEC event.
     *
     * @param string $name
     * @param array  $payload
     * @param string $level
     * @return void
     */
    public static function dispatch( $name, $payload = array(), $level = 'info' ) {
        $name    = is_string( $name ) ? sanitize_key( $name ) : '';
        $payload = is_array( $payload ) ? $payload : array();

        // Always log.
        if ( class_exists( 'SAEC_Logger' ) ) {
            SAEC_Logger::log( $level, $name, $payload );
        }

        /**
         * Fires when an internal SAEC event occurs.
         *
         * @param string $name
         * @param array  $payload
         * @param string $level
         */
        do_action( 'saec_suite_event', $name, $payload, $level );
    }
}

// Public helper.
if ( ! function_exists( 'saec_event' ) ) {
    function saec_event( $name, $payload = array(), $level = 'info' ) {
        SAEC_Events::dispatch( $name, $payload, $level );
    }
}
