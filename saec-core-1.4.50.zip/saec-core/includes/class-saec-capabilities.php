<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * SAEC capabilities manager.
 *
 * Keeps SAEC permissions independent from WordPress' manage_options while
 * remaining backward compatible (manage_options always allowed).
 */
class SAEC_Capabilities {

    const CAP_MANAGE_SUITE       = 'saec_manage_suite';
    const CAP_MANAGE_LICENSES    = 'saec_manage_licenses';
    const CAP_VIEW_REPORTS       = 'saec_view_reports';
    const CAP_MANAGE_SECURITY    = 'saec_manage_security';
    const CAP_MANAGE_PERFORMANCE = 'saec_manage_performance';

    /**
     * Return list of all SAEC capabilities.
     *
     * @return string[]
     */
    public static function all_caps() {
        return array(
            self::CAP_MANAGE_SUITE,
            self::CAP_MANAGE_LICENSES,
            self::CAP_VIEW_REPORTS,
            self::CAP_MANAGE_SECURITY,
            self::CAP_MANAGE_PERFORMANCE,
        );
    }

    /**
     * Back-compat helper.
     */
    public static function user_can_manage_suite() {
        return current_user_can( self::CAP_MANAGE_SUITE ) || current_user_can( 'manage_options' );
    }

    public static function user_can_manage_licenses() {
        return current_user_can( self::CAP_MANAGE_LICENSES ) || current_user_can( 'manage_options' );
    }

    /**
     * Ensure admin role has SAEC caps (runs on init to cover updates without re-activation).
     */
    public static function ensure_admin_caps() {
        $role = get_role( 'administrator' );
        if ( ! $role ) {
            return;
        }
        foreach ( self::all_caps() as $cap ) {
            if ( ! $role->has_cap( $cap ) ) {
                $role->add_cap( $cap );
            }
        }
    }

    /**
     * Activation hook.
     */
    public static function activate() {
        self::ensure_admin_caps();
    }
}
