<?php
/**
 * SAEC Control Center – Marketplace client.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SAEC_Core_Marketplace {


/**
 * Normalize and decode JSON safely (tolerates BOM, leading backslash, double-encoded JSON).
 *
 * @param string $body
 * @return array|null
 */
private static function decode_json_safe( $body ) {
    $raw = (string) $body;
    $raw = preg_replace( '/^\xEF\xBB\xBF/', '', $raw ); // UTF-8 BOM
    $raw = ltrim( $raw );

    // Some stacks may prefix the payload with a stray backslash before the JSON.
    if ( isset( $raw[0] ) && $raw[0] === '\\' ) {
        $raw = ltrim( substr( $raw, 1 ) );
    }

    $data = json_decode( $raw, true );

    // Fallback: double-encoded JSON (JSON string containing JSON)
    if ( ! is_array( $data ) && isset( $raw[0] ) && $raw[0] === '"' ) {
        $tmp = json_decode( $raw, true );
        if ( is_string( $tmp ) ) {
            $data = json_decode( $tmp, true );
        }
    }

    return is_array( $data ) ? $data : null;
}

/**
 * Extract modules list from decoded marketplace payload.
 *
 * Accepts:
 * - { modules: [...] }
 * - { items: [...] }
 * - { data: [...] }
 * - direct array: [ {...}, {...} ]
 *
 * @param array $data
 * @return array
 */
private static function extract_modules( $data ) {
    if ( isset( $data['modules'] ) && is_array( $data['modules'] ) ) {
        return $data['modules'];
    }
    if ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
        return $data['items'];
    }
    if ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
        return $data['data'];
    }
    if ( isset( $data[0] ) && is_array( $data[0] ) ) {
        return $data;
    }
    return array();
}

/**
 * Log a short diagnostic line for marketplace payload issues.
 *
 * @param string $prefix
 * @param string $endpoint
 * @param string $raw
 * @return void
 */
private static function log_marketplace_payload_issue( $prefix, $endpoint, $raw ) {
    $raw = (string) $raw;
    $raw = preg_replace( '/^\xEF\xBB\xBF/', '', $raw );
    $raw = ltrim( $raw );
    $head = substr( $raw, 0, 12 );
    $head_hex = bin2hex( $head );
    error_log(
        $prefix . ' ' . $endpoint .
        ' ; json_error=' . json_last_error_msg() .
        ' ; head_hex=' . $head_hex .
        ' ; body snippet: ' . substr( preg_replace( '/\s+/', ' ', $raw ), 0, 600 )
    );
}


    /**
     * Get catalogue from remote SAEC licence server.
     *
     * @return array{modules:array,error:string}
     */
    public static function get_catalog() {
        $result = array(
            'modules' => array(),
            'error'   => '',
        );

        if ( ! function_exists( 'saec_suite_get_license_info' ) ) {
            $result['error'] = __( 'SAEC Core not available. Licence information missing.', 'saec-core' );
            return $result;
        }

        $license_info = saec_suite_get_license_info();

        $endpoint = '';
        // Prefer endpoint from licence info when available.
        if ( empty( $endpoint ) ) {
            $endpoint = ( isset( $license_info['endpoint'] ) || isset( $license_info['api_endpoint'] ) )
                ? trim( (string) ( $license_info['endpoint'] ?? $license_info['api_endpoint'] ?? '' ) )
                : '';
        }
        if ( empty( $endpoint ) && function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
            $endpoint = saec_suite_get_license_api_endpoint();
        }

        if ( empty( $endpoint ) ) {
            $result['error'] = __(  'No SAEC licence API endpoint configured. Marketplace cannot be loaded.', 'saec-core' );
            return $result;
        }

        $endpoint = rtrim( $endpoint, '/' ) . '/marketplace';

        $args = array(
            'timeout'     => 15,
            'redirection' => 3,
            'sslverify'   => false,
            'headers'     => array(
                'Accept'     => 'application/json, */*;q=0.1',
                'User-Agent' => 'Mozilla/5.0 (compatible; SAEC-ControlCenter/2.9.0; +' . home_url( '/' ) . ')',
                'Referer'    => home_url( '/' ),
            ),
        );

        $response = wp_remote_get( $endpoint, $args );

        if ( is_wp_error( $response ) ) {
            error_log( '[SAEC_CC Marketplace] WP_Error on GET ' . $endpoint . ' : ' . $response->get_error_message() );
            $result['error'] = sprintf(
                /* translators: %s: error message */
                __( 'Unable to contact SAEC Marketplace: %s', 'saec-core' ),
                $response->get_error_message()
            );
            return $result;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            error_log(
                '[SAEC_CC Marketplace] HTTP ' . $code . ' from ' . $endpoint . ' ; body snippet: ' .
                substr( preg_replace( '/\s+/', ' ', $body ), 0, 600 )
            );
            $result['error'] = sprintf(
                /* translators: %d: HTTP status code */
                __( 'SAEC Marketplace responded with HTTP %d.', 'saec-core' ),
                $code
            );
            return $result;
        }

        
$data = self::decode_json_safe( $body );

if ( null === $data ) {
    self::log_marketplace_payload_issue( '[SAEC_CC Marketplace] Invalid JSON from', $endpoint, $body );
    $result['error'] = __( 'Invalid response from SAEC Marketplace (JSON decode failed).', 'saec-core' );
    return $result;
}

$modules = self::extract_modules( $data );

if ( empty( $modules ) ) {
    self::log_marketplace_payload_issue( '[SAEC_CC Marketplace] Unexpected JSON structure from', $endpoint, $body );
    $result['error'] = __( 'Invalid response format from SAEC Marketplace.', 'saec-core' );
    return $result;
}

$result['modules'] = $modules;

        return $result;
    }

    /**
     * Install or update a module by slug via licence server.
     *
     * @param string $slug Plugin slug (e.g. saec-perf/saec-perf.php).
     * @return true|WP_Error
     */
    public static function install_or_update( $slug ) {
        // Safe Mode: never install/update when enabled.
        if ( function_exists( 'saec_suite_is_safe_mode' ) && saec_suite_is_safe_mode() ) {
            return new WP_Error( 'saec_safe_mode', __( 'Safe Mode is enabled. Installs and updates are disabled.', 'saec-core' ), array( 'status' => 423 ) );
        }

        if ( ! function_exists( 'saec_suite_get_license_info' ) ) {
            return new WP_Error(
                'saec_cc_no_core',
                __( 'SAEC Core not available. Licence information missing.', 'saec-core' )
            );
        }

        $license_info = saec_suite_get_license_info();

        $endpoint = '';
        if ( empty( $endpoint ) ) {
            $endpoint = $license_info['endpoint'] ?? ( $license_info['api_endpoint'] ?? '' );
        }
        // Never fallback to the local site's /wp-json/saec-license/v1 on client sites.
        if ( empty( $endpoint ) && function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
            $endpoint = saec_suite_get_license_api_endpoint();
        }
        if ( empty( $endpoint ) ) {
            return new WP_Error(
                'saec_cc_no_endpoint',
                __( 'No SAEC licence API endpoint configured.', 'saec-core' )
            );
        }

        $download_endpoint = rtrim( $endpoint, '/' ) . '/marketplace/download';

        $args = array(
            'timeout'     => 20,
            'redirection' => 3,
            'sslverify'   => false,
            'headers'     => array(
                'Accept'     => 'application/json, */*;q=0.1',
                'User-Agent' => 'Mozilla/5.0 (compatible; SAEC-ControlCenter/2.9.0; +' . home_url( '/' ) . ')',
                'Referer'    => home_url( '/' ),
            ),
            'body'        => array(
                'slug'     => $slug,
                'site_url' => home_url(),
            ),
        );

        $response = wp_remote_post( $download_endpoint, $args );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'saec_cc_http_error',
                sprintf(
                    /* translators: %s: error message */
                    __( 'Error contacting licence server: %s', 'saec-core' ),
                    $response->get_error_message()
                )
            );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error(
                'saec_cc_http_status',
                sprintf(
                    /* translators: %d: HTTP status code */
                    __( 'Licence server returned HTTP %d while requesting package URL.', 'saec-core' ),
                    $code
                )
            );
        }

        $data = self::decode_json_safe( $body );
        if ( ! is_array( $data ) || empty( $data['download_url'] ) ) {
            return new WP_Error(
                'saec_cc_bad_payload',
                __( 'Invalid response from licence server while requesting package URL.', 'saec-core' )
            );
        }

        $download_url = esc_url_raw( $data['download_url'] );

        if ( empty( $download_url ) ) {
            return new WP_Error(
                'saec_cc_empty_url',
                __( 'Empty package URL received from licence server.', 'saec-core' )
            );
        }

        if ( ! function_exists( 'download_url' ) || ! function_exists( 'WP_Filesystem' ) || ! function_exists( 'unzip_file' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // Download package to a temp file using WP HTTP API so we can pass headers (Cloudflare/WAF compatible),
// then validate it is a real ZIP before unzipping.
$tmp_file = wp_tempnam( $download_url );
if ( ! $tmp_file ) {
    return new WP_Error( 'saec_cc_tmp_failed', __( 'Unable to create temporary file for download.', 'saec-core' ) );
}

$download_headers = array(
    'Accept'     => 'application/zip, application/octet-stream, */*;q=0.1',
    // Use a very common UA to avoid overly strict WAF rules.
    'User-Agent' => 'Mozilla/5.0 (compatible; SAEC-ControlCenter/2.9.3; +' . home_url( '/' ) . ')',
    'Referer'    => home_url( '/' ),
);

// Licence token (SAEC Core stores SHA-512 hash only; send it in multiple header names for compatibility).
$license_token = '';
if ( is_array( $license_info ) ) {
    $license_token = (string) ( $license_info['license_key'] ?? $license_info['license_hash'] ?? $license_info['license_key_hash'] ?? '' );
}
if ( ! empty( $license_token ) ) {
    $download_headers['X-SAEC-Token']        = $license_token;
    $download_headers['X-SAEC-License']      = $license_token;
    $download_headers['X-SAEC-License-Hash'] = $license_token;
    $download_headers['Authorization']       = 'Bearer ' . $license_token;
}

// Also send the package token (query param) in a header, for servers that require it.
$package_token = '';
$parsed_url    = wp_parse_url( $download_url );
if ( is_array( $parsed_url ) && ! empty( $parsed_url['query'] ) ) {
    parse_str( $parsed_url['query'], $qv );
    if ( is_array( $qv ) && ! empty( $qv['token'] ) ) {
        $package_token = (string) $qv['token'];
    }
}
if ( ! empty( $package_token ) ) {
    $download_headers['X-SAEC-Package-Token'] = $package_token;
}

// Debug: log which auth headers are present (do not log token value).
error_log( '[SAEC_CC Marketplace] package download headers: token=' . ( empty( $license_token ) ? '0' : '1' ) . ' package_token=' . ( empty( $package_token ) ? '0' : '1' ) );

$dl = wp_remote_get( $download_url, array(
    'timeout'     => 300,
    'redirection' => 5,
    'sslverify'   => false,
    'headers'     => $download_headers,
    'stream'      => true,
    'filename'    => $tmp_file,
) );

if ( is_wp_error( $dl ) ) {
    @unlink( $tmp_file );
    error_log( '[SAEC_CC Marketplace] download failed for ' . $download_url . ' : ' . $dl->get_error_message() );
    return new WP_Error(
        'saec_cc_download_failed',
        sprintf( __( 'Download failed: %s', 'saec-core' ), $dl->get_error_message() )
    );
}

$dl_code = (int) wp_remote_retrieve_response_code( $dl );

if ( $dl_code < 200 || $dl_code >= 300 ) {

        if ( $dl_code === 403 ) {
            // Retry once with a different UA header (some WAF rules are UA-sensitive).
            $retry_headers = $download_headers;
            $retry_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

            $dl_retry = wp_remote_get( $download_url, array(
                'timeout'     => 300,
                'redirection' => 5,
                'sslverify'   => false,
                'headers'     => $retry_headers,
                'stream'      => true,
                'filename'    => $tmp_file,
            ) );

            if ( ! is_wp_error( $dl_retry ) ) {
                $dl       = $dl_retry;
                $dl_code  = (int) wp_remote_retrieve_response_code( $dl_retry );
            }
        }


    $dl_body = (string) wp_remote_retrieve_body( $dl );
    @unlink( $tmp_file );
    error_log( '[SAEC_CC Marketplace] download HTTP ' . $dl_code . ' for ' . $download_url . ' ; body snippet: ' . substr( preg_replace( '/\s+/', ' ', $dl_body ), 0, 600 ) );
    return new WP_Error(
        'saec_cc_download_http',
        sprintf( __( 'Download returned HTTP %d.', 'saec-core' ), $dl_code )
    );
}

// Validate ZIP signature "PK" in the downloaded file (streamed).
$fh  = @fopen( $tmp_file, 'rb' );
$sig = $fh ? fread( $fh, 2 ) : '';
if ( $fh ) {
    fclose( $fh );
}

if ( $sig !== 'PK' ) {
    $dl_body = (string) wp_remote_retrieve_body( $dl );
    $snippet = substr( preg_replace( '/\s+/', ' ', $dl_body ), 0, 600 );
    @unlink( $tmp_file );
    error_log( '[SAEC_CC Marketplace] downloaded file is not a ZIP for ' . $download_url . ' ; sig=' . bin2hex( (string) $sig ) . ' ; body snippet: ' . $snippet );
    return new WP_Error(
        'saec_cc_not_zip',
        __( 'Downloaded package is not a ZIP archive (blocked or invalid response).', 'saec-core' )
    );
}

// Optional checksum verification (sha256) when provided by the licence server.
$expected_sha256 = '';
if ( is_array( $data ) && ! empty( $data['sha256'] ) ) {
    $expected_sha256 = strtolower( preg_replace( '/[^a-f0-9]/i', '', (string) $data['sha256'] ) );
}
if ( empty( $expected_sha256 ) ) {
    $dl_headers = wp_remote_retrieve_headers( $dl );
    if ( is_array( $dl_headers ) ) {
        $h = $dl_headers['x-saec-package-sha256'] ?? ( $dl_headers['X-SAEC-Package-SHA256'] ?? '' );
        if ( ! empty( $h ) ) {
            $expected_sha256 = strtolower( preg_replace( '/[^a-f0-9]/i', '', (string) $h ) );
        }
    }
}
if ( ! empty( $expected_sha256 ) && function_exists( 'hash_file' ) ) {
    $actual_sha256 = strtolower( (string) hash_file( 'sha256', $tmp_file ) );
    if ( $actual_sha256 !== $expected_sha256 ) {
        @unlink( $tmp_file );
        error_log( '[SAEC_CC Marketplace] sha256 mismatch for ' . $download_url . ' expected=' . $expected_sha256 . ' actual=' . $actual_sha256 );
        return new WP_Error(
            'saec_cc_sha256_mismatch',
            __( 'Downloaded package checksum verification failed (sha256 mismatch).', 'saec-core' )
        );
    }
}


$fs_init = WP_Filesystem();

        
        if ( ! $fs_init ) {
            @unlink( $tmp_file );
            error_log( '[SAEC_CC Marketplace] WP_Filesystem could not be initialised.' );
            return new WP_Error(
                'saec_cc_fs_unavailable',
                __( 'WordPress filesystem API could not be initialised. Check FS_METHOD/credentials.', 'saec-core' )
            );
        }

        $result = unzip_file( $tmp_file, WP_PLUGIN_DIR );
        @unlink( $tmp_file );

        if ( is_wp_error( $result ) ) {
            error_log( '[SAEC_CC Marketplace] unzip_file failed: ' . $result->get_error_message() );
            return new WP_Error(
                'saec_cc_unzip_failed',
                sprintf(
                    /* translators: %s: error message */
                    __( 'Plugin installation failed: %s', 'saec-core' ),
                    $result->get_error_message()
                )
            );
        }

        $plugin_file = $slug;

        $all_plugins = get_plugins();

        if ( isset( $all_plugins[ $plugin_file ] ) ) {
            $activate = activate_plugin( $plugin_file );
            if ( is_wp_error( $activate ) ) {
                error_log( '[SAEC_CC Marketplace] activate_plugin failed for ' . $plugin_file . ' : ' . $activate->get_error_message() );
                return new WP_Error(
                    'saec_cc_activate_failed',
                    sprintf(
                        /* translators: 1: slug, 2: error message */
                        __( 'Plugin installed but activation failed for %1$s: %2$s', 'saec-core' ),
                        $plugin_file,
                        $activate->get_error_message()
                    )
                );
            }
        }

        return true;
    }
}
