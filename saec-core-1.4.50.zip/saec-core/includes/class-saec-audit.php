<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class SAEC_Audit {
    const OPTION_KEY = 'saec_audit_log';
    const MAX_ENTRIES = 500;

    public static function log( $action, $details = array(), $level = 'info' ) {
        $action = is_string( $action ) ? sanitize_key( $action ) : '';
        if ( empty( $action ) ) { return; }

        $user = wp_get_current_user();
        $uid  = $user && $user->exists() ? (int) $user->ID : 0;
        $uname = $user && $user->exists() ? $user->user_login : 'guest';

        $ip = '';
        if ( isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) && is_string( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
        } elseif ( isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
        }

        $entry = array(
            'ts'      => time(),
            'action'  => $action,
            'level'   => is_string( $level ) ? sanitize_key( $level ) : 'info',
            'user_id' => $uid,
            'user'    => $uname,
            'ip'      => $ip,
            'details' => is_array( $details ) ? $details : array(),
        );

        $log = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $log ) ) { $log = array(); }

        array_unshift( $log, $entry );
        if ( count( $log ) > self::MAX_ENTRIES ) {
            $log = array_slice( $log, 0, self::MAX_ENTRIES );
        }

        update_option( self::OPTION_KEY, $log, false );
    }

    public static function get( $limit = 200 ) {
        $limit = absint( $limit );
        if ( $limit < 1 ) { $limit = 1; }
        if ( $limit > self::MAX_ENTRIES ) { $limit = self::MAX_ENTRIES; }

        $log = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $log ) ) { return array(); }

        return array_slice( $log, 0, $limit );
    }

    public static function clear() {
        update_option( self::OPTION_KEY, array(), false );
    }

    public static function bundle( $limit = 500 ) {
        return array(
            'count'   => count( self::get( self::MAX_ENTRIES ) ),
            'entries' => self::get( $limit ),
        );
    }
}
