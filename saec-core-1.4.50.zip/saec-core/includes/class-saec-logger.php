<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class SAEC_Logger {

    const OPTION_KEY = 'saec_suite_logs';
    const MAX_ENTRIES = 500;

    /**
     * Log an event.
     *
     * @param string $level info|warning|error|critical
     * @param string $message
     * @param array  $context
     * @return void
     */
    public static function log( $level, $message, $context = array() ) {
        $level   = is_string( $level ) ? strtolower( $level ) : 'info';
        $message = is_string( $message ) ? $message : '';
        $context = is_array( $context ) ? $context : array();

        $entry = array(
            'ts'      => time(),
            'level'   => in_array( $level, array( 'info', 'warning', 'error', 'critical' ), true ) ? $level : 'info',
            'message' => $message,
            'context' => $context,
            'user'    => get_current_user_id(),
        );

        $logs = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $logs ) ) {
            $logs = array();
        }
        $logs[] = $entry;

        $excess = count( $logs ) - self::MAX_ENTRIES;
        if ( $excess > 0 ) {
            $logs = array_slice( $logs, $excess );
        }

        update_option( self::OPTION_KEY, $logs, false );

        // Optional file log in uploads/saec/logs/saec-suite.log (best-effort).
        $upload = wp_upload_dir( null, false );
        $basedir = isset( $upload['basedir'] ) ? $upload['basedir'] : '';
        if ( is_string( $basedir ) && $basedir ) {
            $dir = trailingslashit( $basedir ) . 'saec/logs/';
            if ( ! file_exists( $dir ) ) {
                wp_mkdir_p( $dir );
            }
            $file = $dir . 'saec-suite.log';
            $line = sprintf(
                "[%s] %s: %s %s\n",
                gmdate( 'Y-m-d H:i:s', $entry['ts'] ),
                strtoupper( $entry['level'] ),
                $entry['message'],
                $context ? wp_json_encode( $context ) : ''
            );
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen
            @file_put_contents( $file, $line, FILE_APPEND );
        }
    }

    /**
     * Get log entries.
     *
     * @param int $limit
     * @return array
     */
    public static function get( $limit = 100 ) {
        $limit = absint( $limit );
        if ( $limit <= 0 ) {
            $limit = 100;
        }
        $logs = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $logs ) ) {
            return array();
        }
        return array_slice( array_reverse( $logs ), 0, min( $limit, self::MAX_ENTRIES ) );
    }

    public static function clear() {
        update_option( self::OPTION_KEY, array(), false );
    }
}
