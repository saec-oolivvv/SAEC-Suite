<?php
/**
 * Plugin Name: SAEC Core
 * Description: Core client plugin for SAEC Suite (license validation, marketplace, module gating).
 * Version: 1.4.50
 * Author: SAEC
 * Author URI: https://saec.me
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: saec-core
 * Domain Path: /languages
 */

/**
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// -----------------------------------------------------------------------------
// Constants.
// -----------------------------------------------------------------------------

// IMPORTANT: keep this in sync with the plugin header Version.
if ( ! defined( 'SAEC_CORE_VERSION' ) ) {
    define( 'SAEC_CORE_VERSION', '1.4.50' );

}

if ( ! defined( 'SAEC_CORE_PLUGIN_FILE' ) ) {
    define( 'SAEC_CORE_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'SAEC_CORE_PLUGIN_DIR' ) ) {
    define( 'SAEC_CORE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'SAEC_CORE_PLUGIN_URL' ) ) {
    define( 'SAEC_CORE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Licence API endpoint (can be overridden in wp-config.php).
 */
if ( ! defined( 'SAEC_LICENSE_API_ENDPOINT' ) ) {
    define( 'SAEC_LICENSE_API_ENDPOINT', 'https://saec.me/wp-json/saec-license/v1/' );
}

// Default endpoint (always available even if SAEC_LICENSE_API_ENDPOINT was pre-defined elsewhere).
if ( ! defined( 'SAEC_LICENSE_API_ENDPOINT_DEFAULT' ) ) {
    define( 'SAEC_LICENSE_API_ENDPOINT_DEFAULT', 'https://saec.me/wp-json/saec-license/v1/' );
}

/**
 * Returns the SAEC licence API endpoint to use.
 * - Uses option override when set.
 * - Falls back to SAEC_LICENSE_API_ENDPOINT_DEFAULT.
 * - Ignores a pre-defined SAEC_LICENSE_API_ENDPOINT when it points to the current site.
 */
function saec_suite_get_license_api_endpoint() {
    $default = defined( 'SAEC_LICENSE_API_ENDPOINT_DEFAULT' ) ? (string) SAEC_LICENSE_API_ENDPOINT_DEFAULT : 'https://saec.me/wp-json/saec-license/v1/';

    $home_host = parse_url( home_url(), PHP_URL_HOST );

    // Optional override stored in settings. Ignore misconfigurations pointing to the current site licence namespace.
    $opts = get_option( 'saec_suite_options', array() );
    // Also support legacy/Control Center storage.
    $cc_opts = get_option( 'saec_cc_options', array() );
    if ( is_array( $cc_opts ) && empty( $opts['license_api_endpoint'] ) && ! empty( $cc_opts['license_api_endpoint'] ) ) {
        $opts['license_api_endpoint'] = $cc_opts['license_api_endpoint'];
    }
    if ( is_array( $opts ) && ! empty( $opts['license_api_endpoint'] ) && is_string( $opts['license_api_endpoint'] ) ) {
        $ep = trim( $opts['license_api_endpoint'] );
        if ( $ep !== '' && filter_var( $ep, FILTER_VALIDATE_URL ) ) {
            $ep_host = parse_url( $ep, PHP_URL_HOST );
            $ep_path = (string) parse_url( $ep, PHP_URL_PATH );

            // If someone accidentally set the endpoint to the current site (/wp-json/saec-license/v1), ignore it.
            if ( $ep_host && $home_host && strtolower( $ep_host ) === strtolower( $home_host ) ) {
                if ( strpos( rtrim( $ep_path, '/' ), '/wp-json/saec-license/v1' ) !== false ) {
                    // fall through to default/constant
                } else {
                    return trailingslashit( $ep );
                }
            } else {
                return trailingslashit( $ep );
            }
        }
    }

    // If the constant was defined elsewhere, only use it when it does NOT point to the current site (avoid misconfiguration).
    if ( defined( 'SAEC_LICENSE_API_ENDPOINT' ) ) {
        $ep = trim( (string) SAEC_LICENSE_API_ENDPOINT );
        if ( $ep !== '' && filter_var( $ep, FILTER_VALIDATE_URL ) ) {
            $ep_host = parse_url( $ep, PHP_URL_HOST );
            if ( $ep_host && $home_host && strtolower( $ep_host ) !== strtolower( $home_host ) ) {
                return trailingslashit( $ep );
            }
        }
    }

    return trailingslashit( $default );
}


// -----------------------------------------------------------------------------
// Includes.
// -----------------------------------------------------------------------------

require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-license-manager.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-capabilities.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-registry.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-logger.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-events.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-audit.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-core.php';
require_once SAEC_CORE_PLUGIN_DIR . 'admin/class-saec-core-admin.php';
require_once SAEC_CORE_PLUGIN_DIR . 'includes/class-saec-core-marketplace.php';
require_once SAEC_CORE_PLUGIN_DIR . 'admin/class-saec-core-control-center.php';

// -----------------------------------------------------------------------------
// Activation / deactivation hooks.
// -----------------------------------------------------------------------------

function saec_core_activate() {
    if ( class_exists( 'SAEC_Capabilities' ) ) {
        SAEC_Capabilities::activate();
    }

    if ( ! wp_next_scheduled( 'saec_core_cron_license_validate' ) ) {
        // First run one hour after activation, then twice daily.
        wp_schedule_event( time() + HOUR_IN_SECONDS, 'twicedaily', 'saec_core_cron_license_validate' );
    }

    saec_core_ping_license_server( 'activate', true );
}
register_activation_hook( __FILE__, 'saec_core_activate' );
add_action( 'upgrader_process_complete', 'saec_core_after_upgrade', 10, 2 );

function saec_core_deactivate() {
    $timestamp = wp_next_scheduled( 'saec_core_cron_license_validate' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'saec_core_cron_license_validate' );
    }
}
register_deactivation_hook( __FILE__, 'saec_core_deactivate' );

// -----------------------------------------------------------------------------
// Bootstrap.
// -----------------------------------------------------------------------------

function saec_core_bootstrap() {
    // Instantiate core controller.
    new SAEC_Core();
    if ( class_exists( 'SAEC_Core_Control_Center' ) ) {
        $cc = new SAEC_Core_Control_Center();
        $cc->hooks();
    }

}
add_action( 'plugins_loaded', 'saec_core_bootstrap', 5 );

// Auto-fix misconfigured licence endpoint stored on the client site.
add_action( 'init', function() {
    $opts = get_option( 'saec_suite_options', array() );
    if ( ! is_array( $opts ) ) {
        return;
    }
    if ( empty( $opts['license_api_endpoint'] ) || ! is_string( $opts['license_api_endpoint'] ) ) {
        return;
    }

    $ep = trim( $opts['license_api_endpoint'] );
    if ( $ep === '' || ! filter_var( $ep, FILTER_VALIDATE_URL ) ) {
        return;
    }

    $home_host = parse_url( home_url(), PHP_URL_HOST );
    $ep_host   = parse_url( $ep, PHP_URL_HOST );
    $ep_path   = (string) parse_url( $ep, PHP_URL_PATH );

    if ( $home_host && $ep_host && strtolower( $home_host ) === strtolower( $ep_host ) ) {
        if ( strpos( rtrim( $ep_path, '/' ), '/wp-json/saec-license/v1' ) !== false ) {
            unset( $opts['license_api_endpoint'] );
            update_option( 'saec_suite_options', $opts, false );
        }
    }
}, 1 );
// -----------------------------------------------------------------------------
// Global helper functions for other SAEC Suite modules.
// -----------------------------------------------------------------------------

/**
 * Shortcut to access the licence manager singleton.
 *
 * @return SAEC_License_Manager
 */
if ( ! function_exists( 'saec_suite_license_manager' ) ) {
    function saec_suite_license_manager() {
        return SAEC_License_Manager::instance();
    }
}

/**
 * Get current suite tier (basic | pro | agency | none).
 *
 * @return string
 */
if ( ! function_exists( 'saec_suite_get_tier' ) ) {
    function saec_suite_get_tier() {
        $tier = get_option( 'saec_suite_tier', null );
        if ( null !== $tier ) {
            return $tier;
        }
        $manager = SAEC_License_Manager::instance();
        return method_exists( $manager, 'get_tier' ) ? $manager->get_tier() : 'basic';
    }
}

/**
 * Global lockdown flag (true when all modules must be disabled).
 *
 * @return bool
 */
if ( ! function_exists( 'saec_suite_is_lockdown' ) ) {
    function saec_suite_is_lockdown() {
        $lock = get_option( 'saec_suite_lockdown', null );
        if ( null !== $lock ) {
            return (bool) $lock;
        }
        $manager = SAEC_License_Manager::instance();
        return method_exists( $manager, 'is_lockdown' ) ? $manager->is_lockdown() : false;
    }
}

/**
 * Convenience helper returning all licence info in one array.
 *
 * @return array
 */
/**
 * Safe Mode flag (disables risky actions in production).
 *
 * @return bool
 */
if ( ! function_exists( 'saec_suite_is_safe_mode' ) ) {
    function saec_suite_is_safe_mode() {
        $opts = get_option( 'saec_suite_options', array() );
        if ( ! is_array( $opts ) ) {
            return false;
        }
        return ! empty( $opts['safe_mode'] );
    }
}

if ( ! function_exists( 'saec_suite_get_license_info' ) ) {
    function saec_suite_get_license_info() {
        $manager = SAEC_License_Manager::instance();

        $info = array(
            // NOTE: this is the SHA-512 hash only (never store or expose the plaintext key).
            'license_key'  => $manager->get_license_key(),
            'status'       => $manager->get_status(), // active|expired|invalid|none|inactive
            'tier'         => $manager->get_tier(),   // basic|pro|agency|none
            'lockdown'     => $manager->is_lockdown(),
            'expires_at'   => $manager->get_expires_at(),
            'endpoint'     => function_exists( 'saec_suite_get_license_api_endpoint' ) ? saec_suite_get_license_api_endpoint() : '',
            'last_check'   => (int) $manager->get_last_check(),
            'source'       => method_exists( $manager, 'get_source' ) ? $manager->get_source() : 'cache',
            'message'      => $manager->get_message(),
            'purchase_url' => $manager->get_purchase_url(),
            // Context.
            'email'        => get_bloginfo( 'admin_email' ),
            'site_url'     => home_url(),
        );

        /**
         * Filter licence info exposed to SAEC Suite modules.
         *
         * @param array $info Array of licence information.
         */
        return apply_filters( 'saec_suite_license_info', $info );
    }
}




add_action( 'admin_notices', function () {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    if ( ! function_exists( 'is_plugin_active' ) ) { include_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'saec-control-center/saec-control-center.php' ) ) {
        echo '<div class="notice notice-warning"><p><strong>SAEC:</strong> Control Center is now integrated into SAEC Core. Please deactivate <code>SAEC Control Center</code> to avoid duplicate menus.</p></div>';
    }
} );


/**
 * Ping SAEC License Server to report installation.
 *
 * @param string $context activate|update|daily|manual
 * @param bool   $force   bypass rate limit
 * @return void
 */
/**
 * Resolve SAEC licence server base endpoint.
 *
 * Priority:
 * 1) saec_suite_get_license_api_endpoint() if available
 * 2) SAEC_LICENSE_API_ENDPOINT constant if defined
 * 3) Default to https://saec.me/wp-json/saec-license/v1/
 *
 * @return string
 */
function saec_core_resolve_license_api_base() {
    $default = 'https://saec.me/wp-json/saec-license/v1/';
    if ( function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
        $ep = (string) saec_suite_get_license_api_endpoint();
        if ( '' !== trim( $ep ) ) {
            return $ep;
        }
    }
    if ( defined( 'SAEC_LICENSE_API_ENDPOINT' ) ) {
        $ep = (string) SAEC_LICENSE_API_ENDPOINT;
        if ( '' !== trim( $ep ) ) {
            return $ep;
        }
    }
    return $default;
}

/**
 * Ping SAEC License Server to report installation.
 *
 * @param string $context activate|update|daily|manual
 * @param bool   $force   bypass rate limit
 * @return void
 */
function saec_core_ping_license_server( $context = 'manual', $force = false ) {
    $context = sanitize_key( (string) $context );
    $last    = (int) get_option( 'saec_core_last_license_ping', 0 );

    // Rate-limit: at most once every 12 hours unless forced.
    if ( ! $force && $last > 0 && ( time() - $last ) < ( 12 * HOUR_IN_SECONDS ) ) {
        return;
    }

    $base = saec_core_resolve_license_api_base();
    $endpoint = trailingslashit( $base ) . 'ping';

    // Gather identifiers.
    $instance_id = '';
    $machine_id  = '';
    if ( class_exists( 'SAEC_License_Manager' ) ) {
        $lm = SAEC_License_Manager::instance();
        if ( method_exists( $lm, 'get_instance_id' ) ) {
            $instance_id = (string) $lm->get_instance_id();
        }
        if ( method_exists( $lm, 'get_machine_id' ) ) {
            $machine_id = (string) $lm->get_machine_id();
        }
    }

    $site_url = home_url();
    $hostname = (string) wp_parse_url( $site_url, PHP_URL_HOST );

    $payload = array(
        'context'          => $context,
        'site_url'         => $site_url,
        'hostname'         => $hostname,
        'site_fingerprint' => $instance_id,
        'machine_id'       => $machine_id,
        'core_version'     => defined( 'SAEC_CORE_VERSION' ) ? SAEC_CORE_VERSION : '',
        'wp_version'       => get_bloginfo( 'version' ),
        'php_version'      => PHP_VERSION,
        'admin_email'      => get_bloginfo( 'admin_email' ),
        'ts'               => time(),
    );

    $args = array(
        'timeout' => 10,
        'headers' => array(
            'Content-Type' => 'application/json; charset=utf-8',
        ),
        'body'    => wp_json_encode( $payload ),
    );

    $resp = wp_remote_post( $endpoint, $args );

    if ( is_wp_error( $resp ) ) {
        // Keep a short diagnostic for the Health screen (optional).
        update_option( 'saec_core_last_license_ping_error', $resp->get_error_message(), false );
        return;
    }

    update_option( 'saec_core_last_license_ping', time(), false );
    delete_option( 'saec_core_last_license_ping_error' );
}

/**
 * Hook: after plugin upgrade.
 *
 * @param WP_Upgrader $upgrader
 * @param array       $options
 * @return void
 */
function saec_core_after_upgrade( $upgrader, $options ) {
    if ( empty( $options['type'] ) || 'plugin' !== $options['type'] ) {
        return;
    }
    if ( empty( $options['plugins'] ) || ! is_array( $options['plugins'] ) ) {
        return;
    }
    $target = plugin_basename( __FILE__ );
    // plugin_basename(__FILE__) here returns 'saec-core/saec-core.php'
    if ( in_array( $target, $options['plugins'], true ) ) {
        saec_core_ping_license_server( 'update', true );
    }
}



/**
 * Ping license server at most once per day when an admin visits wp-admin.
 *
 * @return void
 */
function saec_core_maybe_daily_ping() {
    $last = (int) get_option( 'saec_core_last_license_ping', 0 );
    if ( $last > 0 && ( time() - $last ) < DAY_IN_SECONDS ) {
        return;
    }
    saec_core_ping_license_server( 'daily', false );
}
add_action( 'admin_init', 'saec_core_maybe_daily_ping' );

