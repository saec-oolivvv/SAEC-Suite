<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SAEC_Core_Admin {

    /**
     * Render SAEC Suite dashboard: licence overview + SAEC modules list.
     */
    public static function render_dashboard_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $manager      = SAEC_License_Manager::instance();
        $status       = $manager->get_status();
        $tier         = $manager->get_tier();
        $lockdown     = $manager->is_lockdown();
        $expires      = $manager->get_expires_at();
        $endpoint     = function_exists( 'saec_suite_get_license_api_endpoint' ) ? saec_suite_get_license_api_endpoint() : '';
        $purchase_url = $manager->get_purchase_url();

        // Public plans (catalogue) from licence server.
        $plans_payload = array( 'ok' => false, 'plans' => array() );
        if ( method_exists( $manager, 'get_public_plans' ) ) {
            $plans_payload = $manager->get_public_plans();
        }
        $public_plans = ( isset( $plans_payload['plans'] ) && is_array( $plans_payload['plans'] ) ) ? $plans_payload['plans'] : array();

        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = get_plugins();
        $saec_plugins = array();

        foreach ( $all_plugins as $file => $data ) {
            $slug   = dirname( $file );
            $author = isset( $data['Author'] ) ? $data['Author'] : '';

            // Heuristic: SAEC module = directory name starts with "saec-" OR author contains "SAEC".
            if ( 0 === strpos( $slug, 'saec-' ) || false !== stripos( $author, 'saec' ) ) {
                $saec_plugins[ $file ] = $data;
            }
        }

        
        // Plugins update data.
        $updates = get_site_transient( 'update_plugins' );
        $updates_response = ( is_object( $updates ) && isset( $updates->response ) && is_array( $updates->response ) ) ? $updates->response : array();

$nonce = wp_create_nonce( 'saec_toggle_module' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'SAEC Suite Dashboard', 'saec-core' ); ?></h1>
            <p><?php esc_html_e( 'Global status of the SAEC Suite licence and modules on this site.', 'saec-core' ); ?></p>

            <h2><?php esc_html_e( 'Licence overview', 'saec-core' ); ?></h2>
            <table class="widefat striped">
                <tbody>
                <tr>
                    <th><?php esc_html_e( 'Current status', 'saec-core' ); ?></th>
                    <td>
                        <?php
                        if ( 'active' === $status ) {
                            esc_html_e( 'Active', 'saec-core' );
                        } elseif ( 'expired' === $status ) {
                            esc_html_e( 'Expired', 'saec-core' );
                        } elseif ( 'invalid' === $status ) {
                            esc_html_e( 'Invalid', 'saec-core' );
                        } elseif ( 'none' === $status ) {
                            esc_html_e( 'None (basic mode)', 'saec-core' );
                        } else {
                            echo esc_html( ucfirst( $status ) );
                        }

                        if ( $lockdown ) {
                            echo ' – ';
                            esc_html_e( 'LOCKED', 'saec-core' );
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Tier', 'saec-core' ); ?></th>
                    <td><?php echo esc_html( $tier ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Lockdown', 'saec-core' ); ?></th>
                    <td>
                        <?php
                        if ( $lockdown ) {
                            esc_html_e( 'Yes – all SAEC modules are currently locked.', 'saec-core' );
                        } else {
                            esc_html_e( 'No – modules can run according to their tier.', 'saec-core' );
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Expires at', 'saec-core' ); ?></th>
                    <td><?php echo $expires ? esc_html( $expires ) : '—'; ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Instance ID', 'saec-core' ); ?></th>
                    <td><code><?php echo esc_html( $instance_id ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Machine ID', 'saec-core' ); ?></th>
                    <td><code><?php echo esc_html( $machine_id ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Licence API endpoint', 'saec-core' ); ?></th>
                    <td><?php echo esc_html( $endpoint ); ?></td>
                </tr>
                </tbody>
            </table>

            
            <?php if ( ! empty( $public_plans ) ) : ?>
                <h3 style="margin-top:18px;"><?php esc_html_e( 'Licence catalogue', 'saec-core' ); ?></h3>
                <div class="saec-cc-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:10px;">
                    <?php foreach ( $public_plans as $p ) :
                        $tier = isset( $p['tier'] ) ? sanitize_key( (string) $p['tier'] ) : '';
                        $label = isset( $p['label'] ) ? (string) $p['label'] : ucfirst( $tier );
                        $amount = isset( $p['amount'] ) ? (string) $p['amount'] : '0';
                        $currency = isset( $p['currency'] ) ? (string) $p['currency'] : 'EUR';
                        $interval = isset( $p['interval'] ) ? (string) $p['interval'] : 'year';
                        $sale_type = ( 'month' === $interval || 'monthly' === $interval ) ? 'monthly' : ( ( 'life' === $interval || 'lifetime' === $interval ) ? 'lifetime' : 'yearly' );
                        $features = isset( $p['features'] ) && is_array( $p['features'] ) ? $p['features'] : array();
                        $buy_url = wp_nonce_url(
                            add_query_arg(
                                array( 'action' => 'saec_create_checkout', 'tier' => $tier ),
                                admin_url( 'admin-post.php' )
                            ),
                            'saec_create_checkout'
                        );
                    ?>
                        <div class="saec-cc-card" style="border:1px solid rgba(0,0,0,.08);border-radius:12px;padding:14px;background:#fff;">
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
                                <div>
                                    <strong style="font-size:14px;"><?php echo esc_html( $label ); ?></strong><br/>
                                    <span style="font-size:20px;line-height:1.2;"><?php echo esc_html( $amount ); ?> <?php echo esc_html( $currency ); ?></span>
                                    <span style="opacity:.7;"> / <?php echo esc_html( $interval ); ?></span>
                                </div>
                                <span class="saec-badge" style="padding:4px 8px;border-radius:999px;background:rgba(0,0,0,.06);font-size:12px;"><?php echo esc_html( strtoupper( $tier ) ); ?></span>
                            </div>
                            <?php if ( ! empty( $features ) ) : ?>
                                <ul style="margin:10px 0 0 18px;">
                                    <?php foreach ( $features as $f ) : ?>
                                        <li style="margin:2px 0;"><?php echo esc_html( (string) $f ); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <p style="margin-top:12px;">
                                <a class="button button-primary" href="#" data-saec-checkout="1" data-tier="<?php echo esc_attr( $tier ); ?>" data-sale-type="<?php echo esc_attr( $sale_type ); ?>">
                                    <?php esc_html_e( 'Buy / upgrade', 'saec-core' ); ?>
                                </a>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <p style="margin-top:14px;opacity:.8;">
                    <?php esc_html_e( 'Licence catalogue is not available (server did not return plans).', 'saec-core' ); ?>
                </p>
            <?php endif; ?>

<?php if ( $purchase_url ) : ?>
                <p>
                    <a href="<?php echo esc_url( $purchase_url ); ?>" target="_blank" class="button button-primary">
                        <?php esc_html_e( 'Manage / upgrade licence', 'saec-core' ); ?>
                    </a>
                </p>
            <?php endif; ?>

            <hr />

            <h2><?php esc_html_e( 'SAEC modules on this site', 'saec-core' ); ?></h2>

            <?php if ( empty( $saec_plugins ) ) : ?>
                <p><?php esc_html_e( 'No SAEC modules were detected on this site.', 'saec-core' ); ?></p>
            <?php else : ?>
                <table class="widefat striped saec-modules-table">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'Module', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Version', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Update', 'saec-core' ); ?></th>
                        <th style="width: 120px; text-align: center;"><?php esc_html_e( 'On / Off', 'saec-core' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if ( ! function_exists( 'is_plugin_active' ) ) {
                        require_once ABSPATH . 'wp-admin/includes/plugin.php';
                    }

                    $core_basename = defined( 'SAEC_CORE_PLUGIN_FILE' ) ? plugin_basename( SAEC_CORE_PLUGIN_FILE ) : '';

                    foreach ( $saec_plugins as $file => $data ) :
                        $is_active = is_plugin_active( $file );
                        $row_class = $is_active ? 'saec-module-active' : 'saec-module-inactive';

                        $is_core = ( $core_basename && $file === $core_basename );
                        ?>
                        <tr class="<?php echo esc_attr( $row_class ); ?>">
                            <td>
                                <strong><?php echo esc_html( $data['Name'] ); ?></strong><br/>
                                <span class="description"><?php echo esc_html( $file ); ?></span>
                            </td>
                            <td class="saec-module-version">
                                <?php echo esc_html( isset( $data['Version'] ) ? $data['Version'] : '' ); ?>
                            </td>
                            <td class="saec-module-status-cell">
                                <?php if ( $lockdown ) : ?>
                                    <span class="saec-module-status saec-status-locked"><?php esc_html_e( 'Locked by licence', 'saec-core' ); ?></span>
                                <?php elseif ( $is_active ) : ?>
                                    <span class="saec-module-status saec-status-active"><?php esc_html_e( 'Active', 'saec-core' ); ?></span>
                                <?php else : ?>
                                    <span class="saec-module-status saec-status-inactive"><?php esc_html_e( 'Inactive', 'saec-core' ); ?></span>
                                <?php endif; ?>
                            </td>
                            
                            <td class="saec-module-update-cell">
                                <?php
                                $update_available = isset( $updates_response[ $file ] );
                                if ( $update_available ) {
                                    $update_url = wp_nonce_url(
                                        self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ),
                                        'upgrade-plugin_' . $file
                                    );
                                    ?>
                                    <a class="button button-small" href="<?php echo esc_url( $update_url ); ?>">
                                        <?php esc_html_e( 'Update', 'saec-core' ); ?>
                                    </a>
                                    <?php
                                } else {
                                    echo '—';
                                }
                                ?>
                            </td>
<td style="text-align: center;">
                                <?php if ( $lockdown ) : ?>
                                    <span class="dashicons dashicons-lock" title="<?php esc_attr_e( 'Locked by licence', 'saec-core' ); ?>"></span>
                                <?php elseif ( $is_core ) : ?>
                                    <span class="dashicons dashicons-admin-generic" title="<?php esc_attr_e( 'SAEC Core cannot be disabled here.', 'saec-core' ); ?>"></span>
                                <?php else : ?>
                                    <label class="saec-toggle-switch">
                                        <input type="checkbox"
                                               class="saec-suite-toggle"
                                               data-plugin="<?php echo esc_attr( $file ); ?>"
                                            <?php checked( $is_active ); ?> />
                                        <span class="saec-toggle-slider"></span>
                                    </label>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <style>
                    /* SAEC modules table: improved visual layout */
                    .saec-modules-table {
                        margin-top: 12px;
                        border-radius: 6px;
                        overflow: hidden;
                        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
                    }

                    .saec-modules-table th {
                        text-transform: uppercase;
                        font-size: 11px;
                        letter-spacing: 0.04em;
                    }

                    .saec-modules-table .saec-module-active td {
                        background-color: #f0f7ff;
                        border-left: 4px solid #2271b1;
                    }

                    .saec-modules-table .saec-module-inactive td {
                        background-color: #fcfcfc;
                        border-left: 4px solid #ccd0d4;
                    }

                    .saec-modules-table td:first-child strong {
                        font-size: 13px;
                    }

                    .saec-modules-table td:first-child .description {
                        color: #6c7781;
                        font-size: 11px;
                    }

                    .saec-module-status {
                        display: inline-flex;
                        align-items: center;
                        padding: 2px 8px;
                        border-radius: 999px;
                        font-size: 11px;
                        font-weight: 600;
                    }

                    .saec-status-active {
                        background-color: #e6f4ea;
                        color: #008a20;
                    }

                    .saec-status-inactive {
                        background-color: #f3f4f6;
                        color: #4b5563;
                    }

                    .saec-status-locked {
                        background-color: #fef3c7;
                        color: #92400e;
                    }

                    .saec-modules-table td.saec-module-version {
                        white-space: nowrap;
                    }

                    .saec-modules-table td.saec-module-status-cell {
                        width: 140px;
                    }


                    .saec-toggle-switch {
                        position: relative;
                        display: inline-block;
                        width: 46px;
                        height: 24px;
                    }

                    .saec-toggle-switch input {
                        opacity: 0;
                        width: 0;
                        height: 0;
                    }

                    .saec-toggle-slider {
                        position: absolute;
                        cursor: pointer;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background-color: #ccc;
                        transition: .2s;
                        border-radius: 24px;
                    }

                    .saec-toggle-slider:before {
                        position: absolute;
                        content: "";
                        height: 18px;
                        width: 18px;
                        left: 3px;
                        bottom: 3px;
                        background-color: #fff;
                        transition: .2s;
                        border-radius: 50%;
                    }

                    .saec-toggle-switch input:checked + .saec-toggle-slider {
                        background-color: #2271b1;
                    }

                    .saec-toggle-switch input:checked + .saec-toggle-slider:before {
                        transform: translateX(22px);
                    }
                </style>

                
            <?php endif; ?>
        </div>
        <?php self::render_checkout_modal(); ?>
        <?php
    }

    /**
     * Render licence management page.
     */

    /**
     * Render licence UI.
     *
     * @param bool $embedded If true, render without outer wrap/h1.
     */
    public static function render_license_panel( $embedded = false ) {
        if ( ! class_exists( 'SAEC_Capabilities' ) || ! SAEC_Capabilities::user_can_manage_licenses() ) {
            return;
        }

        $manager = SAEC_License_Manager::instance();
        $machine_id = method_exists( $manager, 'get_machine_id' ) ? $manager->get_machine_id() : '';
        $instance_id = method_exists( $manager, 'get_instance_id' ) ? $manager->get_instance_id() : '';
        $message = '';
        $error   = '';

        // Surface redirected purchase/checkout messages.
        // (The checkout handler redirects back to this panel with query args.)
        if ( isset( $_GET['saec_msg'] ) ) {
            $message = sanitize_text_field( wp_unslash( $_GET['saec_msg'] ) );
        }
        if ( isset( $_GET['saec_err'] ) ) {
            $error = sanitize_text_field( wp_unslash( $_GET['saec_err'] ) );
        }

        if ( isset( $_POST['saec_license_nonce'] ) && wp_verify_nonce( $_POST['saec_license_nonce'], 'saec_save_license' ) ) {
            $action = isset( $_POST['saec_license_action'] ) ? sanitize_key( $_POST['saec_license_action'] ) : '';

            if ( 'activate' === $action ) {
                $key = isset( $_POST['saec_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['saec_license_key'] ) ) : '';

                if ( '' === $key || '********' === $key ) {
                    $error = __( 'Please enter a valid licence key.', 'saec-core' );
                } else {
                    $result = $manager->activate( $key );
                    if ( is_wp_error( $result ) ) {
                        $error = $result->get_error_message();
                    } else {
                        $message = __( 'Licence activated successfully.', 'saec-core' );
                    }
                }
            } elseif ( 'deactivate' === $action ) {
                $result = $manager->deactivate();
                if ( is_wp_error( $result ) ) {
                    $error = $result->get_error_message();
                } else {
                    $message = __( 'Licence deactivated.', 'saec-core' );
                }
            } elseif ( 'refresh' === $action ) {
                $result = $manager->refresh();
                if ( is_wp_error( $result ) ) {
                    $error = $result->get_error_message();
                } else {
                    $message = __( 'Licence status refreshed.', 'saec-core' );
                }
            }
        }

        $current_key    = $manager->get_masked_key();
        $current_status = $manager->get_status();
        $current_tier   = $manager->get_tier();
        $lockdown       = $manager->is_lockdown();
        $expires        = $manager->get_expires_at();
        $endpoint       = function_exists( 'saec_suite_get_license_api_endpoint' ) ? saec_suite_get_license_api_endpoint() : '';

        // Masked key for display only.
        $display_key = $current_key ? '********' : '';


        // Public plans catalogue from licence server (for purchase UI).
        $plans_payload = array( 'ok' => false, 'plans' => array() );
        if ( method_exists( $manager, 'get_public_plans' ) ) {
            $plans_payload = $manager->get_public_plans();
        }
        $public_plans = ( isset( $plans_payload['plans'] ) && is_array( $plans_payload['plans'] ) ) ? $plans_payload['plans'] : array();

        $plans_by_tier = array();
        foreach ( $public_plans as $p ) {
            if ( ! is_array( $p ) ) {
                continue;
            }
            $t = isset( $p['tier'] ) ? sanitize_key( (string) $p['tier'] ) : '';
            $s = isset( $p['sale_type'] ) ? sanitize_key( (string) $p['sale_type'] ) : '';
            if ( ! $t || ! $s ) {
                continue;
            }
            if ( ! isset( $plans_by_tier[ $t ] ) ) {
                $plans_by_tier[ $t ] = array();
            }
            $plans_by_tier[ $t ][ $s ] = $p;
        }


        if ( ! $embedded ) : ?>
            <div class="wrap">
                <h1><?php esc_html_e( 'SAEC Suite Licence', 'saec-core' ); ?></h1>
<?php endif; ?>

            <?php
            // Always show the public purchase catalogue (even when embedded in Control Center tab).
            ?>
<?php if ( ! empty( $plans_by_tier ) ) : ?>
                    <style>
                        .saec-licence-catalog{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:16px 0 20px}
                        .saec-licence-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
                        .saec-licence-card h3{margin:0 0 6px;font-size:16px}
                        .saec-licence-card .price{font-size:22px;font-weight:700;margin:10px 0}
                        .saec-licence-card .muted{color:#6b7280;font-size:12px;margin:0}
                        .saec-tier-features{margin:10px 0 0;padding-left:18px}
                        .saec-tier-features li{margin:4px 0;color:#111827;font-size:12px;line-height:1.35}
                        .saec-licence-card select{width:100%;max-width:100%;margin-top:8px}
                        .saec-licence-card .actions{margin-top:12px;display:flex;gap:8px;align-items:center}
                        .saec-licence-card .button-primary{white-space:nowrap}
                        @media (max-width:1100px){.saec-licence-catalog{grid-template-columns:repeat(1,minmax(0,1fr))}}
                    </style>
                    <div class="saec-licence-catalog" id="saec-licence-catalog">
                        <?php
                        $tiers = array(
                            'pro'    => __( 'Pro', 'saec-core' ),
                            'agency' => __( 'Agency', 'saec-core' ),
                        );
                        $dur_labels = array(
                            'monthly'  => __( 'Mensuel', 'saec-core' ),
                            'yearly'   => __( 'Annuel', 'saec-core' ),
                            'lifetime' => __( 'À vie', 'saec-core' ),
                        );

                        $checkout_base = admin_url( 'admin-post.php?action=saec_create_checkout' );
                        $checkout_nonce = wp_create_nonce( 'saec_create_checkout' );

                        foreach ( $tiers as $tier_key => $tier_label ) :
                            $tier_plans = isset( $plans_by_tier[ $tier_key ] ) && is_array( $plans_by_tier[ $tier_key ] ) ? $plans_by_tier[ $tier_key ] : array();
                            if ( empty( $tier_plans ) ) {
                                continue;
                            }
                            // Default duration priority: yearly > monthly > lifetime.
                            $default_sale = isset( $tier_plans['yearly'] ) ? 'yearly' : ( isset( $tier_plans['monthly'] ) ? 'monthly' : ( isset( $tier_plans['lifetime'] ) ? 'lifetime' : '' ) );
                            $default_plan = $default_sale && isset( $tier_plans[ $default_sale ] ) ? $tier_plans[ $default_sale ] : array();
                            $amount   = isset( $default_plan['amount'] ) ? (string) $default_plan['amount'] : '';
                            $currency = isset( $default_plan['currency'] ) ? (string) $default_plan['currency'] : 'EUR';
                            ?>
                            <div class="saec-licence-card" data-tier="<?php echo esc_attr( $tier_key ); ?>">
                                <h3><?php echo esc_html( $tier_label ); ?></h3>
                                <p class="muted"><?php echo esc_html__( 'Choisissez une durée, puis lancez l’achat.', 'saec-core' ); ?></p>

                                <?php
                                // Tier descriptions (shown inside cards).
                                if ( 'pro' === $tier_key ) : ?>
                                    <ul class="saec-tier-features">
                                        <li><?php echo esc_html__( 'Accès aux fonctionnalités Pro de la suite SAEC.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'Mises à jour automatiques.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'Support standard.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'Facturation et licence centralisées.', 'saec-core' ); ?></li>
                                    </ul>
                                <?php elseif ( 'agency' === $tier_key ) : ?>
                                    <ul class="saec-tier-features">
                                        <li><?php echo esc_html__( 'Accès à toutes les fonctionnalités Pro + Agency.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'White-label : masquer les références SAEC côté client.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'Presets et déploiement accéléré.', 'saec-core' ); ?></li>
                                        <li><?php echo esc_html__( 'Support prioritaire.', 'saec-core' ); ?></li>
                                    </ul>
                                <?php endif; ?>


                                <label class="screen-reader-text" for="saec_sale_<?php echo esc_attr( $tier_key ); ?>"><?php echo esc_html__( 'Durée', 'saec-core' ); ?></label>
                                <select id="saec_sale_<?php echo esc_attr( $tier_key ); ?>" class="saec-sale-type">
                                    <?php foreach ( $dur_labels as $sale_key => $sale_label ) :
                                        if ( ! isset( $tier_plans[ $sale_key ] ) ) { continue; }
                                        $p = $tier_plans[ $sale_key ];
                                        $a = isset( $p['amount'] ) ? (string) $p['amount'] : '';
                                        $c = isset( $p['currency'] ) ? (string) $p['currency'] : 'EUR';
                                        ?>
                                        <option value="<?php echo esc_attr( $sale_key ); ?>" data-amount="<?php echo esc_attr( $a ); ?>" data-currency="<?php echo esc_attr( $c ); ?>" <?php selected( $sale_key, $default_sale ); ?>>
                                            <?php echo esc_html( $sale_label ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <div class="price">
                                    <span class="saec-price-amount"><?php echo esc_html( $amount ); ?></span>
                                    <span class="saec-price-currency"><?php echo esc_html( $currency ); ?></span>
                                </div>

                                <div class="actions">
  <button type="button" class="button button-primary saec-buy-btn" data-tier="<?php echo esc_attr( $tier_key ); ?>" data-sale="<?php echo esc_attr( $default_sale ); ?>" data-nonce="<?php echo esc_attr( $checkout_nonce ); ?>">
    <?php echo esc_html__( 'Acheter', 'saec-core' ); ?>
  </button>
</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <script>
                    (function(){
                        function updateCard(card){
                            var sel = card.querySelector('.saec-sale-type');
                            var opt = sel && sel.options[sel.selectedIndex];
                            if(!opt) return;
                            var amt = opt.getAttribute('data-amount') || '';
                            var cur = opt.getAttribute('data-currency') || 'EUR';
                            var aEl = card.querySelector('.saec-price-amount');
                            var cEl = card.querySelector('.saec-price-currency');
                            if(aEl) aEl.textContent = amt;
                            if(cEl) cEl.textContent = cur;

                            var btn = card.querySelector('.saec-buy-btn');
                            if(btn){
                                btn.setAttribute('data-sale', sel.value);
                            }
                        }

                        function openModal(tier, sale){
                            var modal = document.getElementById('saec-checkout-modal');
                            var form  = document.getElementById('saec-checkout-form');
                            if(!modal || !form) return;

                            var t = form.querySelector('input[name="tier"]');
                            var s = form.querySelector('input[name="sale_type"]');
                            if(t) t.value = tier || '';
                            if(s) s.value = sale || '';

                            modal.style.display = 'block';
                        }

                        function closeModal(){
                            var modal = document.getElementById('saec-checkout-modal');
                            if(modal) modal.style.display = 'none';
                        }

                        document.addEventListener('click', function(e){
                            var btn = e.target && e.target.closest ? e.target.closest('.saec-buy-btn') : null;
                            if(btn){
                                e.preventDefault();
                                openModal(btn.getAttribute('data-tier'), btn.getAttribute('data-sale'));
                                return;
                            }
                            if(e.target && e.target.id === 'saec-checkout-modal'){
                                closeModal();
                            }
                            if(e.target && e.target.id === 'saec-checkout-close'){
                                e.preventDefault();
                                closeModal();
                            }
                        });

                        document.querySelectorAll('.saec-licence-card').forEach(function(card){
                            var sel = card.querySelector('.saec-sale-type');
                            if(sel){
                                sel.addEventListener('change', function(){ updateCard(card); });
                                updateCard(card);
                            }
                        });
                    })();
                    </script>
                <?php endif; ?>

            <?php if ( $message ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
            <?php endif; ?>

            <?php if ( $error ) : ?>
                <div class="notice notice-error is-dismissible"><p><?php echo esc_html( $error ); ?></p></div>
            <?php endif; ?>

            <table class="widefat striped" style="max-width: 860px;">
                <tbody>
                    <tr>
                        <th><?php esc_html_e( 'Current status', 'saec-core' ); ?></th>
                        <td><?php echo esc_html( $current_status ); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Tier', 'saec-core' ); ?></th>
                        <td><?php echo esc_html( $current_tier ? $current_tier : 'none' ); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Lockdown', 'saec-core' ); ?></th>
                        <td><?php echo esc_html( $lockdown ? __( 'Yes', 'saec-core' ) : __( 'No', 'saec-core' ) ); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Expires at', 'saec-core' ); ?></th>
                        <td><?php echo esc_html( $expires ? $expires : '—' ); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Licence API endpoint', 'saec-core' ); ?></th>
                        <td><?php echo esc_html( $endpoint ? $endpoint : '—' ); ?></td>
                    </tr>
                </tbody>
            </table>

            <form method="post" action="" style="max-width: 860px; margin-top: 12px;">
                <?php wp_nonce_field( 'saec_save_license', 'saec_license_nonce' ); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="saec_license_key"><?php esc_html_e( 'Licence key', 'saec-core' ); ?></label></th>
                        <td>
                            <input name="saec_license_key" id="saec_license_key" type="password" value="<?php echo esc_attr( $display_key ); ?>" class="regular-text" autocomplete="off" />
                            <p class="description"><?php esc_html_e( 'Enter your SAEC licence key to unlock advanced features. The key is stored as a SHA-512 hash only.', 'saec-core' ); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" name="saec_license_action" value="activate" class="button button-primary"><?php esc_html_e( 'Activate', 'saec-core' ); ?></button>
                    <button type="submit" name="saec_license_action" value="refresh" class="button"><?php esc_html_e( 'Refresh', 'saec-core' ); ?></button>
                    <button type="submit" name="saec_license_action" value="deactivate" class="button button-secondary" onclick="return confirm('<?php echo esc_js( __( 'Deactivate the licence on this site?', 'saec-core' ) ); ?>');"><?php esc_html_e( 'Deactivate', 'saec-core' ); ?></button>
                </p>
            </form>

        <?php if ( ! $embedded ) : ?>
            </div>
        <?php endif;
    }


    

/**
 * Render the unified SAEC Suite Control Center page.
 *
 * @return void
 */
public static function render_control_center_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'saec-core' ) );
    }

    if ( class_exists( 'SAEC_Core_Control_Center' ) ) {
        $cc = new SAEC_Core_Control_Center();
        $cc->render_page();
        return;
    }

    echo '<div class="wrap"><h1>' . esc_html__( 'SAEC Suite', 'saec-core' ) . '</h1>';
    echo '<div class="notice notice-error"><p>' . esc_html__( 'Control Center is missing.', 'saec-core' ) . '</p></div></div>';
}

public static function render_license_page() {
        self::render_license_panel( false );
    }


    /**
     * Render checkout modal used by SAEC Suite Licence purchase flow.
     */
    public static function render_checkout_modal() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <!-- SAEC Checkout Modal -->
        <div id="saec-checkout-modal" style="display:none; position:fixed; inset:0; background:rgba(2,6,23,.55); z-index:100000;">
            <div style="max-width:720px; margin:6vh auto; background:rgba(255,255,255,.92); border:1px solid rgba(255,255,255,.35); border-radius:16px; box-shadow:0 18px 60px rgba(0,0,0,.35); overflow:hidden;">
                <div style="display:flex; align-items:center; justify-content:space-between; padding:14px 16px; background:rgba(15,23,42,.06);">
                    <div style="font-weight:700;"><?php echo esc_html__( 'Checkout details', 'saec-core' ); ?></div>
                    <button type="button" class="button" id="saec-checkout-close"><?php echo esc_html__( 'Close', 'saec-core' ); ?></button>
                </div>

                <form id="saec-checkout-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="padding:16px;">
                    <input type="hidden" name="action" value="saec_create_checkout" />
                    <input type="hidden" name="tier" value="" />
                    <input type="hidden" name="sale_type" value="" />
                    <?php wp_nonce_field( 'saec_create_checkout', 'saec_checkout_nonce' ); ?>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                        <div style="grid-column:1 / -1; font-weight:700; opacity:.85;"><?php echo esc_html__( 'Billing information', 'saec-core' ); ?></div>

                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Company / Name', 'saec-core' ); ?></label>
                            <input type="text" name="billing_company" required class="regular-text" style="width:100%;" />
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; opacity:.85; margin-bottom:4px;"><?php echo esc_html__( 'Contact name', 'saec-core' ); ?></label>
                            <input type="text" name="billing_name" class="regular-text" style="width:100%;" />
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Email', 'saec-core' ); ?></label>
                            <input type="email" name="billing_email" required class="regular-text" style="width:100%;" />
                        </div>

                        <div style="grid-column:1 / -1;">
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Address', 'saec-core' ); ?></label>
                            <input type="text" name="billing_address1" required class="regular-text" style="width:100%;" />
                        </div>

                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'ZIP / Postal code', 'saec-core' ); ?></label>
                            <input type="text" name="billing_zip" required class="regular-text" style="width:100%;" />
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'City', 'saec-core' ); ?></label>
                            <input type="text" name="billing_city" required class="regular-text" style="width:100%;" />
                        </div>

                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Country', 'saec-core' ); ?></label>
                            <input type="text" name="billing_country" required class="regular-text" style="width:100%;" />
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'VAT / Company number', 'saec-core' ); ?></label>
                            <input type="text" name="billing_vat" class="regular-text" style="width:100%;" />
                        </div>

                        <div style="grid-column:1 / -1; font-weight:700; opacity:.85; margin-top:8px;"><?php echo esc_html__( 'Website information', 'saec-core' ); ?></div>

                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Site name', 'saec-core' ); ?></label>
                            <input type="text" name="site_name" required class="regular-text" style="width:100%;" />
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; opacity:.75; margin-bottom:4px;"><?php echo esc_html__( 'Site URL', 'saec-core' ); ?></label>
                            <input type="url" name="site_url" required class="regular-text" style="width:100%;" value="<?php echo esc_attr( site_url() ); ?>" />
                        </div>
                    </div>

                    <div style="display:flex; gap:10px; justify-content:flex-end; margin-top:14px;">
                        <button type="button" class="button" id="saec-checkout-cancel"><?php echo esc_html__( 'Cancel', 'saec-core' ); ?></button>
                        <button type="submit" class="button button-primary" id="saec-checkout-submit"><?php echo esc_html__( 'Continue to payment', 'saec-core' ); ?></button>
                    </div>
                </form>
            </div>
        </div>

        <script>
                    (function(){
                        function updateCard(card){
                            var sel = card.querySelector('.saec-sale-type');
                            var opt = sel && sel.options[sel.selectedIndex];
                            if(!opt) return;
                            var amt = opt.getAttribute('data-amount') || '';
                            var cur = opt.getAttribute('data-currency') || 'EUR';
                            var aEl = card.querySelector('.saec-price-amount');
                            var cEl = card.querySelector('.saec-price-currency');
                            if(aEl) aEl.textContent = amt;
                            if(cEl) cEl.textContent = cur;

                            var btn = card.querySelector('.saec-buy-btn');
                            if(btn){
                                btn.setAttribute('data-sale', sel.value);
                            }
                        }

                        function openModal(tier, sale){
                            var modal = document.getElementById('saec-checkout-modal');
                            var form  = document.getElementById('saec-checkout-form');
                            if(!modal || !form) return;

                            var t = form.querySelector('input[name="tier"]');
                            var s = form.querySelector('input[name="sale_type"]');
                            if(t) t.value = tier || '';
                            if(s) s.value = sale || '';

                            modal.style.display = 'block';
                        }

                        function closeModal(){
                            var modal = document.getElementById('saec-checkout-modal');
                            if(modal) modal.style.display = 'none';
                        }

                        document.addEventListener('click', function(e){
                            var btn = e.target && e.target.closest ? e.target.closest('.saec-buy-btn') : null;
                            if(btn){
                                e.preventDefault();
                                openModal(btn.getAttribute('data-tier'), btn.getAttribute('data-sale'));
                                return;
                            }
                            if(e.target && e.target.id === 'saec-checkout-modal'){
                                closeModal();
                            }
                            if(e.target && e.target.id === 'saec-checkout-close'){
                                e.preventDefault();
                                closeModal();
                            }
                        });

                        document.querySelectorAll('.saec-licence-card').forEach(function(card){
                            var sel = card.querySelector('.saec-sale-type');
                            if(sel){
                                sel.addEventListener('change', function(){ updateCard(card); });
                                updateCard(card);
                            }
                        });
                    })();
                    </script>
        <?php
    }


}


