<?php
/**
 * SAEC Control Center – Admin UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SAEC_Core_Control_Center {

    /**
     * Register hooks.
     */
    public function hooks() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // Ensure the checkout modal is present on the SAEC Suite Licence tab.
        add_action( 'admin_footer', array( $this, 'maybe_render_checkout_modal' ) );
        add_action( 'admin_post_saec_core_cc_market_install', array( $this, 'handle_market_install' ) );
        add_action( 'admin_post_saec_core_cc_save_settings', array( $this, 'handle_save_settings' ) );
        add_action( 'admin_post_saec_core_cc_export_config', array( $this, 'handle_export_config' ) );
        add_action( 'admin_post_saec_core_cc_import_config', array( $this, 'handle_import_config' ) );
    }

    /**
     * Register admin menu.
     */
    public function register_menu() {

        $parent_slug = 'saec-suite';

        add_submenu_page(
            $parent_slug,
            __( 'SAEC Control Center', 'saec-core' ),
            __( 'Control Center', 'saec-core' ),
            'manage_options',
            'saec-suite',
            array( $this, 'render_page' )
        );
    }

    /**
     * Check if a top-level menu slug exists.
     *
     * @param string $slug Slug.
     * @return bool
     */
    private function menu_exists( $slug ) {
        global $menu;
        if ( empty( $menu ) || ! is_array( $menu ) ) {
            return false;
        }
        foreach ( $menu as $item ) {
            if ( isset( $item[2] ) && $item[2] === $slug ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Enqueue styles and scripts.
     *
     * @param string $hook_suffix Current page hook.
     */
    public function enqueue_assets( $hook_suffix ) {
        if ( false === strpos( $hook_suffix, 'saec-suite' ) ) { return; }

        wp_enqueue_style(
            'saec-cc-admin',
            SAEC_CORE_PLUGIN_URL . 'assets/css/cc-admin.css',
            array(),
            SAEC_CORE_VERSION
        );

        wp_enqueue_style(
            'saec-cc-glass',
            SAEC_CORE_PLUGIN_URL . 'assets/css/cc-glass.css',
            array( 'saec-cc-admin' ),
            SAEC_CORE_VERSION
        );


        wp_enqueue_script(
            'saec-cc-admin',
            SAEC_CORE_PLUGIN_URL . 'assets/js/cc-admin.js',
            array(),
            SAEC_CORE_VERSION,
            true
        );
    

    wp_localize_script(
        'saec-cc-admin',
        'SAEC_CC',
        array(
            'restBase' => esc_url_raw( rest_url( 'saec-suite/v1' ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'i18n'     => array(
                'toggleFailed' => __( 'Action failed. Please check logs and try again.', 'saec-core' ),
            ),
        )
    );
}

    /**
     * Render the checkout modal in the admin footer when the user is on the
     * SAEC Suite Licence tab.
     */
    public function maybe_render_checkout_modal() {
        if ( ! is_admin() ) {
            return;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( (string) $_GET['page'] ) : '';
        $tab  = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : '';
        if ( $page !== 'saec-suite' || $tab !== 'licence' ) {
            return;
        }

        if ( class_exists( 'SAEC_Core_Admin' ) && method_exists( 'SAEC_Core_Admin', 'render_checkout_modal' ) ) {
            SAEC_Core_Admin::render_checkout_modal();
        }
    }


    /**
     * Get static registry of known SAEC modules (critical / recommended).
     *
     * @return array
     */
    /**
     * Public registry accessor.
     *
     * This method is intentionally public so SAEC Core REST endpoints can
     * enrich module metadata (required tier, category, etc.) without
     * duplicating the registry.
     *
     * @return array
     */
    public function get_registry() {
        return array(
            'saec-core/saec-core.php' => array(
                'name'          => 'SAEC Core',
                'category'      => __( 'Licence & Suite', 'saec-core' ),
                'importance'    => 'critical',
                'required_tier' => 'basic',
                'icon_key'      => 'core',
            ),
            'saec-guardian/saec-guardian.php' => array(
                'name'          => 'SAEC Guardian',
                'category'      => __( 'Security', 'saec-core' ),
                'importance'    => 'critical',
                'required_tier' => 'pro',
                'icon_key'      => 'guardian',
            ),
            'saec-perf/saec-perf.php' => array(
                'name'          => 'SAEC Perf',
                'category'      => __( 'Performance', 'saec-core' ),
                'importance'    => 'recommended',
                'required_tier' => 'pro',
                'icon_key'      => 'perf',
            ),
            'saec-media/saec-media.php' => array(
                'name'          => 'SAEC Media',
                'category'      => __( 'Media & images', 'saec-core' ),
                'importance'    => 'recommended',
                'required_tier' => 'pro',
                'icon_key'      => 'media',
            ),
            'saec-po-ai-translator/saec-po-ai-translator.php' => array(
                'name'          => 'SAEC PO AI Translator',
                'category'      => __( 'Translations', 'saec-core' ),
                'importance'    => 'optional',
                'required_tier' => 'agency',
                'icon_key'      => 'translator',
            ),
            'saec-consent/saec-consent.php' => array(
                'name'          => 'SAEC Consent',
                'category'      => __( 'Privacy & cookies', 'saec-core' ),
                'importance'    => 'critical',
                'required_tier' => 'basic',
                'icon_key'      => 'consent',
            ),
            'saec-db-cleaner/saec-db-cleaner.php' => array(
                'name'          => 'SAEC DB Cleaner',
                'category'      => __( 'Database & maintenance', 'saec-core' ),
                'importance'    => 'recommended',
                'required_tier' => 'pro',
                'icon_key'      => 'db-cleaner',
            ),
        );
    }

    /**
     * Get installed plugins.
     *
     * @return array
     */
    private function get_installed_plugins() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        return function_exists( 'get_plugins' ) ? get_plugins() : array();
    }

    /**
     * Get custom endpoint override.
     *
     * @return string
     */
    private function get_custom_endpoint() {
        // 1) If a separate Control Center plugin provides an accessor, use it.
        if ( function_exists( 'saec_cc_get_custom_endpoint' ) ) {
            $ep = (string) saec_cc_get_custom_endpoint();
            return trim( $ep );
        }
        // 2) Otherwise read from our stored Control Center options.
        $opts = get_option( 'saec_cc_options', array() );
        if ( is_array( $opts ) ) {
            if ( ! empty( $opts['license_api_endpoint'] ) ) {
                return trim( (string) $opts['license_api_endpoint'] );
            }
            if ( ! empty( $opts['custom_endpoint'] ) ) {
                return trim( (string) $opts['custom_endpoint'] );
            }
        }
        return '';
    }

    /**
     * Resolve icon URL for a given module slug.
     *
     * @param string $slug Plugin slug.
     * @param string $fallback Existing icon URL from marketplace JSON, if any.
     *
     * @return string
     */
    private function resolve_icon_url( $slug, $fallback = '' ) {
        // If marketplace already provided an icon URL, normalize it to the central assets host.
        if ( ! empty( $fallback ) ) {
            return $this->normalize_asset_url( (string) $fallback );
        }

        // Default to central icons directory (assets must be reachable for remote installs).
        $baseurl = $this->get_central_icons_baseurl();

        $map = array(
            'saec-core/'                => 'core.svg',
            'saec-guardian/'            => 'guardian.svg',
            'saec-perf/'                => 'perf.svg',
            'saec-media/'               => 'media.svg',
            'saec-consent/'             => 'consent.svg',
            'saec-po-ai-translator/'    => 'translator.svg',
            'saec-db-cleaner/'          => 'db-cleaner.svg',
            'saec-toolkit/'             => 'toolkit.svg',
            'saec-cloudflare-cdn/'      => 'cloudflare-cdn.svg',
            'saec-control-center/'      => 'control-center.svg',
            'saec-license-marketplace/' => 'marketplace.svg',
        );

        foreach ( $map as $prefix => $file ) {
            if ( 0 === strpos( $slug, $prefix ) ) {
                return $baseurl . $file;
            }
        }

        // Automatic mapping: if the icon wasn't mapped explicitly, try to derive it from the module slug.
        // Examples:
        // - saec-admin-glass/saec-admin-glass.php -> saec-admin-glass.svg
        // - saec-seo/ -> saec-seo.svg
        $key = $this->derive_icon_key_from_slug( (string) $slug );
        if ( '' !== $key ) {
            return $baseurl . $key . '.svg';
        }

        return '';
    }

    /**
     * Derive icon key from a plugin slug.
     *
     * @param string $slug
     * @return string
     */
    private function derive_icon_key_from_slug( $slug ) {
        $slug = trim( (string) $slug );
        if ( '' === $slug ) {
            return '';
        }

        // Keep first path segment (plugin directory).
        $dir = $slug;
        if ( false !== strpos( $dir, '/' ) ) {
            $dir = explode( '/', $dir )[0];
        }

        $dir = trim( $dir );
        if ( '' === $dir ) {
            return '';
        }

        // Remove any .php suffix if it was passed without a directory.
        $dir = preg_replace( '/\.php$/i', '', $dir );

        // Normalize to a slug-like key.
        if ( function_exists( 'sanitize_title' ) ) {
            $dir = sanitize_title( $dir );
        } else {
            $dir = strtolower( preg_replace( '/[^a-z0-9\-]+/i', '-', $dir ) );
            $dir = trim( $dir, '-' );
        }

        return is_string( $dir ) ? $dir : '';
    }

    /**
     * Get central icons base URL hosted on the licence server domain.
     *
     * @return string
     */
    private function get_central_icons_baseurl() {
        $default = 'https://saec.me/wp-content/uploads/saec-icons/';

        $endpoint = '';
        if ( function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
            $endpoint = (string) saec_suite_get_license_api_endpoint();
        }

        if ( empty( $endpoint ) ) {
            return $default;
        }

        $parts = wp_parse_url( $endpoint );
        if ( empty( $parts['host'] ) ) {
            return $default;
        }

        $scheme = ! empty( $parts['scheme'] ) ? $parts['scheme'] : 'https';

        return trailingslashit( $scheme . '://' . $parts['host'] ) . 'wp-content/uploads/saec-icons/';
    }

    /**
     * Normalize an asset URL so icons/images are loaded from the central SAEC host,
     * not from the current (remote) site.
     *
     * @param string $url
     *
     * @return string
     */
    private function normalize_asset_url( $url ) {
        $url = trim( (string) $url );
        if ( '' === $url ) {
            return '';
        }

        // Already absolute: replace host if it's the current site.
        $parts = wp_parse_url( $url );
        if ( is_array( $parts ) && ! empty( $parts['host'] ) ) {
            $current = wp_parse_url( home_url() );
            $current_host = ( is_array( $current ) && ! empty( $current['host'] ) ) ? $current['host'] : '';

            if ( $current_host && 0 === strcasecmp( $parts['host'], $current_host ) ) {
                $central = wp_parse_url( $this->get_central_icons_baseurl() );
                $scheme  = ! empty( $central['scheme'] ) ? $central['scheme'] : 'https';
                $host    = ! empty( $central['host'] ) ? $central['host'] : 'saec.me';

                $path  = isset( $parts['path'] ) ? $parts['path'] : '';
                $query = isset( $parts['query'] ) ? ('?' . $parts['query']) : '';

                return $scheme . '://' . $host . $path . $query;
            }

            return $url;
        }

        // Relative URL: attach to central host.
        $central = $this->get_central_icons_baseurl();
        $central_parts = wp_parse_url( $central );
        $scheme = ! empty( $central_parts['scheme'] ) ? $central_parts['scheme'] : 'https';
        $host   = ! empty( $central_parts['host'] ) ? $central_parts['host'] : 'saec.me';

        $path = $url;
        if ( 0 !== strpos( $path, '/' ) ) {
            $path = '/' . ltrim( $path, '/' );
        }

        return $scheme . '://' . $host . $path;
    }

    /**
     * Render main page.
     */
    public function render_page() {
        if ( ! SAEC_Capabilities::user_can_manage_suite() ) {
            return;
        }

        $base_url = admin_url( 'admin.php?page=saec-suite' );

        // Build tabs based on capabilities.
        // Build tabs based on capabilities.
$tabs = array(
    'dashboard'   => array(
        'label' => __( 'Dashboard', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'modules'     => array(
        'label' => __( 'Modules', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'marketplace' => array(
        'label' => __( 'Marketplace', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'licence'     => array(
        'label' => __( 'Licence', 'saec-core' ),
        'cap'   => 'saec_manage_licenses',
    ),
    'registry'    => array(
        'label' => __( 'Registry', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'health'      => array(
        'label' => __( 'Health', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'logs'        => array(
        'label' => __( 'Logs', 'saec-core' ),
        'cap'   => 'saec_view_reports',
    ),
    'audit'       => array(
        'label' => __( 'Audit', 'saec-core' ),
        'cap'   => 'saec_view_reports',
    ),
    'settings'    => array(
        'label' => __( 'Settings', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
    'help'        => array(
        'label' => __( 'Help', 'saec-core' ),
        'cap'   => 'saec_manage_suite',
    ),
);

        // Filter tabs (allow extensions).
        $tabs = apply_filters( 'saec_suite_control_center_tabs', $tabs );
        if ( ! is_array( $tabs ) ) {
            $tabs = array();
        }

        // Compute allowed tabs.
        $allowed_tabs = array();
        foreach ( $tabs as $key => $cfg ) {
            $cap = isset( $cfg['cap'] ) ? (string) $cfg['cap'] : 'saec_manage_suite';
            if ( current_user_can( $cap ) || current_user_can( 'manage_options' ) ) {
                $allowed_tabs[ $key ] = $cfg;
            }
        }

        // Pick active tab.
        $requested_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
        if ( $requested_tab && isset( $allowed_tabs[ $requested_tab ] ) ) {
            $active_tab = $requested_tab;
        } else {
            $keys = array_keys( $allowed_tabs );
            $active_tab = ! empty( $keys ) ? $keys[0] : 'dashboard';
        }

        ?>
        <?php
        $lm        = class_exists( 'SAEC_License_Manager' ) ? SAEC_License_Manager::instance() : null;
        $lic_tier  = $lm ? $lm->get_tier() : '';
        $lic_stat  = $lm ? $lm->get_status() : '';
        $lockdown  = $lm ? (bool) $lm->is_lockdown() : false;
        $retry_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_retry_license' ), 'saec_retry_license' );
        ?>

        <div class="wrap saec-cc-wrap">
            <h1 class="saec-cc-title"><?php esc_html_e( 'SAEC Control Center', 'saec-core' ); ?></h1>

            <div style="margin:8px 0 12px;">
                <?php if ( $lic_tier ) : ?>
                    <span class="saec-badge saec-badge-info"><?php echo esc_html( strtoupper( $lic_tier ) ); ?></span>
                <?php endif; ?>
                <?php if ( $lic_stat ) : ?>
                    <span class="saec-badge <?php echo ( 'active' === $lic_stat ) ? 'saec-badge-ok' : 'saec-badge-warn'; ?>"><?php echo esc_html( $lic_stat ); ?></span>
                <?php endif; ?>
                <?php if ( $lockdown ) : ?>
                    <span class="saec-badge saec-badge-error"><?php esc_html_e( 'LOCKDOWN', 'saec-core' ); ?></span>
                <?php endif; ?>

                <?php if ( function_exists( 'saec_suite_is_safe_mode' ) && saec_suite_is_safe_mode() ) : ?>
                    <span class="saec-badge saec-badge-warn"><?php esc_html_e( 'SAFE MODE', 'saec-core' ); ?></span>
                <?php endif; ?>


                <?php if ( SAEC_Capabilities::user_can_manage_licenses() ) : ?>
                    <a class="button" href="<?php echo esc_url( $retry_url ); ?>" style="margin-left:10px;">
                        <?php esc_html_e( 'Retry licence check', 'saec-core' ); ?>
                    </a>
                <?php endif; ?>
            </div>


<?php if ( function_exists( 'saec_suite_is_safe_mode' ) && saec_suite_is_safe_mode() ) : ?>
    <div class="notice notice-warning inline" style="margin:12px 0 0 0;">
        <p><strong><?php esc_html_e( 'Safe Mode is enabled.', 'saec-core' ); ?></strong> <?php esc_html_e( 'Risky actions are disabled.', 'saec-core' ); ?></p>
    </div>
<?php endif; ?>

            <h2 class="nav-tab-wrapper saec-cc-tabs">
                <?php foreach ( $allowed_tabs as $key => $cfg ) :
                    $label = isset( $cfg['label'] ) ? (string) $cfg['label'] : $key;
                    ?>
                    <a href="<?php echo esc_url( add_query_arg( 'tab', $key, $base_url ) ); ?>" class="nav-tab <?php echo ( $key === $active_tab ) ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </h2>

            <?php $this->render_notices(); ?>

            <div class="saec-cc-content">
                <?php
                switch ( $active_tab ) {
                    
            case 'modules':
    $this->render_modules();
    break;
case 'marketplace':
    $this->render_marketplace();
    break;
case 'licence':
    if ( class_exists( 'SAEC_Core_Admin' ) ) {
        SAEC_Core_Admin::render_license_panel( true );
    }
    break;
case 'registry':
    $this->render_registry();
    break;
case 'health':
    $this->render_health();
    break;
case 'logs':
    $this->render_logs();
    break;
case 'audit':
    $this->render_audit();
    break;
case 'settings':
    $this->render_settings();
    break;
case 'help':
    $this->render_help();
    break;
case 'dashboard':
default:
    $this->render_dashboard();
    break;
                }
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render stored admin notices for marketplace / settings actions.
     */
    private function render_notices() {
        $notice = get_transient( 'saec_cc_market_notice' );
        if ( $notice && is_array( $notice ) ) {
            delete_transient( 'saec_cc_market_notice' );

            $type    = ! empty( $notice['type'] ) ? $notice['type'] : 'info';
            $message = ! empty( $notice['message'] ) ? $notice['message'] : '';

            if ( $message ) {
                $class = 'notice notice-' . sanitize_html_class( $type );
                ?>
                <div class="<?php echo esc_attr( $class ); ?> is-dismissible">
                    <p><?php echo esc_html( $message ); ?></p>
                </div>
                <?php
            }
        }

        $settings_notice = get_transient( 'saec_core_cc_settings_notice' );
        if ( $settings_notice && is_array( $settings_notice ) ) {
            delete_transient( 'saec_core_cc_settings_notice' );

            $type    = ! empty( $settings_notice['type'] ) ? $settings_notice['type'] : 'info';
            $message = ! empty( $settings_notice['message'] ) ? $settings_notice['message'] : '';

            if ( $message ) {
                $class = 'notice notice-' . sanitize_html_class( $type );
                ?>
                <div class="<?php echo esc_attr( $class ); ?> is-dismissible">
                    <p><?php echo esc_html( $message ); ?></p>
                </div>
                <?php
            }
        }
    }

    /**
     * Render dashboard tab.
     */
    private function render_dashboard() {

        $tier        = function_exists( 'saec_suite_get_tier' ) ? saec_suite_get_tier() : '';
        $license_raw = function_exists( 'saec_suite_get_license_info' ) ? saec_suite_get_license_info() : array();

        $core_endpoint = '';
        if ( ! empty( $license_raw['api_endpoint'] ) ) {
            $core_endpoint = $license_raw['api_endpoint'];
        } elseif ( function_exists( 'saec_suite_get_license_api_endpoint' ) ) {
            $core_endpoint = saec_suite_get_license_api_endpoint();
        } elseif ( function_exists( 'rest_url' ) ) {
            $core_endpoint = rest_url( 'saec-license/v1' );
        }

        $custom_endpoint    = $this->get_custom_endpoint();
        $effective_endpoint = $custom_endpoint ? $custom_endpoint : $core_endpoint;

        $lockdown = isset( $license_raw['lockdown'] ) ? (bool) $license_raw['lockdown'] : null;

        $plugins  = $this->get_installed_plugins();
        $registry = $this->get_registry();

        $saec_plugins = array();
        foreach ( $plugins as $slug => $data ) {
            if ( 0 === strpos( $slug, 'saec-' ) ) {
                $saec_plugins[ $slug ] = $data;
            }
        }

        $total_saec = count( $saec_plugins );
        $active     = 0;
        $inactive   = 0;

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        foreach ( $saec_plugins as $slug => $data ) {
            if ( is_plugin_active( $slug ) ) {
                $active++;
            } else {
                $inactive++;
            }
        }

        $tier_counts = array(
            'basic'   => 0,
            'pro'     => 0,
            'agency'  => 0,
            'none'    => 0,
        );

        foreach ( $registry as $slug => $conf ) {
            $required = isset( $conf['required_tier'] ) ? $conf['required_tier'] : 'none';
            if ( isset( $tier_counts[ $required ] ) ) {
                $tier_counts[ $required ]++;
            } else {
                $tier_counts['none']++;
            }
        }

        $bundle_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_support_bundle' ), 'saec_support_bundle' );
?>
        <div class="saec-cc-grid">
            <div class="saec-cc-card saec-cc-card-glass">
                <h2><?php esc_html_e( 'Licence & SAEC Suite status', 'saec-core' ); ?></h2>

                <table class="saec-cc-table">
                    <tbody>
                        <tr>
                            <th><?php esc_html_e( 'Tier', 'saec-core' ); ?></th>
                            <td><?php echo $tier ? esc_html( $tier ) : '&mdash;'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Core licence endpoint (SAEC Core)', 'saec-core' ); ?></th>
                            <td>
                                <?php
                                if ( $core_endpoint ) {
                                    echo esc_html( $core_endpoint );
                                } else {
                                    esc_html_e( 'None configured', 'saec-core' );
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Custom endpoint override (Control Center)', 'saec-core' ); ?></th>
                            <td>
                                <?php
                                if ( $custom_endpoint ) {
                                    echo esc_html( $custom_endpoint );
                                } else {
                                    echo '&mdash;';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Effective endpoint used by Marketplace', 'saec-core' ); ?></th>
                            <td>
                                <?php
                                if ( $effective_endpoint ) {
                                    echo esc_html( $effective_endpoint );
                                } else {
                                    esc_html_e( 'None', 'saec-core' );
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Lockdown', 'saec-core' ); ?></th>
                            <td>
                                <?php
                                if ( null === $lockdown ) {
                                    echo '&mdash;';
                                } else {
                                    echo $lockdown ? esc_html__( 'Yes', 'saec-core' ) : esc_html__( 'No', 'saec-core' );
                                }
                                ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="saec-cc-card saec-cc-card-glass">
                <h2><?php esc_html_e( 'SAEC plugins summary', 'saec-core' ); ?></h2>
                <ul class="saec-cc-list">
                    <li><?php printf( esc_html__( 'Total SAEC plugins: %d', 'saec-core' ), (int) $total_saec ); ?></li>
                    <li><?php printf( esc_html__( 'Active: %d', 'saec-core' ), (int) $active ); ?></li>
                    <li><?php printf( esc_html__( 'Inactive: %d', 'saec-core' ), (int) $inactive ); ?></li>
                </ul>

                <h3><?php esc_html_e( 'By required tier', 'saec-core' ); ?></h3>
                <ul class="saec-cc-list saec-cc-list-inline">
                    <li><?php printf( esc_html__( 'Basic: %d', 'saec-core' ), (int) $tier_counts['basic'] ); ?></li>
                    <li><?php printf( esc_html__( 'Pro: %d', 'saec-core' ), (int) $tier_counts['pro'] ); ?></li>
                    <li><?php printf( esc_html__( 'Agency: %d', 'saec-core' ), (int) $tier_counts['agency'] ); ?></li>
                    <li><?php printf( esc_html__( 'No specific tier: %d', 'saec-core' ), (int) $tier_counts['none'] ); ?></li>
                </ul>
            </div>

            <div class="saec-cc-card saec-cc-card-glass saec-cc-card-critical">
                <h2><?php esc_html_e( 'Critical modules', 'saec-core' ); ?></h2>
                <p class="description">
                    <?php esc_html_e( 'Critical modules are strongly recommended for a complete SAEC installation (security, performance, media, translations and privacy).', 'saec-core' ); ?>
                </p>
                <table class="saec-cc-table saec-cc-table-compact saec-cc-table-critical">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Module', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Category', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Importance', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Required tier', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Status', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'saec-core' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ( ! function_exists( 'is_plugin_active' ) ) {
                            require_once ABSPATH . 'wp-admin/includes/plugin.php';
                        }

                        foreach ( $registry as $slug => $conf ) :
                            if ( 'critical' !== $conf['importance'] ) {
                                continue;
                            }
                            $is_installed = isset( $plugins[ $slug ] );
                            $is_active    = $is_installed && is_plugin_active( $slug );

                            $status = '';
                            if ( ! $is_installed ) {
                                $status = __( 'Missing', 'saec-core' );
                            } elseif ( $is_active ) {
                                $status = __( 'Active', 'saec-core' );
                            } else {
                                $status = __( 'Inactive', 'saec-core' );
                            }

                            $importance_label = __( 'Critical', 'saec-core' );
                            $tier_label       = ucfirst( $conf['required_tier'] );

                            $icon_url = '';
                            if ( isset( $conf['icon_key'] ) ) {
                                $icon_url = $this->resolve_icon_url( $slug, '' );
                            }
                            ?>
                            <tr>
                                <td>
                                    <div class="saec-cc-module-with-icon">
                                        <?php if ( $icon_url ) : ?>
                                            <span class="saec-cc-module-icon">
                                                <img src="<?php echo esc_url( $icon_url ); ?>" alt="" />
                                            </span>
                                        <?php endif; ?>
                                        <span class="saec-cc-module-name"><?php echo esc_html( $conf['name'] ); ?></span>
                                    </div>
                                </td>
                                <td><?php echo esc_html( $conf['category'] ); ?></td>
                                <td><?php echo esc_html( $importance_label ); ?></td>
                                <td><?php echo esc_html( $tier_label ); ?></td>
                                <td><?php echo esc_html( $status ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Render SAEC modules tab.
     */
    private function render_modules() {

        $registry = $this->get_registry();
        $plugins  = $this->get_installed_plugins();

        // WP update info.
        $updates    = get_site_transient( 'update_plugins' );
        $update_map = is_object( $updates ) && ! empty( $updates->response ) && is_array( $updates->response ) ? $updates->response : array();

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $rows = array();

        foreach ( $registry as $slug => $conf ) {
            $is_installed = isset( $plugins[ $slug ] );
            $is_active    = $is_installed && is_plugin_active( $slug );
            $version      = $is_installed ? $plugins[ $slug ]['Version'] : '';

            $rows[ $slug ] = array(
                'slug'          => $slug,
                'name'          => $conf['name'],
                'category'      => $conf['category'],
                'importance'    => $conf['importance'],
                'required_tier' => $conf['required_tier'],
                'installed'     => $is_installed,
                'active'        => $is_active,
                'version'       => $version,
                'has_update'    => isset( $update_map[ $slug ] ),
                'new_version'   => isset( $update_map[ $slug ] ) && ! empty( $update_map[ $slug ]->new_version ) ? (string) $update_map[ $slug ]->new_version : '',
                'known'         => true,
            );
        }

        foreach ( $plugins as $slug => $data ) {
            if ( 0 !== strpos( $slug, 'saec-' ) ) {
                continue;
            }
            if ( isset( $rows[ $slug ] ) ) {
                continue;
            }
            $is_active = is_plugin_active( $slug );
            $rows[ $slug ] = array(
                'slug'          => $slug,
                'name'          => $data['Name'],
                'category'      => __( 'Other', 'saec-core' ),
                'importance'    => 'optional',
                'required_tier' => 'agency',
                'installed'     => true,
                'active'        => $is_active,
                'version'       => $data['Version'],
                'known'         => false,
            );
        }

        ?>
        <div class="saec-cc-card saec-cc-card-glass">
            <h2><?php esc_html_e( 'SAEC modules overview', 'saec-core' ); ?></h2>
            <p class="description">
                <?php esc_html_e( 'Overview of SAEC Suite modules, their importance, required tier and current status on this site.', 'saec-core' ); ?>
            </p>

            
            <div class="saec-cc-toolbar">
                <input type="search" id="saec-cc-module-search" class="saec-cc-search" placeholder="<?php echo esc_attr__( 'Search modules…', 'saec-core' ); ?>" />
                <label class="saec-cc-check">
                    <input type="checkbox" id="saec-cc-updates-only" />
                    <span><?php esc_html_e( 'Updates only', 'saec-core' ); ?></span>
                </label>
            </div>

<table class="saec-cc-table saec-cc-table-striped saec-cc-table-modules">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Module', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Category', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Importance', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Required tier', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Version', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'saec-core' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $rows as $row ) :
                        $status_bits = array();
                        if ( $row['installed'] ) {
                            if ( $row['active'] ) {
                                $status_bits[] = __( 'Active', 'saec-core' );
                            } else {
                                $status_bits[] = __( 'Inactive', 'saec-core' );
                            }

                            if ( ! empty( $row['has_update'] ) ) {
                                $status_bits[] = sprintf( __( 'Update available (%s)', 'saec-core' ), $row['new_version'] ? $row['new_version'] : __( 'new', 'saec-core' ) );
                            } else {
                                $status_bits[] = __( 'Up to date', 'saec-core' );
                            }
                        } else {
                            $status_bits[] = __( 'Missing', 'saec-core' );
                        }

                        if ( ! $row['known'] ) {
                            $status_bits[] = __( 'Detected (unmapped)', 'saec-core' );
                        }

                        $importance_label = '';
                        if ( 'critical' === $row['importance'] ) {
                            $importance_label = __( 'Critical', 'saec-core' );
                        } elseif ( 'recommended' === $row['importance'] ) {
                            $importance_label = __( 'Recommended', 'saec-core' );
                        } else {
                            $importance_label = __( 'Optional', 'saec-core' );
                        }

                        $tier_label = ucfirst( $row['required_tier'] );

                        $icon_url = $this->resolve_icon_url( $row['slug'], '' );
                        ?>
                        <tr data-module=\"<?php echo esc_attr( $row['slug'] ); ?>\" data-has-update=\"<?php echo ! empty( $row['has_update'] ) ? '1' : '0'; ?>\">
                            <td>
                                <div class="saec-cc-module-with-icon">
                                    <?php if ( $icon_url ) : ?>
                                        <span class="saec-cc-module-icon">
                                            <img src="<?php echo esc_url( $icon_url ); ?>" alt="" />
                                        </span>
                                    <?php endif; ?>
                                    <span class="saec-cc-module-name">
                                        <?php echo esc_html( $row['name'] ); ?><br />
                                        <code><?php echo esc_html( $row['slug'] ); ?></code>
                                    </span>
                                </div>
                            </td>
                            <td><?php echo esc_html( $row['category'] ); ?></td>
                            <td><?php echo esc_html( $importance_label ); ?></td>
                            <td><?php echo esc_html( $tier_label ); ?></td>
                            <td><?php echo $row['version'] ? esc_html( $row['version'] ) : '&mdash;'; ?></td>
                            <td><?php echo esc_html( implode( ' • ', $status_bits ) ); ?></td>
                            <td class="saec-cc-actions">
                                <?php
                                $is_core = ( isset( $row['slug'] ) && defined( 'SAEC_CORE_PLUGIN_FILE' ) && plugin_basename( SAEC_CORE_PLUGIN_FILE ) === $row['slug'] );
                                if ( $row['installed'] && ! $is_core ) :
                                    ?>
                                    <label class="saec-cc-switch">
                                        <input type="checkbox" class="saec-suite-toggle" data-plugin="<?php echo esc_attr( $row['slug'] ); ?>" <?php checked( $row['active'] ); ?> />
                                        <span class="saec-cc-slider" aria-hidden="true"></span>
                                    </label>
                                <?php endif; ?>

                                <?php if ( ! $row['installed'] ) : ?>
								<a class="button button-primary" href="<?php echo esc_url( add_query_arg( array( 'tab' => 'marketplace', 'focus' => rawurlencode( $row['slug'] ) ), admin_url( 'admin.php?page=saec-suite' ) ) ); ?>">
                                        <?php esc_html_e( 'Install', 'saec-core' ); ?>
                                    </a>
                                <?php elseif ( ! empty( $row['has_update'] ) ) : ?>
								<a class="button button-primary" href="<?php echo esc_url( add_query_arg( array( 'tab' => 'marketplace', 'focus' => rawurlencode( $row['slug'] ) ), admin_url( 'admin.php?page=saec-suite' ) ) ); ?>">
                                        <?php echo esc_html( sprintf( __( 'Update to %s', 'saec-core' ), $row['new_version'] ? $row['new_version'] : __( 'latest', 'saec-core' ) ) ); ?>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
        <?php
    }

    /**
     * Render health tab (REST API, licence endpoint, critical modules + per-module diagnostics).
     */
    
    /**
     * Render Registry tab (module manifests).
     */
    private function render_registry() {
        $registry = array();
        if ( function_exists( 'saec_suite_get_registry' ) ) {
            $registry = (array) saec_suite_get_registry();
        }

        // Merge with internal registry (Control Center curated registry).
        $registry = array_merge( $registry, (array) $this->get_registry() );

        ?>
        <div class="saec-cc-card">
            <div class="saec-cc-card-header">
                <h2><?php esc_html_e( 'SAEC Registry', 'saec-core' ); ?></h2>
                <p class="description">
                    <?php esc_html_e( 'This registry is used to declare module metadata (tier requirements, categories, features). Modules can provide a saec.json manifest in their plugin folder, or register via the saec_suite_registry_items filter.', 'saec-core' ); ?>
                </p>
            </div>
            <div class="saec-cc-card-body">
                <?php if ( empty( $registry ) ) : ?>
                    <p><?php esc_html_e( 'No registry entries found yet.', 'saec-core' ); ?></p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Plugin', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Name', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Category', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Required tier', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Manifest', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Lockdown', 'saec-core' ); ?></th>
                                <th><?php esc_html_e( 'Features', 'saec-core' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $registry as $plugin_file => $meta ) : ?>
                                <tr>
                                    <td><code><?php echo esc_html( (string) $plugin_file ); ?></code></td>
                                    <td><?php echo esc_html( isset( $meta['name'] ) ? (string) $meta['name'] : '' ); ?></td>
                                    <td><?php echo esc_html( isset( $meta['category'] ) ? (string) $meta['category'] : '' ); ?></td>
                                    <td><strong><?php echo esc_html( isset( $meta['required_tier'] ) ? (string) $meta['required_tier'] : '' ); ?></strong></td>
                                    <td>
                                        <?php
                                        $valid  = ! isset( $meta['manifest_valid'] ) ? null : (bool) $meta['manifest_valid'];
                                        $errors = isset( $meta['manifest_errors'] ) && is_array( $meta['manifest_errors'] ) ? $meta['manifest_errors'] : array();

                                        if ( null === $valid ) {
                                            echo '<span class="saec-badge saec-badge-info">' . esc_html__( 'n/a', 'saec-core' ) . '</span>';
                                        } elseif ( $valid ) {
                                            echo '<span class="saec-badge saec-badge-ok">' . esc_html__( 'valid', 'saec-core' ) . '</span>';
                                        } else {
                                            echo '<span class="saec-badge saec-badge-warn">' . esc_html__( 'invalid', 'saec-core' ) . '</span>';
                                            if ( ! empty( $errors ) ) {
                                                echo '<div class="description" style="margin-top:6px;">' . esc_html( implode( ' | ', array_map( 'strval', $errors ) ) ) . '</div>';
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo ! empty( $meta['available_in_lockdown'] ) ? esc_html__( 'Allowed', 'saec-core' ) : esc_html__( 'Blocked', 'saec-core' ); ?></td>
                                    <td>
                                        <?php
                                        $features = isset( $meta['features'] ) && is_array( $meta['features'] ) ? $meta['features'] : array();
                                        echo esc_html( implode( ', ', array_map( 'strval', $features ) ) );
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

private function render_health() {

        $bundle_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_support_bundle' ), 'saec_support_bundle' );

        $issues = array();
        $checks = array();

        // === Global REST API reachability ===
        $rest_status   = 'ok';
        $rest_message  = __( 'REST API responded correctly.', 'saec-core' );
        $rest_endpoint = function_exists( 'rest_url' ) ? rest_url() : '';

        if ( $rest_endpoint && function_exists( 'wp_remote_get' ) ) {
            $response = wp_remote_get(
                $rest_endpoint,
                array(
                    'timeout'   => 8,
                    'sslverify' => false,
                )
            );

            if ( is_wp_error( $response ) ) {
                $rest_status  = 'warn';
                $rest_message = sprintf(
                    /* translators: 1: error message, 2: endpoint */
                    __( 'REST API request failed for %2$s: %1$s', 'saec-core' ),
                    $response->get_error_message(),
                    $rest_endpoint
                );
                $issues[] = array(
                    'type'    => 'warning',
                    'label'   => __( 'REST API reachability', 'saec-core' ),
                    'message' => $rest_message,
                );
            } else {
                $code = (int) wp_remote_retrieve_response_code( $response );
                if ( $code < 200 || $code >= 300 ) {
                    $rest_status  = 'warn';
                    $rest_message = sprintf(
                        /* translators: 1: HTTP status code, 2: endpoint */
                        __( 'REST API responded with HTTP status %1$d for %2$s.', 'saec-core' ),
                        $code,
                        $rest_endpoint
                    );
                    $issues[] = array(
                        'type'    => 'warning',
                        'label'   => __( 'REST API reachability', 'saec-core' ),
                        'message' => $rest_message,
                    );
                }
            }
        } else {
            $rest_status  = 'warn';
            $rest_message = __( 'REST API functions are not available.', 'saec-core' );
            $issues[] = array(
                'type'    => 'warning',
                'label'   => __( 'REST API reachability', 'saec-core' ),
                'message' => $rest_message,
            );
        }

        $checks['rest'] = array(
            'label'   => __( 'REST API reachability', 'saec-core' ),
            'status'  => $rest_status,
            'message' => $rest_message,
        );

        // === Licence endpoint reachability ===
        $license_info  = function_exists( 'saec_suite_get_license_info' ) ? saec_suite_get_license_info() : array();
        $core_endpoint = function_exists( 'saec_suite_get_license_api_endpoint' ) ? saec_suite_get_license_api_endpoint() : '';
        $core_endpoint = $core_endpoint ? $core_endpoint : ( isset( $license_info['api_endpoint'] ) ? trim( (string) $license_info['api_endpoint'] ) : '' );
        $custom_endpoint = $this->get_custom_endpoint();
        $effective_endpoint = $custom_endpoint ? $custom_endpoint : $core_endpoint;

        $lic_status  = 'ok';
        $lic_message = __( 'SAEC licence API endpoint is configured.', 'saec-core' );

        if ( empty( $effective_endpoint ) ) {
            $lic_status  = 'warn';
            $lic_message = __( 'No SAEC licence API endpoint configured.', 'saec-core' );
            $issues[]    = array(
                'type'    => 'warning',
                'label'   => __( 'SAEC licence API endpoint', 'saec-core' ),
                'message' => $lic_message,
            );
        } elseif ( function_exists( 'wp_remote_get' ) ) {
            $response = wp_remote_get(
                trailingslashit( $effective_endpoint ),
                array(
                    'timeout'   => 8,
                    'sslverify' => false,
                )
            );
            if ( is_wp_error( $response ) ) {
                $lic_status  = 'warn';
                $lic_message = sprintf(
                    /* translators: 1: error message, 2: endpoint */
                    __( 'Error contacting SAEC licence API endpoint %2$s: %1$s', 'saec-core' ),
                    $response->get_error_message(),
                    $effective_endpoint
                );
                $issues[]    = array(
                    'type'    => 'warning',
                    'label'   => __( 'SAEC licence API endpoint', 'saec-core' ),
                    'message' => $lic_message,
                );
            } else {
                $code = (int) wp_remote_retrieve_response_code( $response );
                if ( $code < 200 || $code >= 300 ) {
                    $lic_status  = 'warn';
                    $lic_message = sprintf(
                        /* translators: 1: HTTP status code, 2: endpoint */
                        __( 'SAEC licence API endpoint %2$s responded with HTTP %1$d.', 'saec-core' ),
                        $code,
                        $effective_endpoint
                    );
                    $issues[]    = array(
                        'type'    => 'warning',
                        'label'   => __( 'SAEC licence API endpoint', 'saec-core' ),
                        'message' => $lic_message,
                    );
                }
            }
        }

        $checks['licence'] = array(
            'label'   => __( 'SAEC licence API endpoint', 'saec-core' ),
            'status'  => $lic_status,
            'message' => $lic_message,
        );

        // === Critical modules presence ===
        $registry = $this->get_registry();
        $plugins  = $this->get_installed_plugins();

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $critical_missing = array();
        foreach ( $registry as $slug => $conf ) {
            if ( 'critical' !== $conf['importance'] ) {
                continue;
            }
            $is_installed = isset( $plugins[ $slug ] );
            if ( ! $is_installed ) {
                $critical_missing[] = $conf['name'];
            }
        }

        if ( ! empty( $critical_missing ) ) {
            $issues[] = array(
                'type'    => 'warning',
                'label'   => __( 'Critical SAEC modules', 'saec-core' ),
                'message' => sprintf(
                    /* translators: %s: list of module names */
                    __( 'The following critical SAEC modules are missing: %s', 'saec-core' ),
                    implode( ', ', $critical_missing )
                ),
            );
        }

        // === Per-module diagnostics (Health v2) ===
        $module_diag = array();

        foreach ( $registry as $slug => $conf ) {
            $name       = $conf['name'];
            $importance = $conf['importance'];
            $category   = $conf['category'];

            $is_installed = isset( $plugins[ $slug ] );
            $is_active    = $is_installed && is_plugin_active( $slug );
            $version      = $is_installed ? $plugins[ $slug ]['Version'] : '';

            $score      = 'ok'; // ok / warn / critical
            $status_msg = '';
            $hint       = '';

            if ( ! $is_installed ) {
                if ( 'critical' === $importance ) {
                    $score      = 'critical';
                    $status_msg = __( 'Module not installed.', 'saec-core' );
                    $hint       = __( 'Install this module from the SAEC Marketplace to ensure full protection.', 'saec-core' );
                } else {
                    $score      = 'warn';
                    $status_msg = __( 'Module missing (not installed).', 'saec-core' );
                    $hint       = __( 'Consider installing this module from the SAEC Marketplace.', 'saec-core' );
                }
            } elseif ( ! $is_active ) {
                if ( 'critical' === $importance ) {
                    $score      = 'critical';
                    $status_msg = __( 'Module installed but inactive.', 'saec-core' );
                    $hint       = __( 'Activate this module to benefit from its protection and features.', 'saec-core' );
                } else {
                    $score      = 'warn';
                    $status_msg = __( 'Module installed but inactive.', 'saec-core' );
                    $hint       = __( 'Activate this module if you want to use its features.', 'saec-core' );
                }
            } else {
                $score      = 'ok';
                $status_msg = __( 'Module installed and active.', 'saec-core' );
                $hint       = __( 'No immediate action required.', 'saec-core' );
            }

            // Add contextual hints based on global checks.
            if ( 'saec-guardian/saec-guardian.php' === $slug ) {
                if ( 'warn' === $rest_status ) {
                    $score = ( 'critical' === $score ) ? 'critical' : 'warn';
                    $hint  = __( 'Check Guardian rules / Cloudflare / SAEC Perf to ensure that /wp-json/ is not blocked for legitimate traffic.', 'saec-core' );
                }
            }

            if ( 'saec-core/saec-core.php' === $slug ) {
                if ( 'warn' === $lic_status ) {
                    $score = ( 'critical' === $score ) ? 'critical' : 'warn';
                    $hint  = __( 'Review SAEC Core licence configuration and ensure the licence API endpoint is reachable.', 'saec-core' );
                }
            }

            if ( 'saec-db-cleaner/saec-db-cleaner.php' === $slug && $is_active ) {
                $hint = __( 'Use SAEC DB Cleaner regularly to trim transient data and keep the database lean.', 'saec-core' );
            }

            if ( 'saec-perf/saec-perf.php' === $slug && $is_active ) {
                $hint = __( 'Verify that caching and optimisation rules are correctly applied and do not conflict with other layers (e.g. Cloudflare).', 'saec-core' );
            }

            $module_diag[ $slug ] = array(
                'name'       => $name,
                'category'   => $category,
                'importance' => $importance,
                'installed'  => $is_installed,
                'active'     => $is_active,
                'version'    => $version,
                'score'      => $score,
                'status_msg' => $status_msg,
                'hint'       => $hint,
            );
        }

        ?>
        <div class="saec-cc-grid">
            <div class="saec-cc-card saec-cc-card-glass">
                <h2><?php esc_html_e( 'Technical checks', 'saec-core' ); ?></h2>
                <p>
                    <a class="button button-secondary" href="<?php echo esc_url( $bundle_url ); ?>">
                        <?php esc_html_e( 'Download support bundle', 'saec-core' ); ?>
                    </a>
                </p>

                <table class="saec-cc-table saec-cc-table-compact">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Check', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Status', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'saec-core' ); ?></th>
                            <th><?php esc_html_e( 'Details', 'saec-core' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $checks as $key => $check ) :
                            $status_label = __( 'OK', 'saec-core' );
                            $status_class = 'saec-cc-badge-ok';
                            if ( 'warn' === $check['status'] ) {
                                $status_label = __( 'Warning', 'saec-core' );
                                $status_class = 'saec-cc-badge-warn';
                            }
                            ?>
                            <tr>
                                <td><?php echo esc_html( $check['label'] ); ?></td>
                                <td><span class="saec-cc-badge <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_label ); ?></span></td>
                                <td><?php echo esc_html( $check['message'] ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="saec-cc-card saec-cc-card-glass saec-cc-card-critical">
                <h2><?php esc_html_e( 'Detected issues', 'saec-core' ); ?></h2>
                <?php if ( empty( $issues ) ) : ?>
                    <p><?php esc_html_e( 'No major issues detected with SAEC Suite on this site.', 'saec-core' ); ?></p>
                <?php else : ?>
                    <ul class="saec-cc-list">
                        <?php foreach ( $issues as $issue ) : ?>
                            <li>
                                <strong><?php echo esc_html( $issue['label'] ); ?>:</strong>
                                <?php echo esc_html( $issue['message'] ); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="saec-cc-card saec-cc-card-glass saec-cc-card-modules-health">
            <h2><?php esc_html_e( 'SAEC module diagnostics', 'saec-core' ); ?></h2>
            <p class="description">
                <?php esc_html_e( 'Status and recommendations per SAEC module, based on importance, activation and connectivity.', 'saec-core' ); ?>
            </p>

            <table class="saec-cc-table saec-cc-table-compact saec-cc-table-modhealth">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Module', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Category', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Importance', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Version', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Score', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Suggested action', 'saec-core' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $module_diag as $slug => $diag ) :
                        $importance_label = '';
                        if ( 'critical' === $diag['importance'] ) {
                            $importance_label = __( 'Critical', 'saec-core' );
                        } elseif ( 'recommended' === $diag['importance'] ) {
                            $importance_label = __( 'Recommended', 'saec-core' );
                        } else {
                            $importance_label = __( 'Optional', 'saec-core' );
                        }

                        $score_label = __( 'OK', 'saec-core' );
                        $score_class = 'saec-cc-badge-ok';
                        if ( 'warn' === $diag['score'] ) {
                            $score_label = __( 'Warning', 'saec-core' );
                            $score_class = 'saec-cc-badge-warn';
                        } elseif ( 'critical' === $diag['score'] ) {
                            $score_label = __( 'Critical', 'saec-core' );
                            $score_class = 'saec-cc-badge-critical';
                        }

                        $icon_url = $this->resolve_icon_url( $slug, '' );
                        ?>
                        <tr>
                            <td>
                                <div class="saec-cc-module-with-icon">
                                    <?php if ( $icon_url ) : ?>
                                        <span class="saec-cc-module-icon">
                                            <img src="<?php echo esc_url( $icon_url ); ?>" alt="" />
                                        </span>
                                    <?php endif; ?>
                                    <span class="saec-cc-module-name">
                                        <?php echo esc_html( $diag['name'] ); ?><br />
                                        <code><?php echo esc_html( $slug ); ?></code>
                                    </span>
                                </div>
                            </td>
                            <td><?php echo esc_html( $diag['category'] ); ?></td>
                            <td><?php echo esc_html( $importance_label ); ?></td>
                            <td><?php echo $diag['version'] ? esc_html( $diag['version'] ) : '&mdash;'; ?></td>
                            <td><span class="saec-cc-badge <?php echo esc_attr( $score_class ); ?>"><?php echo esc_html( $score_label ); ?></span></td>
                            <td><?php echo esc_html( $diag['status_msg'] ); ?></td>
                            <td><?php echo esc_html( $diag['hint'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Render marketplace tab.
     */
    private 
function render_logs() {
        if ( ! class_exists( 'SAEC_Logger' ) ) {
            echo '<div class="notice notice-warning"><p>' . esc_html__( 'Logger is not available.', 'saec-core' ) . '</p></div>';
            return;
        }

        $entries = SAEC_Logger::get( 200 );
        $clear_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_clear_logs' ), 'saec_clear_logs' );
        $download_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_logs_bundle' ), 'saec_logs_bundle' );

        if ( isset( $_GET['cleared'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Logs cleared.', 'saec-core' ) . '</p></div>';
        }

        ?>
        <div class="saec-cc-card saec-cc-card-glass">
            <h2><?php esc_html_e( 'SAEC Logs', 'saec-core' ); ?></h2>

            <p>
                <a class="button button-secondary" href="<?php echo esc_url( $download_url ); ?>"><?php esc_html_e( 'Download JSON', 'saec-core' ); ?></a>
                <a class="button button-secondary" href="<?php echo esc_url( $clear_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Clear all SAEC logs?', 'saec-core' ) ); ?>');"><?php esc_html_e( 'Clear logs', 'saec-core' ); ?></a>
            </p>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Time (UTC)', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Level', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Message', 'saec-core' ); ?></th>
                        <th><?php esc_html_e( 'Context', 'saec-core' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $entries ) ) : ?>
                        <tr><td colspan="4"><?php esc_html_e( 'No entries.', 'saec-core' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $entries as $e ) : ?>
                            <tr>
                                <td><?php echo esc_html( gmdate( 'Y-m-d H:i:s', (int) $e['ts'] ) ); ?></td>
                                <td><?php echo esc_html( strtoupper( (string) $e['level'] ) ); ?></td>
                                <td><code><?php echo esc_html( (string) $e['message'] ); ?></code></td>
                                <td><code><?php echo esc_html( ! empty( $e['context'] ) ? wp_json_encode( $e['context'] ) : '' ); ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private function render_audit() {
        if ( ! current_user_can( 'saec_view_reports' ) && ! current_user_can( 'saec_manage_suite' ) && ! current_user_can( 'manage_options' ) ) {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'You are not allowed to access this section.', 'saec-core' ) . '</p></div>';
            return;
        }

        if ( ! class_exists( 'SAEC_Audit' ) ) {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'Audit system is not available.', 'saec-core' ) . '</p></div>';
            return;
        }

        $entries = SAEC_Audit::get( 200 );
        $clear_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_clear_audit' ), 'saec_clear_audit' );
        $download_url = wp_nonce_url( admin_url( 'admin-post.php?action=saec_audit_bundle' ), 'saec_audit_bundle' );

        if ( isset( $_GET['cleared'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Audit log cleared.', 'saec-core' ) . '</p></div>';
        }

        echo '<div class="saec-cc-panel">';
        echo '<div style="display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;">';
        echo '<h2 style="margin:0;">' . esc_html__( 'Activity Audit', 'saec-core' ) . '</h2>';
        echo '<div style="display:flex;gap:10px;">';
        echo '<a class="button" href="' . esc_url( $download_url ) . '">' . esc_html__( 'Download JSON', 'saec-core' ) . '</a>';
        echo '<a class="button button-secondary" href="' . esc_url( $clear_url ) . '" onclick="return confirm(\'' . esc_js( __( 'Clear the audit log?', 'saec-core' ) ) . '\');">' . esc_html__( 'Clear', 'saec-core' ) . '</a>';
        echo '</div>';
        echo '</div>';

        echo '<p style="margin-top:10px;color:#646970;">' . esc_html__( 'Tracks administrative actions for support and compliance.', 'saec-core' ) . '</p>';

        echo '<table class="widefat striped" style="margin-top:12px;">';
        echo '<thead><tr>';
        echo '<th style="width:180px;">' . esc_html__( 'Time (UTC)', 'saec-core' ) . '</th>';
        echo '<th style="width:140px;">' . esc_html__( 'User', 'saec-core' ) . '</th>';
        echo '<th style="width:120px;">' . esc_html__( 'IP', 'saec-core' ) . '</th>';
        echo '<th style="width:160px;">' . esc_html__( 'Action', 'saec-core' ) . '</th>';
        echo '<th>' . esc_html__( 'Details', 'saec-core' ) . '</th>';
        echo '</tr></thead><tbody>';

        if ( empty( $entries ) ) {
            echo '<tr><td colspan="5">' . esc_html__( 'No audit entries yet.', 'saec-core' ) . '</td></tr>';
        } else {
            foreach ( $entries as $e ) {
                $ts = isset( $e['ts'] ) ? (int) $e['ts'] : 0;
                $time = $ts ? gmdate( 'Y-m-d H:i:s', $ts ) : '';
                $user = isset( $e['user'] ) ? (string) $e['user'] : '';
                $ip = isset( $e['ip'] ) ? (string) $e['ip'] : '';
                $action = isset( $e['action'] ) ? (string) $e['action'] : '';
                $details = ( isset( $e['details'] ) && is_array( $e['details'] ) ) ? $e['details'] : array();

                echo '<tr>';
                echo '<td>' . esc_html( $time ) . '</td>';
                echo '<td>' . esc_html( $user ) . '</td>';
                echo '<td><code>' . esc_html( $ip ) . '</code></td>';
                echo '<td><code>' . esc_html( $action ) . '</code></td>';
                echo '<td><pre style="margin:0;white-space:pre-wrap;">' . esc_html( wp_json_encode( $details, JSON_PRETTY_PRINT ) ) . '</pre></td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '</div>';
    }


function render_marketplace() {

        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = function_exists( 'get_plugins' ) ? get_plugins() : array();

        $catalog = SAEC_Core_Marketplace::get_catalog();

        ?>
        <div class="saec-cc-card saec-cc-card-marketplace saec-cc-card-glass">
            <div class="saec-cc-marketplace-header">
                <div class="saec-cc-marketplace-header-main">
                    <div>
                        <h2><?php esc_html_e( 'SAEC Marketplace', 'saec-core' ); ?></h2>
                        <p class="description">
                            <?php esc_html_e( 'Install or update SAEC modules from your central licence server.', 'saec-core' ); ?>
                        </p>
                    </div>
					<a href="<?php echo esc_url( add_query_arg( 'tab', 'marketplace', admin_url( 'admin.php?page=saec-suite' ) ) ); ?>" class="button button-secondary">
                        <?php esc_html_e( 'Refresh catalogue', 'saec-core' ); ?>
                    </a>
                </div>
            </div>

            <?php if ( ! empty( $catalog['error'] ) ) : ?>
                <div class="notice notice-error inline">
                    <p><?php echo esc_html( $catalog['error'] ); ?></p>
                </div>
            <?php elseif ( empty( $catalog['modules'] ) ) : ?>
                <p><?php esc_html_e( 'No modules are currently available in the SAEC Marketplace.', 'saec-core' ); ?></p>
            <?php else : ?>
                <div class="saec-cc-marketplace-grid">
                    <?php foreach ( $catalog['modules'] as $module ) :
                        $slug     = isset( $module['slug'] ) ? (string) $module['slug'] : '';
                        $name     = isset( $module['name'] ) ? (string) $module['name'] : $slug;
                        $desc     = isset( $module['description'] ) ? (string) $module['description'] : '';
                        $tier     = isset( $module['tier'] ) ? (string) $module['tier'] : '';
                        $category = isset( $module['category'] ) ? (string) $module['category'] : '';
                        $icon     = isset( $module['icon'] ) ? (string) $module['icon'] : '';
                        $version  = isset( $module['current_version'] ) ? (string) $module['current_version'] : '';

                        $icon     = $this->resolve_icon_url( $slug, $icon );

                        $installed          = isset( $all_plugins[ $slug ] );
                        $installed_version  = $installed ? (string) $all_plugins[ $slug ]['Version'] : '';
                        $active             = $installed && is_plugin_active( $slug );
                        $has_update         = false;
                        $version_compare_ok = ( $version && $installed_version && preg_match( '/[0-9]/', $version ) && preg_match( '/[0-9]/', $installed_version ) );

                        if ( $version_compare_ok && version_compare( $installed_version, $version, '<' ) ) {
                            $has_update = true;
                        }

                        if ( ! $installed && ! $version && $installed_version ) {
                            $version = $installed_version;
                        }

                        $status_labels = array();

                        if ( ! $installed ) {
                            $status_labels[] = __( 'Not installed', 'saec-core' );
                        } else {
                            if ( $active ) {
                                $status_labels[] = __( 'Active', 'saec-core' );
                            } else {
                                $status_labels[] = __( 'Inactive', 'saec-core' );
                            }

                            if ( $has_update ) {
                                $status_labels[] = __( 'Update available', 'saec-core' );
                            } else {
                                $status_labels[] = __( 'Up to date', 'saec-core' );
                            }
                        }

                        $action  = '';
                        $label   = '';
                        $accent  = '';

                        if ( ! $installed ) {
                            $action = 'install';
                            $label  = __( 'Install', 'saec-core' );
                            $accent = 'primary';
                        } elseif ( $has_update ) {
                            $action = 'update';
                            $label  = __( 'Update', 'saec-core' );
                            $accent = 'primary';
                        }

                        ?>
                        <div class="saec-cc-market-item" data-slug="<?php echo esc_attr( $slug ); ?>">
                            <div class="saec-cc-market-item-header">
                                <?php if ( $icon ) : ?>
                                    <div class="saec-cc-market-item-icon">
                                        <img src="<?php echo esc_url( $icon ); ?>" alt="" />
                                    </div>
                                <?php endif; ?>
                                <div class="saec-cc-market-item-title">
                                    <h3><?php echo esc_html( $name ); ?></h3>
                                    <div class="saec-cc-market-item-pills">
                                        <?php if ( $category ) : ?>
                                            <span class="saec-cc-pill saec-cc-pill-category"><?php echo esc_html( $category ); ?></span>
                                        <?php endif; ?>
                                        <?php if ( $tier ) : ?>
                                            <span class="saec-cc-pill saec-cc-pill-tier"><?php echo esc_html( ucfirst( $tier ) ); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="saec-cc-market-item-body">
                                <?php if ( $desc ) : ?>
                                    <p><?php echo esc_html( $desc ); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="saec-cc-market-item-footer">
                                <div class="saec-cc-market-meta">
                                    <?php if ( $version ) : ?>
                                        <span class="saec-cc-market-version">
                                            <?php
                                            printf(
                                                esc_html__( 'Remote: %s', 'saec-core' ),
                                                esc_html( $version )
                                            );
                                            ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if ( $installed_version ) : ?>
                                        <span class="saec-cc-market-installed">
                                            <?php
                                            printf(
                                                esc_html__( 'Installed: %s', 'saec-core' ),
                                                esc_html( $installed_version )
                                            );
                                            ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="saec-cc-market-actions">
                                    <?php if ( $status_labels ) : ?>
                                        <span class="saec-cc-status-label">
                                            <?php echo esc_html( implode( ' • ', $status_labels ) ); ?>
                                        </span>
                                    <?php endif; ?>

                                    <?php if ( $action && $slug ) : ?>
                                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                            <input type="hidden" name="action" value="saec_core_cc_market_install" />
                                            <input type="hidden" name="saec_cc_slug" value="<?php echo esc_attr( $slug ); ?>" />
                                            <input type="hidden" name="saec_cc_do" value="<?php echo esc_attr( $action ); ?>" />
                                            <?php wp_nonce_field( 'saec_core_cc_market_install', 'saec_cc_nonce' ); ?>
                                            <button type="submit" class="button button-<?php echo esc_attr( $accent ); ?>">
                                                <?php echo esc_html( $label ); ?>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render settings tab.
     */
private function render_settings() {

$suite_opts = get_option( 'saec_suite_options', array() );
$safe_mode  = is_array( $suite_opts ) && ! empty( $suite_opts['safe_mode'] );

?>
<div class="saec-cc-card saec-cc-card-glass">
    <h2><?php esc_html_e( 'Safe Mode', 'saec-core' ); ?></h2>
    <p class="description">
        <?php esc_html_e( 'When enabled, risky actions are disabled in the SAEC Suite interface (recommended on production).', 'saec-core' ); ?>
    </p>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <?php wp_nonce_field( 'saec_save_settings' ); ?>
        <input type="hidden" name="action" value="saec_save_settings" />
        <label class="saec-cc-switch saec-switch-colored" style="margin-top:10px;display:inline-flex;align-items:center;gap:10px;">
            <input type="checkbox" name="saec_suite_safe_mode" value="1" <?php checked( $safe_mode ); ?> />
            <span><?php echo $safe_mode ? esc_html__( 'ON', 'saec-core' ) : esc_html__( 'OFF', 'saec-core' ); ?></span>
        </label>
        <p style="margin-top:12px;">
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'saec-core' ); ?></button>
            <?php if ( isset( $_GET['saved'] ) ) : ?>
                <span style="margin-left:10px;"><?php esc_html_e( 'Saved.', 'saec-core' ); ?></span>
            <?php endif; ?>
        </p>
    </form>
</div>


<div class="saec-cc-card saec-cc-card-glass" style="margin-top:16px;">
    <h2><?php esc_html_e( 'Export / Import configuration', 'saec-core' ); ?></h2>
    <p class="description"><?php esc_html_e( 'Export your SAEC Suite settings to quickly replicate them on another site. Import is limited to safe settings only.', 'saec-core' ); ?></p>

    <p style="margin:12px 0;">
        <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=saec_core_cc_export_config' ), 'saec_core_cc_export_config' ) ); ?>">
            <?php esc_html_e( 'Download config (JSON)', 'saec-core' ); ?>
        </a>
    </p>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="margin-top:12px;">
        <?php wp_nonce_field( 'saec_core_cc_import_config', '_wpnonce' ); ?>
        <input type="hidden" name="action" value="saec_core_cc_import_config" />
        <input type="file" name="saec_config_file" accept="application/json" required />
        <button type="submit" class="button button-primary"><?php esc_html_e( 'Import config', 'saec-core' ); ?></button>
    </form>
</div>



<?php
        $license_info  = function_exists( 'saec_suite_get_license_info' ) ? saec_suite_get_license_info() : array();
        // Resolved endpoint (Core default + overrides). Never fallback to rest_url('saec-license/v1') on client sites.
        $core_endpoint = function_exists( 'saec_suite_get_license_api_endpoint' ) ? saec_suite_get_license_api_endpoint() : '';
        $core_endpoint = $core_endpoint ? $core_endpoint : ( isset( $license_info['api_endpoint'] ) ? trim( (string) $license_info['api_endpoint'] ) : '' );

        // Settings override stored in Control Center options (and legacy key custom_endpoint).
        $opts            = get_option( 'saec_cc_options', array() );
        $custom_endpoint = '';
        if ( is_array( $opts ) ) {
            if ( ! empty( $opts['license_api_endpoint'] ) ) {
                $custom_endpoint = (string) $opts['license_api_endpoint'];
            } elseif ( ! empty( $opts['custom_endpoint'] ) ) {
                $custom_endpoint = (string) $opts['custom_endpoint'];
            }
        }
        $effective = $custom_endpoint ? $custom_endpoint : $core_endpoint;

        ?>
        <div class="saec-cc-card saec-cc-card-glass">
            <h2><?php esc_html_e( 'Settings', 'saec-core' ); ?></h2>
            <p class="description">
                <?php esc_html_e( 'Read and optionally override some SAEC Control Center behaviour. Licence itself is still fully managed by SAEC Core.', 'saec-core' ); ?>
            </p>

            <table class="saec-cc-table saec-cc-table-compact">
                <tbody>
                    <tr>
                        <th><?php esc_html_e( 'Core licence API endpoint (from SAEC Core)', 'saec-core' ); ?></th>
                        <td><?php echo $core_endpoint ? esc_html( $core_endpoint ) : '&mdash;'; ?></td>
                    </tr>
<tr>
  <th scope="row"><?php esc_html_e( 'Licence API endpoint', 'saec-core' ); ?></th>
  <td>
    <input type="url" name="saec_suite_options[license_api_endpoint]" value="<?php echo esc_attr( isset( $opts['license_api_endpoint'] ) ? $opts['license_api_endpoint'] : '' ); ?>" class="regular-text" placeholder="https://saec.me/wp-json/saec-license/v1/" />
    <p class="description"><?php esc_html_e( 'Leave empty to use the default SAEC licence server.', 'saec-core' ); ?></p>
  </td>
</tr>

                    <tr>
                        <th><?php esc_html_e( 'Effective endpoint used by Marketplace', 'saec-core' ); ?></th>
                        <td><?php echo $effective ? esc_html( $effective ) : '&mdash;'; ?></td>
                    </tr>
                </tbody>
            </table>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="saec-cc-settings-form">
                <input type="hidden" name="action" value="saec_core_cc_save_settings" />
                <?php wp_nonce_field( 'saec_core_cc_save_settings', 'saec_core_cc_settings_nonce' ); ?>

                <h3><?php esc_html_e( 'Endpoint override', 'saec-core' ); ?></h3>
                <p class="description">
                    <?php esc_html_e( 'If needed, you can force Control Center and Marketplace to use a specific SAEC licence endpoint (for example when testing a staging licence server). Leave empty to rely on SAEC Core configuration.', 'saec-core' ); ?>
                </p>

                <table class="saec-cc-table saec-cc-table-compact">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="saec_cc_custom_endpoint"><?php esc_html_e( 'Custom licence API endpoint', 'saec-core' ); ?></label>
                            </th>
                            <td>
                                <input type="url" class="regular-text code" id="saec_cc_custom_endpoint" name="saec_cc_custom_endpoint"
                                       value="<?php echo esc_attr( $custom_endpoint ); ?>" placeholder="https://saec.me/wp-json/saec-license/v1" />
                            </td>
                        </tr>
                    </tbody>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e( 'Save settings', 'saec-core' ); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Render help tab.
     */
    private function render_help() {
        $license_base = saec_core_resolve_license_api_base();
        $logo_url     = 'https://saec.me/wp-content/uploads/2025/12/cropped-saec_logo_original-e1764235312972.png';
        ?>
        <div class="saec-cc-page saec-cc-help">
            <div class="saec-cc-card">
                <div class="saec-cc-help-header">
                    <div class="saec-cc-help-brand">
                        <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr__( 'SAEC Holding', 'saec-core' ); ?>" class="saec-cc-help-logo" />
                    </div>
                    <div class="saec-cc-help-title">
                        <h2><?php echo esc_html__( 'SAEC Suite – Core', 'saec-core' ); ?></h2>
                        <p class="saec-cc-muted">
                            <?php echo esc_html__( 'Foundation plugin that connects this WordPress site to the SAEC Suite ecosystem.', 'saec-core' ); ?>
                        </p>
                    </div>
                </div>

                <h3><?php echo esc_html__( 'What this module does', 'saec-core' ); ?></h3>
                <ul class="saec-cc-list">
                    <li><?php echo esc_html__( 'Adds the SAEC Suite control center in WordPress admin (single entry point).', 'saec-core' ); ?></li>
                    <li><?php echo esc_html__( 'Stores and validates your SAEC licence key to unlock tiers (Basic / Pro / Agency).', 'saec-core' ); ?></li>
                    <li><?php echo esc_html__( 'Applies “lockdown” rules when no valid licence is detected (gates SAEC modules).', 'saec-core' ); ?></li>
                    <li><?php echo esc_html__( 'Connects to the SAEC marketplace endpoint to list available SAEC packages and updates.', 'saec-core' ); ?></li>
                </ul>

                <h3><?php echo esc_html__( 'Why it is useful in daily use', 'saec-core' ); ?></h3>
                <div class="saec-cc-grid saec-cc-grid-2">
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Centralized management', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'One page to see the licence status, installed SAEC modules, and available updates.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Controlled upgrades', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'SAEC Core is designed to keep the suite consistent: licence checks, update sources, and shared UI.', 'saec-core' ); ?></p>
                    </div>
                </div>

                <h3><?php echo esc_html__( 'SAEC Suite in WordPress', 'saec-core' ); ?></h3>
                <p><?php echo esc_html__( 'The SAEC Suite is a set of WordPress plugins managed as a coherent stack. SAEC Core provides the shared entry point, licence gating, and marketplace connectivity used by other SAEC modules.', 'saec-core' ); ?></p>

                <h3><?php echo esc_html__( 'Control center tabs', 'saec-core' ); ?></h3>
                <div class="saec-cc-grid saec-cc-grid-2">
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Dashboard', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Quick status: current tier, lockdown state, and key indicators.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Modules', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Lists detected SAEC modules and exposes activation/deactivation controls.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Marketplace', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Lists SAEC packages from the marketplace endpoint and shows available updates.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Licence', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Enter or change the licence key and access purchase links when provided.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Registry', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Internal registry used to track detected modules/packages and related metadata.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Health', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Diagnostics and checks to help troubleshoot connectivity and environment issues.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Logs / Audit', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Operational logs and audit trail recorded by the suite.', 'saec-core' ); ?></p>
                    </div>
                    <div class="saec-cc-subcard">
                        <h4><?php echo esc_html__( 'Settings', 'saec-core' ); ?></h4>
                        <p><?php echo esc_html__( 'Configuration related to the suite (endpoints, behaviour, advanced options).', 'saec-core' ); ?></p>
                    </div>
                </div>

                <h3><?php echo esc_html__( 'Company information', 'saec-core' ); ?></h3>
                <ul class="saec-cc-list">
                    <li><?php echo esc_html__( 'Company: SAEC Holding', 'saec-core' ); ?></li>
                    <li><?php echo esc_html__( 'Website: https://saec.me', 'saec-core' ); ?></li>
                    <li><?php echo esc_html__( 'Email: info@saec.me', 'saec-core' ); ?></li>
                    <li>
                        <?php
                        /* translators: %s: URL to the official logo */
                        echo esc_html( sprintf( __( 'Official logo: %s', 'saec-core' ), $logo_url ) );
                        ?>
                    </li>
                </ul>

                <h3><?php echo esc_html__( 'Connectivity', 'saec-core' ); ?></h3>
                <p>
                    <?php
                    /* translators: %s: licence API base URL */
                    echo esc_html( sprintf( __( 'Default licence API endpoint: %s', 'saec-core' ), $license_base ) );
                    ?>
                </p>

                <h3><?php echo esc_html__( 'Data sent to the licence server (ping)', 'saec-core' ); ?></h3>
                <p><?php echo esc_html__( 'When enabled by the plugin workflow, SAEC Core can ping the licence server. The payload includes: site URL, hostname, site fingerprint, machine ID (if available), core version, WordPress version, PHP version, admin email, and a timestamp.', 'saec-core' ); ?></p>
            </div>
        </div>
        <?php
    }


    /**
     * Handle install/update action from Marketplace.
     */
    public function handle_market_install() {
        if ( ! current_user_can( 'install_plugins' ) ) {
            wp_die( esc_html__( 'You are not allowed to install plugins.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_core_cc_market_install', 'saec_cc_nonce' );

        // Safe Mode: block installs/updates in production-safe mode.
        if ( function_exists( 'saec_suite_is_safe_mode' ) && saec_suite_is_safe_mode() ) {
            set_transient(
                'saec_cc_market_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'Safe Mode is enabled. Installs and updates are disabled.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'marketplace', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

// Safe Mode: block installs/updates in production-safe mode.
        if ( function_exists( 'saec_suite_is_safe_mode' ) && saec_suite_is_safe_mode() ) {
            set_transient(
                'saec_cc_market_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'Safe Mode is enabled. Installs and updates are disabled.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'marketplace', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

$slug = isset( $_POST['saec_cc_slug'] ) ? sanitize_text_field( wp_unslash( $_POST['saec_cc_slug'] ) ) : '';
        $do   = isset( $_POST['saec_cc_do'] ) ? sanitize_key( wp_unslash( $_POST['saec_cc_do'] ) ) : 'install';

        if ( empty( $slug ) ) {
            set_transient(
                'saec_cc_market_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'Missing module slug.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'marketplace', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

        $result = SAEC_Core_Marketplace::install_or_update( $slug );

        if ( is_wp_error( $result ) ) {
            set_transient(
                'saec_cc_market_notice',
                array(
                    'type'    => 'error',
                    'message' => $result->get_error_message(),
                ),
                300
            );
        } else {
            $verb = ( 'update' === $do ) ? __( 'updated', 'saec-core' ) : __( 'installed', 'saec-core' );
            set_transient(
                'saec_cc_market_notice',
                array(
                    'type'    => 'success',
                    'message' => sprintf(
                        /* translators: 1: slug, 2: verb */
                        __( 'Module %1$s has been %2$s successfully.', 'saec-core' ),
                        $slug,
                        $verb
                    ),
                ),
                60
            );
        }

        wp_safe_redirect( add_query_arg( 'tab', 'marketplace', admin_url( 'admin.php?page=saec-suite' ) ) );
        exit;
    }

    /**
     * Handle settings save.
     */
    public function handle_save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to manage SAEC Control Center settings.', 'saec-core' ) );
        }

        check_admin_referer( 'saec_core_cc_save_settings', 'saec_core_cc_settings_nonce' );

        $custom_endpoint = isset( $_POST['saec_cc_custom_endpoint'] ) ? trim( wp_unslash( $_POST['saec_cc_custom_endpoint'] ) ) : '';
        if ( '' !== $custom_endpoint ) {
            $custom_endpoint = esc_url_raw( $custom_endpoint );
        }

        $opts = get_option( 'saec_cc_options', array() );
        if ( ! is_array( $opts ) ) {
            $opts = array();
        }

        $opts['license_api_endpoint'] = $custom_endpoint;
        $opts['custom_endpoint']       = $custom_endpoint; // legacy
        update_option( 'saec_cc_options', $opts );

        set_transient(
            'saec_core_cc_settings_notice',
            array(
                'type'    => 'success',
                'message' => __( 'Settings saved.', 'saec-core' ),
            ),
            60
        );

        wp_safe_redirect( add_query_arg( 'tab', 'settings', admin_url( 'admin.php?page=saec-suite' ) ) );
        exit;
    }

    /**
     * Export SAEC Suite configuration (safe subset) as JSON.
     */
    public function handle_export_config() {
        if ( ! ( current_user_can( 'saec_manage_suite' ) || current_user_can( 'manage_options' ) ) ) {
            wp_die( esc_html__( 'You are not allowed to export SAEC configuration.', 'saec-core' ) );
        }
        check_admin_referer( 'saec_core_cc_export_config' );

        $payload = array(
            'exported_at' => gmdate( 'c' ),
            'site'        => get_site_url(),
            'version'     => defined( 'SAEC_CORE_VERSION' ) ? SAEC_CORE_VERSION : '',
            'options'     => array(
                'saec_suite_options' => get_option( 'saec_suite_options', array() ),
                'saec_cc_options'    => get_option( 'saec_cc_options', array() ),
            ),
        );

        $json = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        if ( false === $json ) {
            $json = wp_json_encode( $payload );
        }

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=saec-config-' . gmdate( 'Ymd-His' ) . '.json' );
        echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    /**
     * Import SAEC Suite configuration from JSON.
     */
    public function handle_import_config() {
        if ( ! ( current_user_can( 'saec_manage_suite' ) || current_user_can( 'manage_options' ) ) ) {
            wp_die( esc_html__( 'You are not allowed to import SAEC configuration.', 'saec-core' ) );
        }
        check_admin_referer( 'saec_core_cc_import_config' );

        if ( empty( $_FILES['saec_config_file']['tmp_name'] ) ) {
            set_transient(
                'saec_core_cc_settings_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'No configuration file provided.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'settings', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

        $raw = file_get_contents( (string) $_FILES['saec_config_file']['tmp_name'] );
        if ( false === $raw || '' === trim( (string) $raw ) ) {
            set_transient(
                'saec_core_cc_settings_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'Unable to read configuration file.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'settings', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) || empty( $data['options'] ) || ! is_array( $data['options'] ) ) {
            set_transient(
                'saec_core_cc_settings_notice',
                array(
                    'type'    => 'error',
                    'message' => __( 'Invalid configuration format.', 'saec-core' ),
                ),
                60
            );
            wp_safe_redirect( add_query_arg( 'tab', 'settings', admin_url( 'admin.php?page=saec-suite' ) ) );
            exit;
        }

        $options = $data['options'];

        // Only allow known safe options keys.
        if ( isset( $options['saec_suite_options'] ) && is_array( $options['saec_suite_options'] ) ) {
            // Keep only known keys.
            $allowed_suite = array( 'safe_mode' );
            $clean_suite   = array();
            foreach ( $allowed_suite as $k ) {
                if ( array_key_exists( $k, $options['saec_suite_options'] ) ) {
                    $clean_suite[ $k ] = $options['saec_suite_options'][ $k ] ? 1 : 0;
                }
            }
            update_option( 'saec_suite_options', $clean_suite );
        }

        if ( isset( $options['saec_cc_options'] ) && is_array( $options['saec_cc_options'] ) ) {
            // Currently no user-sensitive values are imported; keep as-is but ensure array.
            update_option( 'saec_cc_options', $options['saec_cc_options'] );
        }

        if ( class_exists( 'SAEC_Audit' ) ) {
            SAEC_Audit::add(
                'config_imported',
                array(
                    'file' => isset( $_FILES['saec_config_file']['name'] ) ? sanitize_text_field( wp_unslash( $_FILES['saec_config_file']['name'] ) ) : '',
                )
            );
        }

        set_transient(
            'saec_core_cc_settings_notice',
            array(
                'type'    => 'success',
                'message' => __( 'Configuration imported.', 'saec-core' ),
            ),
            60
        );

        wp_safe_redirect( add_query_arg( 'tab', 'settings', admin_url( 'admin.php?page=saec-suite' ) ) );
        exit;
    }

}